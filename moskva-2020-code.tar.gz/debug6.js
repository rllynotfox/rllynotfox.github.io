const puppeteer=require('puppeteer');const path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:800,height:520});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?q=low',{waitUntil:'load'});
await new Promise(r=>setTimeout(r,16000));
const d=await p.evaluate(()=>window.__diag);
console.log('postFailed=',d.postFailed,'errors=',d.shaderErrors.length);
if(d.shaderErrors.length){console.log(d.shaderErrors[0].info);console.log('----SRC----');console.log(d.shaderErrors[0].src.slice(0,1500));}
await b.close();})();
