/* Короткая свежая сессия: один сценарий, без марафона пересборок.
   Использование: node quick.js <scenario> */
const puppeteer=require('puppeteer');const path=require('path');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const SC=process.argv[2]||'bogie';
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:1000,height:620});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
p.on('console',m=>{const t=m.text();if(/нет материала|CONTEXT_LOST|not of type/i.test(t))errs.push(t.slice(0,120));});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?q=low',{waitUntil:'load'});
await p.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:180000});
await p.evaluate(()=>document.querySelector('#segCars button[data-cars="4"]').click());
await wait(2500);
const sync=()=>p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
const shot=async n=>{await sync();await p.screenshot({path:'shots/q_'+SC+'_'+n+'.png'});};
const info=()=>p.evaluate(()=>{const s=window.__stats();return{cp:s.cp,ct:s.ct,tp:s.tp,phase:s.phase,studio:s.studio,diag:window.__diag,err:window.__renderErr,calls:s.calls};});
const out={};
if(SC==='bogie'){
  await p.evaluate(()=>window.__setCam('bogie'));await wait(3500);await shot('view');out.bogie=await info();
  out.hits=await p.evaluate(()=>{const T=window.__three,sc=window.__getScene(),cam=window.__cam();
    const vis=o=>{let q=o;while(q){if(!q.visible)return false;q=q.parent;}return true;};
    const rc=new T.Raycaster();const n={};
    for(let i=0;i<11;i++)for(let j=0;j<8;j++){rc.setFromCamera(new T.Vector2(-0.85+i*0.17,-0.75+j*0.21),cam);
      const h=rc.intersectObjects(sc.children,true).filter(x=>x.object.type==='Mesh'&&vis(x.object));
      if(h[0]){const k=h[0].object.name||'?';n[k]=(n[k]||0)+1;}}
    return n;});
}else if(SC==='run'){
  await shot('start');
  await p.evaluate(()=>{const s=window.__sim;s.x=s.stopX-9;s.v=3.4;s.phase='approach';s.tPhase=0;window.__state.running=true;});
  let ok=false;try{await p.waitForFunction(()=>window.__sim.phase==='dwell',{timeout:100000,polling:700});ok=true;}catch(e){}
  out.arrived=ok;await wait(4000);out.doors=await p.evaluate(()=>window.__state.doorsOpen);
  await shot('arrived');out.after=await info();
}else if(SC==='reset'){
  await p.evaluate(()=>document.querySelector('#liveryBox button[data-liv="classic"]').click());await wait(2500);
  await p.evaluate(()=>document.getElementById('btnReset').click());await wait(3500);
  out.reset=await info();await shot('after');
  out.dustCount=await p.evaluate(()=>{let n=0;window.__getScene().traverse(o=>{if(o.type==='Points')n++;});return n;});
  await p.evaluate(()=>document.querySelector('#segCars button[data-cars="6"]').click());await wait(2500);
  out.dustCount2=await p.evaluate(()=>{let n=0;window.__getScene().traverse(o=>{if(o.type==='Points')n++;});return n;});
  await shot('cars6');
}
console.log(JSON.stringify(out,null,1),'errs',errs.slice(0,4));
await b.close();})();
