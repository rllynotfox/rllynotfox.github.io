const puppeteer=require('puppeteer');const path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:900,height:600});
const out=[];
p.on('console',async m=>{
  try{const parts=await Promise.all(m.args().map(a=>a.evaluate(v=>typeof v==='string'?v:(v&&v.message)||JSON.stringify(v)).catch(()=>'?')));
    out.push(m.type()+': '+parts.join(' | ').slice(0,3000));}catch(e){out.push(m.type()+': '+m.text())}
});
p.on('pageerror',e=>out.push('PAGEERROR '+e.message));
await p.goto('file://'+path.join(__dirname,'moskva-2020.html'),{waitUntil:'load'});
await new Promise(r=>setTimeout(r,25000));
const uniq=[...new Set(out)];
console.log(uniq.slice(0,6).join('\n\n========\n\n'));
await b.close();})();
