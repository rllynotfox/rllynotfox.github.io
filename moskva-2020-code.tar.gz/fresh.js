/* Свежая сессия: все ключевые ракурсы + данные + мобильный. Без марафона пересборок. */
const puppeteer=require('puppeteer');const path=require('path');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:1280,height:800});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
p.on('console',m=>{const t=m.text();if(/нет материала|CONTEXT_LOST|not of type/i.test(t))errs.push(t.slice(0,120));});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html'),{waitUntil:'load'});
await p.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:180000});
await wait(2500);
const sync=()=>p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
const out={};
out.start=await p.evaluate(()=>({q:window.__state.quality,cars:window.__stats().cars,diag:window.__diag}));
await sync();await p.screenshot({path:'shots/n_hero.png'});
for(const c of ['facade','cab','salon','bogie','side','roof','pano']){
  await p.evaluate(k=>window.__setCam(k),c);await wait(2200);await sync();
  await p.screenshot({path:'shots/n_'+c+'.png'});
}
out.cams=await p.evaluate(()=>window.__stats());
// данные
await p.evaluate(()=>document.getElementById('btnSpecs').click());await wait(700);
await p.screenshot({path:'shots/n_specs.png'});
out.specsOpen=await p.evaluate(()=>document.getElementById('specs').classList.contains('open'));
await p.evaluate(()=>document.getElementById('specsX').click());await wait(400);
// размеры + двери
await p.evaluate(()=>{window.__setCam('side');});await wait(1500);
await p.evaluate(()=>{const t=document.getElementById('tgDims');if(t)t.click();});
await p.evaluate(()=>document.getElementById('btnDoors').click());await wait(2500);await sync();
await p.screenshot({path:'shots/n_dims_doors.png'});
// орбита мышью
const b0=await p.evaluate(()=>window.__stats().cp);
await p.mouse.move(500,400);await p.mouse.down();
for(let i=0;i<12;i++){await p.mouse.move(500+i*16,400+i*4);await wait(30);}
await p.mouse.up();await wait(1000);await sync();await p.screenshot({path:'shots/n_orbit.png'});
out.orbitMoved=JSON.stringify(b0)!==JSON.stringify(await p.evaluate(()=>window.__stats().cp));
out.final=await p.evaluate(()=>({diag:window.__diag,err:window.__renderErr,calls:window.__stats().calls,tris:window.__stats().tris}));
out.overflow=await p.evaluate(()=>[document.documentElement.scrollWidth-document.documentElement.clientWidth,document.documentElement.scrollHeight-document.documentElement.clientHeight]);
await p.close();
const m=await b.newPage();await m.setViewport({width:390,height:780,isMobile:true,hasTouch:true});
m.on('pageerror',e=>errs.push('M '+e.message));
await m.goto('file://'+path.join(__dirname,'moskva-2020.html'),{waitUntil:'load'});
await m.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:180000});
await wait(2500);await m.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
await m.screenshot({path:'shots/n_mobile.png'});
out.mobileHidden=await m.evaluate(()=>document.getElementById('dock').classList.contains('hidden'));
await m.evaluate(()=>document.getElementById('btnPanel').click());await wait(800);
await m.screenshot({path:'shots/n_mobile_panel.png'});
out.mobileOverflow=await m.evaluate(()=>[document.documentElement.scrollWidth-document.documentElement.clientWidth,document.documentElement.scrollHeight-document.documentElement.clientHeight]);
out.mobileDiag=await m.evaluate(()=>window.__diag);
await m.close();await b.close();
console.log(JSON.stringify(out,null,1),'errs',errs.slice(0,5));
})();
