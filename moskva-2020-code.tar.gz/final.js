const puppeteer=require('puppeteer');const path=require('path');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:1000,height:620});
const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text().slice(0,100))});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?q=low',{waitUntil:'load'});
await p.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:120000});
await p.evaluate(()=>document.querySelector('#segCars button[data-cars="4"]').click());
await sleep(3000);
const sync=async()=>{await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));};
const shot=async n=>{await sync();await p.screenshot({path:'shots/f_'+n+'.png'});};
// 1 студия + тележка
await p.evaluate(()=>window.__setCam('bogie'));await sleep(3000);await shot('bogie_studio');
// 2 кабина
await p.evaluate(()=>window.__setCam('cab'));await sleep(2500);await shot('cab');
// 3 салон
await p.evaluate(()=>window.__setCam('salon'));await sleep(2500);await shot('salon');
// 4 габариты + двери + фасад
await p.evaluate(()=>{document.getElementById('tgDims').click();document.getElementById('btnDoors').click();window.__setCam('facade');});
await sleep(3500);await shot('dims_doors');
const st1=await p.evaluate(()=>({doors:window.__state.doorsOpen,doorT:window.__sim.doorT,dims:window.__state.dimensions,studio:window.__state.studio}));
// 5 обратно на станцию, ливрея classic, панорама
await p.evaluate(()=>{document.getElementById('tgDims').click();document.querySelector('#segMode button[data-mode="station"]').click();document.querySelector('#liveryBox button[data-liv="classic"]').click();});
await sleep(4000);
await p.evaluate(()=>window.__setCam('pano'));await sleep(2500);await shot('pano_classic');
// 6 мобильная раскладка
await p.setViewport({width:390,height:780});await sleep(2500);
await p.evaluate(()=>window.__setCam('hero'));await sleep(2500);await shot('mobile');
const overflow=await p.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,
  dock:document.getElementById('dock').getBoundingClientRect().width,
  cams:document.getElementById('cams').getBoundingClientRect().width}));
await p.evaluate(()=>document.getElementById('btnPanel').click());await sleep(1200);await shot('mobile_panel');
const st2=await p.evaluate(()=>({diag:window.__diag,stats:window.__stats(),renderErr:window.__renderErr||null}));
console.log('STATE1',JSON.stringify(st1));console.log('OVERFLOW',JSON.stringify(overflow));console.log('STATE2',JSON.stringify(st2));
console.log('ERRORS',errs.slice(0,5));
await b.close();})();
