const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=angle', '--use-angle=swiftshader',
      '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl', '--window-size=1440,900']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 1 });
  const logs = [];
  page.on('console', m => logs.push('[' + m.type() + '] ' + m.text()));
  page.on('pageerror', e => logs.push('[PAGEERROR] ' + e.message));
  page.on('requestfailed', r => logs.push('[REQFAIL] ' + r.url()));
  const file = 'file://' + path.join(__dirname, 'moskva-2020.html');
  await page.goto(file, { waitUntil: 'load', timeout: 90000 });
  // ждём скрытия загрузчика
  try {
    await page.waitForFunction(() => {
      const l = document.getElementById('loader');
      return l && (l.classList.contains('done') || l.style.display === 'none');
    }, { timeout: 120000 });
  } catch (e) { logs.push('[TIMEOUT] loader never finished'); }
  await new Promise(r => setTimeout(r, 4000));
  fs.mkdirSync('shots', { recursive: true });
  const shots = process.argv.slice(2);
  const cams = shots.length ? shots : ['hero', 'facade', 'side', 'bogie', 'cab', 'salon', 'pano', 'roof'];
  for (const c of cams) {
    await page.evaluate(k => { window.__setCam && window.__setCam(k); }, c);
    await new Promise(r => setTimeout(r, 2200));
    await page.screenshot({ path: `shots/${c}.png` });
  }
  const stats = await page.evaluate(() => window.__stats ? window.__stats() : null);
  console.log('STATS', JSON.stringify(stats));
  console.log(logs.slice(0, 60).join('\n') || 'no console output');
  await browser.close();
})();
