/* Финальная приёмка: тележка / салон / сброс / смена состава / рейс / мобильный первый экран */
const puppeteer = require('puppeteer'); const path = require('path');
const URL = 'file://' + path.join(__dirname, 'moskva-2020.html') + '?q=low';
const FLAGS = ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];
const wait = ms => new Promise(r => setTimeout(r, ms));
const sync = p => p.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))));
const R = { errors: [] };

async function boot(b, w, h) {
  const p = await b.newPage();
  await p.setViewport({ width: w, height: h });
  p.on('pageerror', e => R.errors.push('PAGEERR ' + e.message));
  p.on('console', m => { const t = m.text(); if (/нет материала|not of type|CONTEXT_LOST|Too many/i.test(t)) R.errors.push('CONSOLE ' + t.slice(0, 140)); });
  await p.goto(URL, { waitUntil: 'load' });
  await p.waitForFunction(() => document.getElementById('loader').classList.contains('done'), { timeout: 180000 });
  await wait(1800);
  return p;
}
const cars = async (p, n) => { await p.evaluate(k => document.querySelector('#segCars button[data-cars="' + k + '"]').click(), n); await wait(2600); };
const hits = p => p.evaluate(() => {
  const T = window.__three, sc = window.__getScene(), cam = window.__cam();
  const vis = o => { let q = o; while (q) { if (!q.visible) return false; q = q.parent; } return true; };
  const rc = new T.Raycaster(); const n = {};
  for (let i = 0; i < 11; i++) for (let j = 0; j < 8; j++) {
    rc.setFromCamera(new T.Vector2(-0.85 + i * 0.17, -0.75 + j * 0.21), cam);
    const h = rc.intersectObjects(sc.children, true).filter(x => x.object.type === 'Mesh' && vis(x.object));
    if (h[0]) { const k = h[0].object.name || '?'; n[k] = (n[k] || 0) + 1; }
  }
  return n;
});
/* виден ли поезд в кадре: доля лучей, попавших в состав */
const trainFrac = p => p.evaluate(() => {
  const T = window.__three, cam = window.__cam();
  const rc = new T.Raycaster(); let hit = 0, tot = 0;
  const g = window.__getScene().children.find(o => o.userData && o.userData.isTrain) || null;
  const cars = []; window.__getScene().traverse(o => { if (o.userData && o.userData.cfg) cars.push(o); });
  for (let i = 0; i < 13; i++) for (let j = 0; j < 9; j++) {
    rc.setFromCamera(new T.Vector2(-0.9 + i * 0.15, -0.8 + j * 0.2), cam);
    tot++; if (rc.intersectObjects(cars, true).length) hit++;
  }
  return +(hit / tot).toFixed(3);
});

(async () => {
  const b = await puppeteer.launch({ headless: 'new', args: FLAGS });
  try {
    const p = await boot(b, 1000, 620);
    await cars(p, 4);
    const shot = async n => { await sync(p); await p.screenshot({ path: 'shots/z_' + n + '.png' }); };

    R.heroFrac = await trainFrac(p); await shot('hero');

    await p.evaluate(() => window.__setCam('bogie')); await wait(2800);
    R.bogieHits = await hits(p); await shot('bogie');

    await p.evaluate(() => window.__setCam('salon')); await wait(2400); await shot('salon');
    await p.evaluate(() => document.querySelector('#segMode button[data-mode="station"]').click()); await wait(2000);
    await p.evaluate(() => window.__setCam('hero')); await wait(2200);

    /* смена состава: поезд обязан остаться у платформы */
    await cars(p, 8); R.frac8 = await trainFrac(p); await shot('cars8');
    await cars(p, 4); R.frac4 = await trainFrac(p); await shot('cars4');

    /* сброс */
    await p.evaluate(() => document.getElementById('btnReset').click()); await wait(3200);
    R.reset = await p.evaluate(() => { const s = window.__stats(); return { phase: s.phase, studio: s.studio, cars: s.cars, q: window.__state.quality }; });
    R.resetFrac = await trainFrac(p); await shot('reset');
    await cars(p, 4);

    /* рейс: короткий подход -> остановка -> двери */
    await p.evaluate(() => { const s = window.__sim; s.x = s.stopX - 7; s.v = 3.2; s.phase = 'approach'; s.tPhase = 0; window.__state.running = true; });
    let ok = false;
    try { await p.waitForFunction(() => window.__sim.phase === 'dwell', { timeout: 120000, polling: 800 }); ok = true; } catch (e) { }
    R.arrived = ok;
    if (ok) { await wait(3500); R.doors = await p.evaluate(() => window.__state.doorsOpen); await shot('arrived'); }

    /* мышь */
    const b0 = await p.evaluate(() => window.__stats().cp);
    await p.mouse.move(400, 300); await p.mouse.down();
    for (let i = 0; i < 10; i++) { await p.mouse.move(400 + i * 15, 300 + i * 3); await wait(35); }
    await p.mouse.up(); await wait(1000);
    R.dragMoved = JSON.stringify(b0) !== JSON.stringify(await p.evaluate(() => window.__stats().cp));
    R.desktop = await p.evaluate(() => ({ diag: window.__diag, err: window.__renderErr, calls: window.__stats().calls }));
    R.desktopOverflow = await p.evaluate(() => [document.documentElement.scrollWidth - document.documentElement.clientWidth, document.documentElement.scrollHeight - document.documentElement.clientHeight]);
    await p.close();

    /* мобильный первый экран */
    const m = await boot(b, 390, 780);
    await cars(m, 4); await sync(m);
    R.mobileDockHidden = await m.evaluate(() => document.getElementById('dock').classList.contains('hidden'));
    R.mobileFrac = await trainFrac(m);
    await m.screenshot({ path: 'shots/z_mobile_first.png' });
    await m.evaluate(() => document.getElementById('btnPanel').click()); await wait(800);
    await m.screenshot({ path: 'shots/z_mobile_panel.png' });
    R.panelScroll = await m.evaluate(() => { const d = document.querySelector('.dock-scroll'); return { fits: d.getBoundingClientRect().bottom <= innerHeight + 1, scrollable: d.scrollHeight > d.clientHeight }; });
    await m.evaluate(() => { document.querySelector('.dock-scroll').scrollTop = 99999; }); await wait(600);
    await m.screenshot({ path: 'shots/z_mobile_panel_end.png' });
    await m.evaluate(() => document.getElementById('btnPanel').click()); await wait(600);
    await m.evaluate(() => window.__setCam('facade')); await wait(2600); await sync(m);
    await m.screenshot({ path: 'shots/z_mobile_facade.png' });
    R.mobile = await p.evaluate ? await m.evaluate(() => ({ diag: window.__diag, err: window.__renderErr })) : null;
    R.mobileOverflow = await m.evaluate(() => [document.documentElement.scrollWidth - document.documentElement.clientWidth, document.documentElement.scrollHeight - document.documentElement.clientHeight]);
    await m.close();
  } catch (e) { R.fatal = String(e && e.message || e); }
  finally { try { await b.close(); } catch (e) { } console.log(JSON.stringify(R, null, 1)); }
})();
