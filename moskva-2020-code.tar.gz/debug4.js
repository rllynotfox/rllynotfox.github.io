const puppeteer=require('puppeteer');const path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:900,height:600});
const out=[];
p.on('console',m=>{const t=m.text(); if(t.startsWith('NANGEOM')||t.startsWith('LINKFAIL')||t.startsWith('FSDEFINES')) out.push(t.slice(0,600));});
p.on('pageerror',e=>out.push('PAGEERROR '+e.message));
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?nancheck&shaderdebug',{waitUntil:'load'});
await new Promise(r=>setTimeout(r,20000));
console.log([...new Set(out)].slice(0,10).join('\n\n'));
await b.close();})();
