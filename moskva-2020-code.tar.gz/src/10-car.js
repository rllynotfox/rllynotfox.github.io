/* ============================================================================
   КУЗОВ ВАГОНА: лофтинг оболочки, боковины с проёмами, двери, лобовая маска
   ========================================================================== */

const NS = 88;                     // точек в поперечном сечении

function ringOf(sec) {
  const pts = [];
  const hh = (sec.yt - sec.yb) / 2, yc = (sec.yt + sec.yb) / 2;
  for (let i = 0; i < NS; i++) {
    const th = i / NS * Math.PI * 2;
    const p = rrPoint(sec.hw, hh, sec.rb, sec.rt, th);
    const y = yc + p[1];
    pts.push(new THREE.Vector3(sec.x - (sec.shear || 0) * (y - sec.yb), y, p[0]));
  }
  return pts;
}

function bodyKey(y, nose, nx) {
  if (nose && nx > 0.30) return 'accent';
  if (y < DIM.sideBot - 0.001) return 'skirt';
  if (y < DIM.bandLowTop) return 'red';
  if (y < DIM.bandUpBot) return 'body';
  if (y < DIM.sideTop) return 'red';
  return 'roof';
}

/* оболочка кузова: секции слева направо */
function buildShell(B, sections, noseFrom) {
  const rings = sections.map(ringOf);
  const pos = { body: [], red: [], roof: [], skirt: [], accent: [] };
  const nrm = { body: [], red: [], roof: [], skirt: [], accent: [] };
  const uvs = { body: [], red: [], roof: [], skirt: [], accent: [] };
  const vA = new THREE.Vector3(), vB = new THREE.Vector3(), vN = new THREE.Vector3();
  for (let j = 0; j < rings.length - 1; j++) {
    const r0 = rings[j], r1 = rings[j + 1];
    const s0 = sections[j], s1 = sections[j + 1];
    const nose = (s0.x >= noseFrom - 1e-6);
    const nearFront = nose && (s1.x > sections[sections.length - 1].x - 0.26);
    for (let i = 0; i < NS; i++) {
      const k = (i + 1) % NS;
      const a = r0[i], b = r0[k], c = r1[i], d = r1[k];
      const ym = (a.y + b.y + c.y + d.y) / 4;
      const zm = (a.z + b.z + c.z + d.z) / 4;
      const flat = Math.abs(Math.abs(zm) - s0.hw) < 0.004 && Math.abs(Math.abs(a.z) - s0.hw) < 0.004
        && Math.abs(Math.abs(b.z) - s0.hw) < 0.004;
      if (!nose && flat && ym > DIM.sideBot + 0.002 && ym < DIM.sideTop - 0.002) continue;
      vA.subVectors(b, a); vB.subVectors(c, a); vN.crossVectors(vA, vB).normalize();
      const outward = new THREE.Vector3(0, ym - (s0.yt + s0.yb) / 2, zm).normalize();
      let flip = vN.dot(outward) < 0;
      if (Math.abs(zm) < 0.05) flip = vN.y * (ym > (s0.yt + s0.yb) / 2 ? 1 : -1) < 0;
      const key = bodyKey(ym, nose && (nearFront || vN.x * (flip ? -1 : 1) > 0.22), 1);
      const P = pos[key], N = nrm[key], U = uvs[key];
      const quad = flip ? [a, c, b, b, c, d] : [a, b, c, b, d, c];
      const nn = flip ? vN.clone().negate() : vN.clone();
      for (const p of quad) {
        P.push(p.x, p.y, p.z); N.push(nn.x, nn.y, nn.z);
        U.push(p.x * 0.22, Math.atan2(p.y - 2.3, p.z) * 0.6);
      }
    }
  }
  for (const key of Object.keys(pos)) {
    if (!pos[key].length) continue;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos[key], 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(nrm[key], 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs[key], 2));
    B.add(key, g);
  }
  return rings;
}

/* матрица лобовой плоскости (локальные u->-Z, v->вверх по наклонной плоскости) */
function frontMatrix(x0, yb, rake) {
  const th = Math.atan(rake);
  const m = new THREE.Matrix4().makeRotationZ(th);
  m.multiply(new THREE.Matrix4().makeRotationY(Math.PI / 2));
  m.setPosition(x0, yb, 0);
  return m;
}
function onFront(B, key, geo, M, off = 0) {
  const g = geo.clone();
  g.translate(0, 0, off);
  return B.add(key, g, M);
}
function plate(w, h, r, t = 0.02) {
  return new THREE.ExtrudeGeometry(roundedRectShape(w, h, r), { depth: t, bevelEnabled: false, curveSegments: 8 });
}
function ringPlate(w, h, r, border, t = 0.012) {
  const s = roundedRectShape(w, h, r);
  s.holes.push(roundedRectPath(w - border * 2, h - border * 2, Math.max(0.01, r - border)));
  return new THREE.ExtrudeGeometry(s, { depth: t, bevelEnabled: false, curveSegments: 8 });
}

/* ------------------------------- конфигурация вагона ---------------------- */
function carConfig(type) {
  const head = type === 'head';
  const half = head ? 9.60 : 9.15;
  const cfg = {
    type, head, half,
    rear: -half, front: half,
    noseStart: head ? half - DIM.noseLen : half,
    doors: head ? [4.90, 0.90, -3.10, -7.10] : [6.50, 2.20, -2.20, -6.50],
    cabWall: head ? 6.55 : null,
    bogies: [-SPECS.carBase / 2, SPECS.carBase / 2],
    motor: type !== 'trailer'
  };
  return cfg;
}

/* окна в промежутках между дверями */
function windowLayout(cfg) {
  const edges = [];
  const ds = cfg.doors.slice().sort((a, b) => a - b);
  let start = cfg.rear + 0.10;
  const gaps = [];
  for (const d of ds) {
    gaps.push([start, d - SPECS.doorW / 2]);
    start = d + SPECS.doorW / 2;
  }
  gaps.push([start, (cfg.head ? cfg.cabWall - 0.05 : cfg.front - 0.10)]);
  const wins = [];
  gaps.forEach((g, gi) => {
    const w = g[1] - g[0];
    if (w < 0.75) return;
    const m = 0.22;
    const isCenter = (!cfg.head && gi === 2);
    if (w > 2.05) {
      const pw = (w - 2 * m - 0.16) / 2;
      wins.push({ x: g[0] + m + pw / 2, w: pw, gap: gi });
      wins.push({ x: g[1] - m - pw / 2, w: pw, gap: gi, display: isCenter });
    } else {
      wins.push({ x: (g[0] + g[1]) / 2, w: w - 2 * m, gap: gi, display: isCenter });
    }
  });
  return wins;
}

/* ---------------------------------- вагон --------------------------------- */
function buildCar(type, L, number) {
  const cfg = carConfig(type);
  const G = new THREE.Group();
  G.name = 'car_' + type + '_' + number;
  const B = new Builder();
  const anim = { doorsL: null, doorsR: null, wheels: [], wiper: null, displays: [] };

  /* --- оболочка --- */
  const sections = [];
  const straightEnd = cfg.noseStart;
  const nStraight = 6;
  for (let i = 0; i <= nStraight; i++) {
    const x = lerp(cfg.rear, straightEnd, i / nStraight);
    sections.push({ x, hw: DIM.hw, yb: DIM.yb, yt: DIM.yt, rb: DIM.rb, rt: DIM.rt });
  }
  if (cfg.head) {
    const steps = 16;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps, e = smoother(t);
      sections.push({
        x: lerp(cfg.noseStart, cfg.front, t),
        hw: lerp(DIM.hw, 1.285, e),
        yb: lerp(DIM.yb, 1.055, e),
        yt: lerp(DIM.yt, 3.545, e),
        rb: lerp(DIM.rb, 0.44, e),
        rt: lerp(DIM.rt, 0.50, e),
        shear: DIM.rake * e
      });
    }
  }
  buildShell(B, sections, cfg.head ? cfg.noseStart : 1e9);

  /* --- торцевые стены --- */
  const endWall = (x, sign) => {
    const s = roundedRectShape(SPECS.width - 0.06, DIM.yt - DIM.yb - 0.06, 0.30, 0, (DIM.yt + DIM.yb) / 2);
    s.holes.push(roundedRectPath(SPECS.gangwayW, 2.10, 0.16, 0, DIM.floorH + 1.05));
    const g = new THREE.ExtrudeGeometry(s, { depth: 0.05, bevelEnabled: false, curveSegments: 8 });
    const m = new THREE.Matrix4().makeRotationY(sign * Math.PI / 2);
    m.setPosition(x, 0, 0);
    B.add('under', g, m);
  };
  endWall(cfg.rear + 0.02, 1);
  if (!cfg.head) endWall(cfg.front - 0.02, -1);

  /* --- боковины с проёмами --- */
  const wins = windowLayout(cfg);
  for (const side of [1, -1]) {
    const shape = new THREE.Shape();
    const x0 = cfg.rear, x1 = cfg.noseStart;
    shape.moveTo(x0, DIM.sideBot); shape.lineTo(x1, DIM.sideBot);
    shape.lineTo(x1, DIM.sideTop); shape.lineTo(x0, DIM.sideTop); shape.closePath();
    for (const d of cfg.doors) shape.holes.push(roundedRectPath(SPECS.doorW, DIM.doorTop - DIM.doorBot, 0.07, d, (DIM.doorTop + DIM.doorBot) / 2));
    for (const w of wins) if (!w.display) shape.holes.push(roundedRectPath(w.w, DIM.winTop - DIM.winBot, 0.09, w.x, (DIM.winTop + DIM.winBot) / 2));
    if (cfg.head) {
      shape.holes.push(roundedRectPath(0.70, 1.50, 0.06, 7.45, 2.05));      // дверь кабины
      shape.holes.push(roundedRectPath(0.52, 0.80, 0.07, 8.16, 2.28));      // окно кабины
    }
    const g = new THREE.ExtrudeGeometry(shape, { depth: 0.055, bevelEnabled: false, curveSegments: 6 });
    const z = side > 0 ? DIM.hw - 0.055 : -DIM.hw;
    B.add('body', g, M4(0, 0, z));

    /* оконные модули */
    for (const w of wins) {
      if (w.display) continue;
      const h = DIM.winTop - DIM.winBot, cy = (DIM.winTop + DIM.winBot) / 2;
      const ring = ringPlate(w.w + 0.18, h + 0.18, 0.13, 0.10, 0.02);
      B.add('band', ring, M4(w.x, cy, side * (DIM.hw - 0.028) - (side > 0 ? 0.02 : 0)));
      const gl = new THREE.ShapeGeometry(roundedRectShape(w.w + 0.02, h + 0.02, 0.09), 6);
      B.add('glass', gl, M4(w.x, cy, side * (DIM.hw - 0.012)));
      if (w.gap % 2 === 0) { // форточка
        B.box('band', w.w + 0.02, 0.045, 0.03, w.x, DIM.winTop - 0.30, side * (DIM.hw - 0.012));
        B.box('steelDark', 0.10, 0.03, 0.03, w.x, DIM.winTop - 0.36, side * (DIM.hw + 0.004));
      }
    }
    /* оконные проёмы кабины */
    if (cfg.head) {
      const ring = ringPlate(0.52 + 0.16, 0.80 + 0.16, 0.12, 0.09, 0.02);
      B.add('band', ring, M4(8.16, 2.28, side * (DIM.hw - 0.028) - (side > 0 ? 0.02 : 0)));
      B.add('glass', new THREE.ShapeGeometry(roundedRectShape(0.54, 0.82, 0.07), 6), M4(8.16, 2.28, side * (DIM.hw - 0.012)));
      // дверь кабины
      const cd = plate(0.68, 1.48, 0.05, 0.04);
      B.add('door', cd, M4(7.45, 2.05, side * (DIM.hw - 0.045)));
      B.add('glass', new THREE.ShapeGeometry(roundedRectShape(0.40, 0.72, 0.05), 6), M4(7.45, 2.38, side * (DIM.hw + 0.002)));
      B.cyl('pole', 0.017, 0.017, 0.62, 8, 7.72, 2.00, side * (DIM.hw + 0.045), [Math.PI / 2, 0, 0]);
      // камера бокового обзора
      B.box('under', 0.20, 0.13, 0.16, 8.42, 2.95, side * (DIM.hw + 0.05));
      B.cyl('mask', 0.045, 0.05, 0.10, 12, 8.42, 2.95, side * (DIM.hw + 0.13), [Math.PI / 2, 0, 0]);
      // зеркальный/камерный кронштейн
      B.box('steelDark', 0.05, 0.05, 0.12, 8.42, 2.95, side * (DIM.hw - 0.02));
    }
    /* красные полосы (нижняя — с разрывами на дверях) */
    const ds = cfg.doors.slice().sort((a, b) => a - b);
    let segs = [], cur = cfg.rear;
    for (const d of ds) { segs.push([cur, d - SPECS.doorW / 2]); cur = d + SPECS.doorW / 2; }
    segs.push([cur, cfg.noseStart]);
    for (const s of segs) {
      const w = s[1] - s[0]; if (w <= 0.02) continue;
      B.box('red', w, DIM.bandLowTop - DIM.bandLowBot, 0.012, (s[0] + s[1]) / 2, (DIM.bandLowTop + DIM.bandLowBot) / 2, side * (DIM.hw + 0.004));
    }
    B.box('red', cfg.noseStart - cfg.rear, DIM.bandUpTop - DIM.bandUpBot, 0.012,
      (cfg.rear + cfg.noseStart) / 2, (DIM.bandUpTop + DIM.bandUpBot) / 2, side * (DIM.hw + 0.004));
    /* капельники над дверями */
    for (const d of cfg.doors) B.box('roof', SPECS.doorW + 0.34, 0.05, 0.09, d, DIM.doorTop + 0.07, side * (DIM.hw + 0.02));
    /* наружные поручни у дверей */
    for (const d of cfg.doors) {
      for (const s of [-1, 1]) {
        B.cyl('pole', 0.018, 0.018, 1.30, 8, d + s * (SPECS.doorW / 2 + 0.13), 2.05, side * (DIM.hw + 0.05));
        B.box('steelDark', 0.05, 0.05, 0.06, d + s * (SPECS.doorW / 2 + 0.13), 2.66, side * (DIM.hw + 0.025));
        B.box('steelDark', 0.05, 0.05, 0.06, d + s * (SPECS.doorW / 2 + 0.13), 1.44, side * (DIM.hw + 0.025));
      }
      // ручка аварийной разблокировки
      B.box('under', 0.10, 0.16, 0.035, d + SPECS.doorW / 2 + 0.30, 1.62, side * (DIM.hw + 0.012));
      B.box('red', 0.055, 0.055, 0.02, d + SPECS.doorW / 2 + 0.30, 1.60, side * (DIM.hw + 0.032));
    }
    /* номер вагона на юбке */
    const numMat = MATS.decal.clone();
    numMat.map = tex(textDecal('№ ' + number, 256, 64, { fg: '#c9ced3', font: 40, weight: 600 }), { clamp: true });
    const nm = new THREE.Mesh(new THREE.PlaneGeometry(0.52, 0.13), numMat);
    nm.position.set(cfg.rear + 1.35, 1.30, side * (DIM.hw + 0.012));
    nm.rotation.y = side > 0 ? 0 : Math.PI;
    G.add(nm);
    /* логотип метро на борту */
    const lmesh = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.46), MATS.dLogo);
    lmesh.position.set(cfg.head ? -1.0 : 0.0, 2.05, side * (DIM.hw + 0.012));
    lmesh.rotation.y = side > 0 ? 0 : Math.PI;
    G.add(lmesh);
    /* бортовая графика */
    if (MATS.dGraphic) {
      const gx = cfg.head ? -5.1 : -4.35;
      const gmesh = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 1.1), MATS.dGraphic);
      gmesh.position.set(gx, 2.25, side * (DIM.hw + 0.011));
      gmesh.rotation.y = side > 0 ? 0 : Math.PI;
      G.add(gmesh);
    }
    /* надпись МОСКВА на верхней полосе головного вагона */
    if (cfg.head) {
      const msh = new THREE.Mesh(new THREE.PlaneGeometry(1.55, 0.20), MATS.dMoskva);
      msh.position.set(5.55, 3.235, side * (DIM.hw + 0.014));
      msh.rotation.y = side > 0 ? 0 : Math.PI;
      G.add(msh);
    }
    /* внешнее информационное табло */
    const dw = wins.find(w => w.display);
    if (dw) {
      const fw = dw.w, fh = 0.42;
      B.add('band', plate(fw + 0.10, fh + 0.10, 0.06, 0.03), M4(dw.x, 2.46, side * (DIM.hw - 0.03) - (side > 0 ? 0.03 : 0)));
      const dmesh = new THREE.Mesh(new THREE.PlaneGeometry(fw, fh * 0.72), MATS.dDisplay);
      dmesh.position.set(dw.x, 2.46, side * (DIM.hw + 0.004));
      dmesh.rotation.y = side > 0 ? 0 : Math.PI;
      G.add(dmesh);
      anim.displays.push(dmesh);
      // нижняя часть окна под табло
      B.add('glass', new THREE.ShapeGeometry(roundedRectShape(fw, 0.44, 0.05), 6), M4(dw.x, 1.98, side * (DIM.hw - 0.012)));
      B.add('band', ringPlate(fw + 0.16, 0.60, 0.10, 0.09, 0.02), M4(dw.x, 1.98, side * (DIM.hw - 0.028) - (side > 0 ? 0.02 : 0)));
    }
  }

  /* --- двери (створки) --- */
  buildDoors(cfg, G, anim, L);

  /* --- лобовая маска --- */
  if (cfg.head) buildFront(cfg, B, G, anim, L);

  /* --- крыша, подкузовное оборудование, тележки, салон --- */
  buildRoof(cfg, B, G);
  buildUnderframe(cfg, B, G, number);
  anim.wheels = buildBogies(cfg, B, G);
  buildInterior(cfg, G, L, anim);

  B.flush(MATS, G);
  G.add(contactShadow(cfg.noseStart - cfg.rear + 1.0));
  G.userData = { cfg, anim, type, number };
  return G;
}

/* --------------------------------- двери ---------------------------------- */
function buildDoors(cfg, G, anim, L) {
  const leafW = SPECS.doorW / 2 - 0.012;
  const leafH = DIM.doorTop - DIM.doorBot - 0.02;
  const cy = (DIM.doorTop + DIM.doorBot) / 2;
  for (const side of [1, -1]) {
    for (const dir of [-1, 1]) {
      const B = new Builder();
      for (const d of cfg.doors) {
        const cx = d + dir * (SPECS.doorW / 4);
        const zOut = side * (DIM.hw - 0.005);
        // рама створки
        const frame = roundedRectShape(leafW, leafH, 0.05);
        frame.holes.push(roundedRectPath(leafW - 0.16, 1.06, 0.06, 0, 0.30));
        B.add('door', new THREE.ExtrudeGeometry(frame, { depth: 0.045, bevelEnabled: false, curveSegments: 6 }),
          M4(cx, cy, zOut - side * 0.045));
        // стекло
        B.add('glass', new THREE.ShapeGeometry(roundedRectShape(leafW - 0.14, 1.08, 0.06), 6), M4(cx, cy + 0.30, zOut - side * 0.018));
        // нижняя окрашенная часть
        B.box('body', leafW - 0.02, 0.42, 0.05, cx, DIM.doorBot + 0.24, zOut - side * 0.025);
        B.box('red', leafW - 0.02, DIM.bandLowTop - DIM.bandLowBot, 0.052, cx, (DIM.bandLowTop + DIM.bandLowBot) / 2, zOut - side * 0.024);
        // красная кромка по стыку створок
        B.box('red', 0.045, leafH - 0.06, 0.055, cx - dir * (leafW / 2 - 0.022), cy, zOut - side * 0.022);
        B.box('rubber', 0.022, leafH - 0.04, 0.06, cx - dir * (leafW / 2 - 0.002), cy, zOut - side * 0.02);
        // наружный поручень
        B.cyl('pole', 0.017, 0.017, 1.02, 8, cx + dir * (leafW / 2 - 0.10), 2.05, zOut + side * 0.045);
        B.box('steelDark', 0.04, 0.04, 0.05, cx + dir * (leafW / 2 - 0.10), 2.54, zOut + side * 0.022);
        B.box('steelDark', 0.04, 0.04, 0.05, cx + dir * (leafW / 2 - 0.10), 1.56, zOut + side * 0.022);
        // пиктограмма «инвалидная коляска» на первой двери
        if (d === cfg.doors[0] && dir === -1) {
          const wmesh = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.22), MATS.dWheel);
          wmesh.position.set(cx, 1.62, zOut + side * 0.004);
          wmesh.rotation.y = side > 0 ? 0 : Math.PI;
          G.add(wmesh);
          wmesh.userData.doorSide = dir;
        }
      }
      const grp = new THREE.Group();
      B.flush(MATS, grp, { cast: true, receive: true });
      grp.userData = { dir, side, base: 0 };
      G.add(grp);
      if (dir < 0) anim.doorsL = grp; else anim.doorsR = grp;
      if (side < 0) { (dir < 0 ? anim.doorsL2 = grp : anim.doorsR2 = grp); }
    }
  }
  // пороги
  const B = new Builder();
  for (const side of [1, -1]) for (const d of cfg.doors) {
    B.box('steelDark', SPECS.doorW + 0.06, 0.03, 0.14, d, DIM.floorH - 0.01, side * (DIM.hw - 0.06));
    B.box('ledWarm', SPECS.doorW - 0.10, 0.012, 0.02, d, DIM.doorTop - 0.03, side * (DIM.hw - 0.09));
  }
  B.flush(MATS, G);
}

/* ------------------------------ лобовая маска ------------------------------ */
function buildFront(cfg, B, G, anim, L) {
  const th = Math.atan(DIM.rake), cs = Math.cos(th);
  const yb = 1.055, yt = 3.545, X0 = cfg.front;
  const M = frontMatrix(X0, yb, DIM.rake);
  const V = (yt - yb) / cs;                       // высота маски в её плоскости
  const W = 2 * 1.285;
  const cv = V / 2;

  const gw = 1.00, gh = 1.08, gv = V - 1.06;         // лобовые стёкла
  // внешняя рамка (цвет ливреи) — кольцо, не глухая плита
  B.add('accent', ringPlate(W, V, 0.47, 0.14, 0.06), M.clone().multiply(M4(0, cv, -0.06)));
  // чёрная маска с вырезами под лобовые стёкла
  const mw = W - 0.26, mh = V - 0.26;
  const maskShape = roundedRectShape(mw, mh, 0.37, 0, cv);
  for (const s of [-1, 1]) maskShape.holes.push(roundedRectPath(gw, gh, 0.10, s * (gw / 2 + 0.062), gv));
  B.add('mask', new THREE.ExtrudeGeometry(maskShape, { depth: 0.05, bevelEnabled: false, curveSegments: 8 }),
    M.clone().multiply(M4(0, 0, 0.002)));

  // маршрутное табло
  const dv = V - 0.30;
  B.add('band', plate(1.92, 0.30, 0.05, 0.03), M.clone().multiply(M4(0, dv, 0.045)));
  const routeGeo = new THREE.PlaneGeometry(1.86, 0.24);
  routeGeo.translate(0, dv, 0.092); routeGeo.applyMatrix4(M);
  const routeMesh = new THREE.Mesh(routeGeo, MATS.dRoute);
  G.add(routeMesh);
  anim.routeDisplay = routeMesh;
  // разделитель номера маршрута
  B.add('ledWhite', new THREE.BoxGeometry(0.014, 0.19, 0.012), M.clone().multiply(M4(-0.58, dv, 0.095)));

  // лобовые стёкла (две половины)
  for (const s of [-1, 1]) {
    const u = s * (gw / 2 + 0.062);
    const gasket = ringPlate(gw + 0.10, gh + 0.10, 0.13, 0.07, 0.03);
    const gm = M.clone().multiply(M4(u, gv, 0.03));
    B.add('rubber', gasket, gm);
    const glass = new THREE.ShapeGeometry(roundedRectShape(gw, gh, 0.10), 8);
    B.add('glassFront', glass, M.clone().multiply(M4(u, gv, 0.038)));
  }
  // центральная стойка
  B.add('mask', plate(0.15, gh + 0.16, 0.05, 0.07), M.clone().multiply(M4(0, gv, 0.035)));

  // световые модули
  for (const s of [-1, 1]) {
    const u = s * (W / 2 - 0.235);
    B.add('ledWhite', plate(0.115, 0.50, 0.05, 0.02), M.clone().multiply(M4(u, V - 0.72, 0.055)));
    B.add('ledWhite', plate(0.115, 0.62, 0.05, 0.02), M.clone().multiply(M4(u, 0.72, 0.055)));
    B.add('mask', plate(0.20, 0.56, 0.07, 0.05), M.clone().multiply(M4(u, V - 1.32, 0.045)));
    for (const dy of [0.135, -0.135]) {
      B.add('steelDark', new THREE.CylinderGeometry(0.072, 0.078, 0.05, 18),
        M.clone().multiply(M4(u, V - 1.32 + dy, 0.075)).multiply(new THREE.Matrix4().makeRotationX(Math.PI / 2)));
      const lamp = new THREE.Mesh(new THREE.CircleGeometry(0.058, 20), MATS.ledWhite.clone());
      lamp.geometry.applyMatrix4(M.clone().multiply(M4(u, V - 1.32 + dy, 0.102)));
      lamp.userData.headlamp = true;
      G.add(lamp);
      (anim.headlamps || (anim.headlamps = [])).push(lamp);
    }
  }

  // логотип метрополитена (подсветка)
  const logo = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.34), MATS.dFrontLogo.clone());
  logo.geometry.applyMatrix4(M.clone().multiply(M4(0, 0.62, 0.082)));
  G.add(logo);
  anim.frontLogo = logo;
  B.add('band', plate(0.44, 0.44, 0.07, 0.018), M.clone().multiply(M4(0, 0.62, 0.055)));

  // блок номера маршрута слева внизу + датчики
  B.add('band', plate(0.26, 0.14, 0.03, 0.02), M.clone().multiply(M4(-0.72, 0.30, 0.05)));
  for (const s of [-1, 1]) B.add('mask', plate(0.10, 0.06, 0.02, 0.02), M.clone().multiply(M4(s * 0.30, V - 0.52, 0.05)));

  // стеклоочиститель
  const wiper = new THREE.Group();
  const armB = new Builder();
  armB.box('rubber', 0.035, 0.60, 0.025, 0, 0.30, 0);
  armB.box('rubber', 0.02, 0.46, 0.045, 0.02, 0.52, 0.02);
  armB.cyl('steelDark', 0.035, 0.035, 0.05, 12, 0, 0, 0, [Math.PI / 2, 0, 0]);
  armB.flush(MATS, wiper, { cast: false });
  wiper.applyMatrix4(M.clone().multiply(M4(0.60, gv - gh / 2 - 0.02, 0.075)));
  wiper.userData.baseM = M.clone().multiply(M4(0.60, gv - gh / 2 - 0.02, 0.075));
  G.add(wiper);
  anim.wiper = wiper;

  // нижняя юбка лобовой части
  B.add('skirt', plate(2.52, 0.56, 0.16, 0.26), M.clone().multiply(M4(0, -0.26, -0.26)));
  B.box('underDark', 1.24, 0.40, 0.30, cfg.front - 0.22, 0.74, 0);
  for (const sx of [-1, 1]) B.box('under', 0.42, 0.16, 0.22, cfg.front - 0.26, 0.60, sx * 0.86);
  // ниша автосцепки и автосцепка
  const cp = new Builder();
  cp.box('steelDark', 0.42, 0.30, 0.34, cfg.front + 0.16, 0.72, 0);
  cp.box('under', 0.30, 0.42, 0.46, cfg.front + 0.40, 0.72, 0);
  cp.cyl('steelDark', 0.09, 0.09, 0.5, 12, cfg.front - 0.15, 0.72, 0, [0, 0, Math.PI / 2]);
  for (const s of [-1, 1]) {
    cp.cyl('rubber', 0.035, 0.035, 0.42, 8, cfg.front + 0.05, 0.55, s * 0.28, [0, 0, Math.PI / 2 + 0.25]);
    cp.cyl('rubber', 0.03, 0.03, 0.40, 8, cfg.front + 0.05, 0.92, s * 0.30, [0, 0, Math.PI / 2 - 0.2]);
  }
  cp.flush(MATS, G);
  // ступени под маской
  B.box('under', 0.9, 0.05, 0.28, cfg.front - 0.42, 0.52, 0);
}
