/* ============================================================================
   СОСТАВ И СТАНЦИЯ
   ========================================================================== */

const CONSISTS = {
  4: ['head', 'trailer', 'motor', 'head'],
  6: ['head', 'trailer', 'motor', 'motor', 'trailer', 'head'],
  8: ['head', 'trailer', 'motor', 'motor', 'motor', 'motor', 'trailer', 'head']
};

let trainGroup = null, trainCars = [], trainLen = 0;

function disposeGroup(g) {
  const shared = new Set(Object.values(MATS));
  g.traverse(o => {
    if (o.geometry) o.geometry.dispose();
    const ms = Array.isArray(o.material) ? o.material : [o.material];
    for (const m of ms) {
      if (!m || shared.has(m)) continue;
      for (const k of ['map', 'normalMap', 'roughnessMap', 'emissiveMap', 'alphaMap']) if (m[k]) m[k].dispose();
      m.dispose();
    }
  });
  if (g.parent) g.parent.remove(g);
}

function buildTrain() {
  if (trainGroup) disposeGroup(trainGroup);
  const L = LIVERIES[state.livery];
  buildMaterials(L);
  if (scene.environment) scene.environment = envTex;
  trainGroup = new THREE.Group();
  trainCars = [];
  const types = CONSISTS[state.cars];
  const lens = types.map(t => t === 'head' ? SPECS.headLen : SPECS.midLen);
  const xs = [0];
  for (let i = 1; i < types.length; i++) xs.push(xs[i - 1] - (lens[i - 1] + lens[i]) / 2);
  const frontX = xs[0] + lens[0] / 2, rearX = xs[xs.length - 1] - lens[lens.length - 1] / 2;
  const mid = (frontX + rearX) / 2;
  trainLen = frontX - rearX;
  const base = 75000 + (state.livery === 'bkl' ? 300 : state.livery === 'm2024' ? 420 : 100);
  let nm = 0, nt = 0;
  types.forEach((t, i) => {
    const number = t === 'head' ? base + (i === 0 ? 1 : 2) : t === 'motor' ? 76000 + (++nm) + 300 : 77000 + (++nt) + 300;
    const car = buildCar(t, L, number);
    car.position.x = xs[i] - mid;
    if (i === types.length - 1) car.rotation.y = Math.PI;
    trainGroup.add(car);
    trainCars.push(car);
    if (i < types.length - 1) {
      const hA = t === 'head' ? 9.60 : 9.15;
      const hB = types[i + 1] === 'head' ? 9.60 : 9.15;
      const xa = xs[i + 1] + hB - mid, xb = xs[i] - hA - mid;
      trainGroup.add(buildGangway(xa, xb, L));
    }
  });
  trainGroup.position.set(sim.x, 0, TRACK_Z);
  scene.add(trainGroup);
  applyLighting();
  updateDoorTargets(true);
}

/* ------------------------------ станция ----------------------------------- */
const TRACK_Z = 2.60;
const HALL = 84, PLAT = 81;
const PLAT_EDGE = TRACK_Z + 1.58;
const PLAT_W = 7.4;
const PLAT_Y = 1.10;
const CEIL_Y = 5.45;
let stationGroup = null, stationLights = [], ringMesh = null, dust = null;

function graniteTexture() {
  const c = cvs(512, 512), g = c.getContext('2d');
  g.fillStyle = '#9a9a97'; g.fillRect(0, 0, 512, 512);
  const S = { s: 4242 };
  for (let i = 0; i < 26000; i++) {
    const x = rnd(S) * 512, y = rnd(S) * 512, r = rnd(S) * 2.4;
    const v = rnd(S);
    g.fillStyle = v < 0.35 ? 'rgba(60,60,62,0.5)' : v < 0.7 ? 'rgba(210,210,208,0.45)' : 'rgba(140,138,132,0.4)';
    g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  g.strokeStyle = 'rgba(58,58,60,0.55)'; g.lineWidth = 2.5;
  for (let i = 0; i <= 4; i++) {
    g.beginPath(); g.moveTo(i * 128, 0); g.lineTo(i * 128, 512); g.stroke();
    g.beginPath(); g.moveTo(0, i * 128); g.lineTo(512, i * 128); g.stroke();
  }
  return c;
}
function concreteTexture() {
  const c = cvs(256, 256), g = c.getContext('2d');
  g.fillStyle = '#3a3c3e'; g.fillRect(0, 0, 256, 256);
  const S = { s: 991 };
  for (let i = 0; i < 9000; i++) {
    const v = rnd(S);
    g.fillStyle = `rgba(${v < 0.5 ? '20,20,22' : '90,90,92'},${0.15 + rnd(S) * 0.3})`;
    g.beginPath(); g.arc(rnd(S) * 256, rnd(S) * 256, rnd(S) * 3, 0, 7); g.fill();
  }
  return c;
}

let stationLivery = null;
function buildStation(force) {
  // станция зависит только от ливреи — не пересобираем её при смене состава
  if (stationGroup && !force && stationLivery === state.livery) return;
  stationLivery = state.livery;
  if (stationGroup) disposeGroup(stationGroup);
  if (dust) { scene.remove(dust); dust.geometry.dispose(); dust.material.dispose(); dust = null; }
  stationGroup = new THREE.Group();
  const L = LIVERIES[state.livery];
  const gran = tex(graniteTexture(), { repeat: [60, 5] });
  const conc = tex(concreteTexture(), { repeat: [80, 4] });
  const SM = {
    plat: new THREE.MeshStandardMaterial({ map: gran, roughness: 0.42, metalness: 0.05, envMapIntensity: 0.6 }),
    platEdge: new THREE.MeshStandardMaterial({ color: 0x4a4d50, roughness: 0.7 }),
    wall: new THREE.MeshStandardMaterial({ color: 0xc6c9cb, roughness: 0.55, metalness: 0.08, envMapIntensity: 0.55 }),
    wallRib: new THREE.MeshStandardMaterial({ color: 0xe6e8e9, roughness: 0.38, metalness: 0.22, envMapIntensity: 0.8 }),
    column: new THREE.MeshStandardMaterial({ color: 0xdedfe0, roughness: 0.30, metalness: 0.30, envMapIntensity: 0.9 }),
    ceil: new THREE.MeshStandardMaterial({ color: 0x9fa3a6, roughness: 0.65, metalness: 0.05 }),
    bed: new THREE.MeshStandardMaterial({ map: conc, color: 0x8a8a8a, roughness: 0.95 }),
    rail: new THREE.MeshStandardMaterial({ color: 0x9aa0a6, roughness: 0.22, metalness: 1.0, envMapIntensity: 1.2 }),
    railWeb: new THREE.MeshStandardMaterial({ color: 0x6a5f55, roughness: 0.72, metalness: 0.7 }),
    sleeper: new THREE.MeshStandardMaterial({ color: 0x6e7073, roughness: 0.92 }),
    yellow: new THREE.MeshStandardMaterial({ color: 0xd8b23a, roughness: 0.6 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x2a2c2f, roughness: 0.8 }),
    strip: new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff1dd, emissiveIntensity: 2.6, roughness: 0.5, toneMapped: false }),
    ring: new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff4e6, emissiveIntensity: 3.4, roughness: 0.4, toneMapped: false }),
    tunnel: new THREE.MeshStandardMaterial({ color: 0x121417, roughness: 0.98, side: THREE.BackSide, envMapIntensity: 0.15 }),
    tactile: new THREE.MeshStandardMaterial({ color: 0xd9b53c, roughness: 0.7 }),
    glassPanel: new THREE.MeshPhysicalMaterial({ color: 0x101418, roughness: 0.15, metalness: 0.2, clearcoat: 1 }),
    steelDark: new THREE.MeshStandardMaterial({ color: 0x6d747c, roughness: 0.42, metalness: 0.9 }),
    ledRed: new THREE.MeshStandardMaterial({ color: 0x330000, emissive: 0xff5a20, emissiveIntensity: 2.0, roughness: 0.5, toneMapped: false })
  };
  stationGroup.userData.SM = SM;
  const B = new Builder();

  /* путь */
  for (const tz of [TRACK_Z, -TRACK_Z]) {
    B.box('bed', 2 * HALL + 120, 0.6, 4.6, 0, -0.55, tz);
    for (const s of [-1, 1]) {
      const rz = tz + s * SPECS.gauge / 2;
      B.box('railWeb', 2 * HALL + 120, 0.13, 0.03, 0, -0.10, rz);
      B.box('rail', 2 * HALL + 120, 0.045, 0.075, 0, -0.022, rz);
      B.box('railWeb', 2 * HALL + 120, 0.03, 0.15, 0, -0.175, rz);
    }
    // контактный рельс с жёлтым кожухом
    const cz = tz - 1.30;
    B.box('railWeb', 2 * HALL + 120, 0.14, 0.09, 0, 0.10, cz);
    B.box('yellow', 2 * HALL + 120, 0.05, 0.26, 0, 0.22, cz);
    for (let x = -HALL - 40; x < HALL + 40; x += 3.2) {
      B.box('dark', 0.12, 0.30, 0.16, x, 0.02, cz);
      B.box('yellow', 0.16, 0.10, 0.30, x, 0.24, cz);
    }
    // лотки и кабели
    B.box('dark', 2 * HALL + 120, 0.10, 0.30, 0, -0.20, tz + 1.85);
  }
  /* шпалы */
  const sleeperGeo = new THREE.BoxGeometry(0.26, 0.18, 2.5);
  const nS = Math.floor((2 * HALL + 120) / 0.58);
  const sleepers = new THREE.InstancedMesh(sleeperGeo, SM.sleeper, nS * 2);
  sleepers.receiveShadow = true; sleepers.castShadow = false;
  let si = 0;
  for (const tz of [TRACK_Z, -TRACK_Z]) {
    for (let i = 0; i < nS; i++) {
      const x = -HALL - 60 + i * 0.58;
      sleepers.setMatrixAt(si++, M4(x, -0.24, tz));
    }
  }
  sleepers.instanceMatrix.needsUpdate = true;
  stationGroup.add(sleepers);

  /* платформы */
  for (const s of [1, -1]) {
    const zc = s * (PLAT_EDGE + PLAT_W / 2);
    B.box('plat', 2 * PLAT, 0.12, PLAT_W, 0, PLAT_Y - 0.06, zc);
    B.box('platEdge', 2 * PLAT, PLAT_Y + 0.35, 0.22, 0, (PLAT_Y - 0.35) / 2, s * (PLAT_EDGE + 0.11));
    B.box('tactile', 2 * PLAT, 0.02, 0.42, 0, PLAT_Y + 0.005, s * (PLAT_EDGE + 0.34));
    B.box('wall', 2 * PLAT, 0.02, 0.10, 0, PLAT_Y + 0.005, s * (PLAT_EDGE + 0.62));
    // стена за платформой
    B.box('wall', 2 * HALL, CEIL_Y + 1.2, 0.35, 0, (CEIL_Y - 1.2) / 2, s * (PLAT_EDGE + PLAT_W + 0.17));
    // путевая стена под платформой
    B.box('dark', 2 * HALL, 1.0, 0.10, 0, 0.35, s * (PLAT_EDGE + 0.02));
  }
  /* рёбра стен */
  const ribGeo = new THREE.BoxGeometry(0.13, CEIL_Y - PLAT_Y - 0.2, 0.10);
  const nR = Math.floor(2 * PLAT / 0.30);
  const ribs = new THREE.InstancedMesh(ribGeo, SM.wallRib, nR * 2);
  ribs.castShadow = false; ribs.receiveShadow = true;
  let ri = 0;
  for (const s of [1, -1]) for (let i = 0; i < nR; i++) {
    ribs.setMatrixAt(ri++, M4(-PLAT + i * 0.30, PLAT_Y + (CEIL_Y - PLAT_Y) / 2 - 0.1, s * (PLAT_EDGE + PLAT_W - 0.02)));
  }
  ribs.instanceMatrix.needsUpdate = true;
  stationGroup.add(ribs);

  /* колонны между путями */
  for (let x = -PLAT + 4; x <= PLAT - 4; x += 4.4) {
    B.box('column', 1.15, CEIL_Y + 0.6, 1.15, x, (CEIL_Y - 0.6) / 2, 0);
    B.box('dark', 1.28, 0.45, 1.28, x, -0.05, 0);
    B.box('column', 1.35, 0.22, 1.35, x, CEIL_Y - 0.16, 0);
    B.box('steelDark', 1.20, 0.06, 1.20, x, 1.30, 0);
  }
  /* потолок */
  B.box('ceil', 2 * HALL, 0.30, 2 * (PLAT_EDGE + PLAT_W) + 1, 0, CEIL_Y + 0.15, 0);
  for (const z of [TRACK_Z, -TRACK_Z, PLAT_EDGE + 3.4, -(PLAT_EDGE + 3.4)]) {
    B.box('ceil', 2 * PLAT, 0.16, 1.10, 0, CEIL_Y - 0.06, z);
    B.box('strip', 2 * PLAT - 2, 0.05, 0.34, 0, CEIL_Y - 0.15, z);
  }
  /* кольцевые светильники */
  const ringGeo = new THREE.TorusGeometry(0.86, 0.055, 8, 40);
  const ringPos = [];
  for (const s of [1, -1]) for (let x = -PLAT + 6; x <= PLAT - 6; x += 8.2) ringPos.push([x, s * (PLAT_EDGE + 3.4)]);
  ringMesh = new THREE.InstancedMesh(ringGeo, SM.ring, ringPos.length);
  ringPos.forEach((p, i) => {
    ringMesh.setMatrixAt(i, M4(p[0], CEIL_Y - 0.75, p[1], Math.PI / 2, 0, 0));
  });
  ringMesh.instanceMatrix.needsUpdate = true;
  stationGroup.add(ringMesh);
  const cableB = new Builder();
  for (const p of ringPos) for (const d of [-0.5, 0.5]) cableB.cyl('dark', 0.012, 0.012, 0.62, 5, p[0] + d, CEIL_Y - 0.44, p[1]);
  cableB.flush(SM, stationGroup, { cast: false });

  /* указатели станции */
  const signTex = tex(stationSign(L), { clamp: true });
  const signMat = new THREE.MeshStandardMaterial({ map: signTex, roughness: 0.5, emissive: 0xffffff, emissiveMap: signTex, emissiveIntensity: 0.22 });
  for (const s of [1, -1]) for (let x = -PLAT + 12; x <= PLAT - 12; x += 24) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 1.0), signMat);
    m.position.set(x, 3.05, s * (PLAT_EDGE + PLAT_W - 0.10));
    m.rotation.y = s > 0 ? Math.PI : 0;
    stationGroup.add(m);
  }
  /* скамьи, урны, стойки */
  for (const s of [1, -1]) for (let x = -PLAT + 16; x <= PLAT - 16; x += 27) {
    const z = s * (PLAT_EDGE + PLAT_W - 1.2);
    B.box('dark', 2.0, 0.10, 0.55, x, PLAT_Y + 0.45, z);
    B.box('steelDark', 0.10, 0.45, 0.5, x - 0.85, PLAT_Y + 0.22, z);
    B.box('steelDark', 0.10, 0.45, 0.5, x + 0.85, PLAT_Y + 0.22, z);
    B.box('dark', 0.55, 0.85, 0.55, x + 2.2, PLAT_Y + 0.42, z);
    B.box('steelDark', 0.60, 0.06, 0.60, x + 2.2, PLAT_Y + 0.86, z);
    // навигационная стойка
    B.box('dark', 0.14, 2.4, 0.5, x - 3.0, PLAT_Y + 1.2, z);
    B.box('glassPanel', 0.06, 1.0, 0.42, x - 3.08, PLAT_Y + 1.9, z);
  }
  /* пассажиры на платформе */
  ensurePeopleMats();
  const PB = new Builder();
  for (const s of [1, -1]) for (let i = 0; i < 15; i++) {
    const x = rr(-PLAT + 8, PLAT - 26);
    const z = s * (PLAT_EDGE + rr(2.3, PLAT_W - 1.3));
    person(PB, x, PLAT_Y, z, false, -s, (R() * 6) | 0);
  }
  PB.flush(MATS, stationGroup, { cast: true, receive: true });

  /* порталы тоннелей */
  for (const e of [-1, 1]) {
    const x = e * HALL;
    const wallShape = new THREE.Shape();
    wallShape.moveTo(-(PLAT_EDGE + PLAT_W) - 1, -1.0);
    wallShape.lineTo((PLAT_EDGE + PLAT_W) + 1, -1.0);
    wallShape.lineTo((PLAT_EDGE + PLAT_W) + 1, CEIL_Y + 0.3);
    wallShape.lineTo(-(PLAT_EDGE + PLAT_W) - 1, CEIL_Y + 0.3);
    wallShape.closePath();
    for (const tz of [TRACK_Z, -TRACK_Z]) {
      const hole = new THREE.Path();
      const r = 2.55, cy = 1.05;
      hole.moveTo(tz - r, -0.9); hole.lineTo(tz + r, -0.9);
      hole.lineTo(tz + r, cy); hole.absarc(tz, cy, r, 0, Math.PI, false);
      hole.lineTo(tz - r, -0.9);
      wallShape.holes.push(hole);
    }
    const wg = new THREE.ExtrudeGeometry(wallShape, { depth: 1.2, bevelEnabled: false, curveSegments: 14 });
    B.add('wall', wg, M4(x - (e > 0 ? 0 : 1.2), 0, 0, 0, Math.PI / 2, 0));
    // тоннель за порталом
    for (const tz of [TRACK_Z, -TRACK_Z]) {
      const tg = new THREE.CylinderGeometry(2.62, 2.62, 70, 22, 1, true);
      B.add('tunnel', tg, M4(x + e * 35, 1.05, tz, 0, 0, Math.PI / 2));
      for (let i = 0; i < 22; i++) {
        const rx = x + e * (2 + i * 3.1);
        const rg = new THREE.TorusGeometry(2.60, 0.075, 5, 22);
        B.add('dark', rg, M4(rx, 1.05, tz, 0, Math.PI / 2, 0));
        if (i % 3 === 0) B.box('ledRed', 0.06, 0.14, 0.06, rx, 2.6, tz + 2.3);
      }
    }
  }
  B.flush(SM, stationGroup, { cast: true, receive: true });
  stationGroup.traverse(o => { if (o.isMesh && o.material === SM.strip) o.castShadow = false; });
  scene.add(stationGroup);

  /* пыль в воздухе */
  const N = 900;
  const pg = new THREE.BufferGeometry();
  const pp = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) {
    pp[i * 3] = rr(-60, 60); pp[i * 3 + 1] = rr(0.3, 5.0); pp[i * 3 + 2] = rr(-10, 12);
  }
  pg.setAttribute('position', new THREE.BufferAttribute(pp, 3));
  dust = new THREE.Points(pg, new THREE.PointsMaterial({
    color: 0xffe9cc, size: 0.022, transparent: true, opacity: 0.42, depthWrite: false,
    blending: THREE.AdditiveBlending, sizeAttenuation: true
  }));
  scene.add(dust);
}

function stationSign(L) {
  const c = cvs(1024, 232), g = c.getContext('2d');
  g.fillStyle = '#f2f3f4'; g.fillRect(0, 0, 1024, 232);
  g.fillStyle = L.lineColor; g.beginPath(); g.arc(96, 116, 62, 0, 7); g.fill();
  g.fillStyle = '#ffffff'; g.font = '700 68px "Segoe UI", Arial, sans-serif';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(L.line, 96, 120);
  g.fillStyle = '#16181c'; g.textAlign = 'left';
  g.font = '700 84px "Segoe UI", Arial, sans-serif';
  g.fillText(L.station, 190, 118);
  g.fillStyle = '#8a8f95'; g.fillRect(0, 226, 1024, 6);
  return c;
}

/* --------------------------- студийная площадка ---------------------------- */
let studioGroup = null;
function buildStudio() {
  if (studioGroup) return;
  studioGroup = new THREE.Group();
  const B = new Builder();
  const SM = {
    floor: new THREE.MeshPhysicalMaterial({ color: 0x0e1216, roughness: 0.34, metalness: 0.30, clearcoat: 0.5, clearcoatRoughness: 0.35, envMapIntensity: 0.7 }),
    plinth: new THREE.MeshStandardMaterial({ color: 0x14181d, roughness: 0.7, metalness: 0.2 }),
    rail: new THREE.MeshStandardMaterial({ color: 0x9aa0a6, roughness: 0.24, metalness: 1.0 }),
    tie: new THREE.MeshStandardMaterial({ color: 0x2a2e33, roughness: 0.9 }),
    glow: new THREE.MeshBasicMaterial({ color: 0x1b2b3a, toneMapped: false })
  };
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(420, 220), SM.floor);
  floor.rotation.x = -Math.PI / 2; floor.position.y = -0.42; floor.receiveShadow = true;
  studioGroup.add(floor);
  B.box('plinth', 200, 0.30, 4.4, 0, -0.28, 0);
  for (const s of [-1, 1]) {
    B.box('rail', 200, 0.05, 0.075, 0, -0.022, s * SPECS.gauge / 2);
    B.box('plinth', 200, 0.14, 0.03, 0, -0.10, s * SPECS.gauge / 2);
  }
  for (let x = -100; x < 100; x += 0.58) B.box('tie', 0.26, 0.14, 2.5, x, -0.20, 0);
  B.flush(SM, studioGroup, { cast: false, receive: true });
  // светящиеся полосы-«софтбоксы» по бокам (читаются в отражениях кузова)
  for (const s of [-1, 1]) {
    const bar = new THREE.Mesh(new THREE.PlaneGeometry(150, 1.2), new THREE.MeshBasicMaterial({ color: 0x8fb4d8, toneMapped: false, side: THREE.DoubleSide }));
    bar.position.set(-10, 6.2, s * 13); bar.rotation.x = Math.PI / 2.4; bar.rotation.z = 0;
    bar.lookAt(0, 2, 0);
    studioGroup.add(bar);
  }
  studioGroup.visible = false;
  scene.add(studioGroup);
}
function applyMode() {
  buildStudio();
  const st = state.studio;
  if (stationGroup) stationGroup.visible = !st;
  if (studioGroup) studioGroup.visible = st;
  if (dust) dust.visible = !st;
  if (trainGroup) trainGroup.position.z = st ? 0 : TRACK_Z;
  scene.fog.density = st ? 0.0042 : (0.0016 + state.fog * 0.014);
  for (const p of platformLights) p.visible = !st;
}
