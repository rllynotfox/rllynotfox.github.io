/* Сборка автономного HTML: three.js + OrbitControls + приложение в одном файле */
const fs = require('fs');
const path = require('path');
const R = p => fs.readFileSync(path.join(__dirname, p), 'utf8');

/* 1. three.js: превращаем ESM-экспорт в объект THREE */
let three = R('vendor/three.module.min.js');
const m = three.match(/export\s*\{([\s\S]*?)\};?\s*$/);
if (!m) throw new Error('не найден export в three.module.min.js');
const pairs = m[1].split(',').map(s => s.trim()).filter(Boolean).map(s => {
  const p = s.split(/\s+as\s+/);
  return p.length === 2 ? `${p[1]}:${p[0]}` : `${p[0]}:${p[0]}`;
});
three = three.slice(0, m.index) + `\nconst THREE={${pairs.join(',')}};\n`;

/* 2. OrbitControls: убираем импорты/экспорт, оборачиваем в IIFE */
let oc = R('vendor/OrbitControls.js');
oc = oc.replace(/import\s*\{[\s\S]*?\}\s*from\s*'three';/, '');
oc = oc.replace(/export\s*\{[\s\S]*?\};?/, '');
const ocNames = ['EventDispatcher', 'MOUSE', 'Quaternion', 'Spherical', 'TOUCH', 'Vector2', 'Vector3', 'Plane', 'Ray', 'MathUtils'];
oc = `\nconst OrbitControls=(function(){\nconst {${ocNames.join(',')}}=THREE;\n${oc}\nreturn OrbitControls;\n})();\n`;

/* 3. приложение */
const parts = ['00-core.js', '10-car.js', '11-detail.js', '20-station.js', '30-post.js', '40-sim.js', '50-ui.js'];
const app = parts.map(p => `\n/* ==== ${p} ==== */\n` + R('src/' + p)).join('\n');

const css = R('src/style.css');
const markup = R('src/ui.html');

const html = `<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Москва-2020 · 81-775/776/777 — интерактивная 3D-модель</title>
<meta name="description" content="Фотореалистичная интерактивная модель поезда метро «Москва-2020» (81-775/776/777) на Three.js: точные габариты, тележки, салон, кабина, станция, свет и звук.">
<style>
${css}
</style>
</head>
<body>
${markup}
<script type="module">
/* Three.js r160 (MIT) — встроен, чтобы файл работал полностью автономно, без сети */
${three}
${oc}
(function(){
'use strict';
${app}
})();
</script>
</body>
</html>`;

const out = path.join(__dirname, 'moskva-2020.html');
fs.writeFileSync(out, html);
console.log('OK', out, (html.length / 1048576).toFixed(2), 'MB');
