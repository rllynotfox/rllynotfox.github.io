const puppeteer=require('puppeteer');const path=require('path');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:900,height:560});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?q=low',{waitUntil:'load'});
await p.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:120000});
await p.evaluate(()=>document.querySelector('#segCars button[data-cars="4"]').click());await sleep(3000);
for(const c of ['bogie','cab','salon']){
  await p.evaluate(k=>window.__setCam(k),c);await sleep(3500);
  const s=await p.evaluate(()=>window.__stats());
  console.log(c,JSON.stringify({cp:s.cp,ct:s.ct,tp:s.tp,sx:s.sx,lastX:s.lastX,studio:s.studio,follow:s.follow}));
  await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  await p.screenshot({path:'shots/d_'+c+'.png'});
}
await b.close();})();
