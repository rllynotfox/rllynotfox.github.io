/* ============================================================================
   МОСКВА-2020 · 81-775/776  —  студийная модель двух вагонов
   База: размеры, палитры, математика, сборщик геометрии, материалы, окружение
   ========================================================================== */

const SPECS = {
  headLen: 20.080, midLen: 19.140,
  width: 2.740, height: 3.680,
  carBase: 12.600, bogieBase: 2.200,
  wheelD: 0.780, gauge: 1.520,
  doorW: 1.600, gangwayW: 1.600, floorH: 1.200
};

const DIM = {
  hw: 1.370,
  yb: 1.000, yt: 3.680,
  rb: 0.10, rt: 0.34,
  sideBot: 1.100, sideTop: 3.300,
  skirtTop: 1.180,
  bandLowBot: 1.180, bandLowTop: 1.460,
  bandUpBot: 3.040, bandUpTop: 3.300,
  winBot: 1.760, winTop: 2.800,
  doorBot: 1.180, doorTop: 2.920,
  noseLen: 1.150, rake: 0.130,
  floorH: 1.200
};

const LIVERIES = {
  classic: {
    name: 'Кольцевая',
    body: '#dfe4e7', bodyHi: '#f2f6f8',
    red: '#d2261f', redHi: '#ef3b30',
    roof: '#1e3a63', skirt: '#23262a',
    mask: '#0b0d10', frame: '#d2261f',
    glass: '#0d1518', door: '#16191d',
    graphic: '#2f5fa8', rings: true,
    line: '5', lineColor: '#8d5b4c',
    station: 'Краснопресненская', route: '024'
  },
  bkl: {
    name: 'БКЛ',
    body: '#e6eaec', bodyHi: '#f6f9fa',
    red: '#d2261f', redHi: '#ef3b30',
    roof: '#16233d', skirt: '#212429',
    mask: '#0a0c0f', frame: '#d2261f',
    glass: '#0c1417', door: '#14171b',
    graphic: '#3a76c4', rings: true,
    line: '11', lineColor: '#82c0c0',
    station: 'Терехово', route: '047'
  },
  m2024: {
    name: 'Рестайлинг',
    body: '#eceff1', bodyHi: '#fbfdfd',
    red: '#e01f1f', redHi: '#ff3b30',
    roof: '#262a31', skirt: '#1c1f23',
    mask: '#08090b', frame: '#e01f1f',
    glass: '#0b1114', door: '#121519',
    graphic: '#c8352c', rings: false,
    line: '2', lineColor: '#4fb04f',
    station: 'Технопарк', route: '112'
  }
};

const state = {
  livery: 'classic',
  exposure: 1.02,
  key: 1.00,
  rim: 1.00,
  warm: 0.40,
  gloss: 0.72,
  glassTint: 0.46,
  doors: 0,
  headlights: true,
  interiorLight: true,
  autoOrbit: false,
  orbitSpeed: 0.35,
  wireframe: false,
  backdrop: 'studio',
  quality: 'high',
  camera: 'hero',
  sound: false
};

/* -------------------------------- математика ------------------------------ */
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const smoother = t => t * t * t * (t * (t * 6 - 15) + 10);
const TAU = Math.PI * 2;

function M4(x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Matrix4();
  if (rx || ry || rz) m.makeRotationFromEuler(new THREE.Euler(rx, ry, rz));
  m.setPosition(x, y, z);
  return m;
}

/* --------------------------------- холсты --------------------------------- */
function cvs(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}
let MAXANISO = 8;
function tex(canvas, opts = {}) {
  const t = new THREE.CanvasTexture(canvas);
  t.colorSpace = opts.data ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = opts.clamp ? THREE.ClampToEdgeWrapping : THREE.RepeatWrapping;
  if (opts.repeat) t.repeat.set(opts.repeat[0], opts.repeat[1]);
  t.anisotropy = MAXANISO;
  t.needsUpdate = true;
  return t;
}

/* --------------------------- скруглённые прямоугольники ------------------- */
function roundedRectShape(w, h, r, cx = 0, cy = 0) {
  const s = new THREE.Shape();
  const x = cx - w / 2, y = cy - h / 2;
  r = Math.min(r, w / 2 - 1e-4, h / 2 - 1e-4);
  s.moveTo(x + r, y);
  s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r); s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}
function roundedRectPath(w, h, r, cx = 0, cy = 0) {
  const p = new THREE.Path();
  p.curves = roundedRectShape(w, h, r, cx, cy).curves;
  p.autoClose = true;
  return p;
}
/* точка скруглённого сечения по лучу из центра */
function rrPoint(hw, hh, rb, rt, th) {
  const c = Math.cos(th), s = Math.sin(th);
  const ac = Math.abs(c), as = Math.abs(s);
  const r = s >= 0 ? rt : rb;
  const cz = hw - r, cy = hh - r;
  let z, y;
  if (ac > 1e-9 && (as <= 1e-9 || (hw / ac) * as <= cy)) { z = hw; y = hw * as / ac; }
  else if (as > 1e-9 && (hh / as) * ac <= cz) { y = hh; z = hh * ac / as; }
  else {
    const b = ac * cz + as * cy, cc = cz * cz + cy * cy - r * r;
    const t = b + Math.sqrt(Math.max(0, b * b - cc));
    z = t * ac; y = t * as;
  }
  return [c < 0 ? -z : z, s < 0 ? -y : y];
}

function plate(w, h, r, t = 0.02) {
  return new THREE.ExtrudeGeometry(roundedRectShape(w, h, r), { depth: t, bevelEnabled: false, curveSegments: 10 });
}
function ringPlate(w, h, r, border, t = 0.014) {
  const s = roundedRectShape(w, h, r);
  s.holes.push(roundedRectPath(w - border * 2, h - border * 2, Math.max(0.01, r - border)));
  return new THREE.ExtrudeGeometry(s, { depth: t, bevelEnabled: false, curveSegments: 10 });
}

/* ------------------------- сборщик геометрии по материалам ---------------- */
class Builder {
  constructor() { this.bins = new Map(); }
  add(key, geo, matrix) {
    if (matrix) geo.applyMatrix4(matrix);
    if (!geo.attributes.uv) {
      const n = geo.attributes.position.count;
      geo.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(n * 2), 2));
    }
    if (!geo.attributes.normal) geo.computeVertexNormals();
    const g = geo.index ? geo.toNonIndexed() : geo;
    if (!this.bins.has(key)) this.bins.set(key, []);
    this.bins.get(key).push(g);
    return this;
  }
  box(key, w, h, d, x, y, z, rot) {
    const g = new THREE.BoxGeometry(w, h, d);
    const m = new THREE.Matrix4();
    if (rot) m.makeRotationFromEuler(new THREE.Euler(rot[0] || 0, rot[1] || 0, rot[2] || 0));
    m.setPosition(x, y, z);
    return this.add(key, g, m);
  }
  cyl(key, rt, rb, h, seg, x, y, z, rot) {
    const g = new THREE.CylinderGeometry(rt, rb, h, seg);
    const m = new THREE.Matrix4();
    if (rot) m.makeRotationFromEuler(new THREE.Euler(rot[0] || 0, rot[1] || 0, rot[2] || 0));
    m.setPosition(x, y, z);
    return this.add(key, g, m);
  }
  flush(materials, target, opts = {}) {
    const out = [];
    for (const [key, list] of this.bins) {
      const mat = materials[key];
      if (!mat) { console.warn('нет материала:', key); continue; }
      const geo = mergeGeos(list);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = opts.cast !== false;
      mesh.receiveShadow = opts.receive !== false;
      mesh.name = key;
      target.add(mesh);
      out.push(mesh);
    }
    this.bins.clear();
    return out;
  }
}

function mergeGeos(list) {
  let total = 0;
  for (const g of list) total += g.attributes.position.count;
  const pos = new Float32Array(total * 3);
  const nrm = new Float32Array(total * 3);
  const uv = new Float32Array(total * 2);
  let o = 0;
  for (const g of list) {
    const n = g.attributes.position.count;
    pos.set(g.attributes.position.array, o * 3);
    nrm.set(g.attributes.normal.array, o * 3);
    if (g.attributes.uv) uv.set(g.attributes.uv.array, o * 2);
    o += n;
    g.dispose();
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nrm, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  out.computeBoundingSphere();
  return out;
}

/* ------------------------------ микрофактура ------------------------------ */
function noiseCanvas(size, amp, base, scale) {
  const c = cvs(size, size), g = c.getContext('2d');
  const img = g.createImageData(size, size);
  const grid = 32, vals = [];
  for (let i = 0; i < (grid + 1) * (grid + 1); i++) vals.push(Math.random());
  const at = (x, y) => vals[(y % grid) * (grid + 1) + (x % grid)];
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const fx = x / size * grid, fy = y / size * grid;
    const ix = fx | 0, iy = fy | 0, tx = fx - ix, ty = fy - iy;
    const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
    const v = lerp(lerp(at(ix, iy), at(ix + 1, iy), sx), lerp(at(ix, iy + 1), at(ix + 1, iy + 1), sx), sy);
    const b = clamp(base + (v - 0.5) * amp * 2 + (Math.random() - 0.5) * amp * scale, 0, 1) * 255;
    const i = (y * size + x) * 4;
    img.data[i] = img.data[i + 1] = img.data[i + 2] = b;
    img.data[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return c;
}
function normalFromCanvas(src, strength) {
  const size = src.width;
  const sg = src.getContext('2d').getImageData(0, 0, size, size).data;
  const c = cvs(size, size), g = c.getContext('2d');
  const img = g.createImageData(size, size);
  const H = (x, y) => sg[(((y + size) % size) * size + ((x + size) % size)) * 4] / 255;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const dx = (H(x + 1, y) - H(x - 1, y)) * strength;
    const dy = (H(x, y + 1) - H(x, y - 1)) * strength;
    let nx = -dx, ny = -dy, nz = 1;
    const l = Math.hypot(nx, ny, nz);
    const i = (y * size + x) * 4;
    img.data[i] = (nx / l * 0.5 + 0.5) * 255;
    img.data[i + 1] = (ny / l * 0.5 + 0.5) * 255;
    img.data[i + 2] = (nz / l * 0.5 + 0.5) * 255;
    img.data[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return c;
}

/* --------------------------------- материалы ------------------------------ */
const MATS = {};
function buildMaterials(L) {
  for (const k in MATS) {
    const m = MATS[k];
    if (m && m.isMaterial) {
      for (const t of ['map', 'normalMap', 'roughnessMap']) if (m[t]) m[t].dispose();
      m.dispose();
    }
    delete MATS[k];
  }
  const rough = tex(noiseCanvas(256, 0.07, 0.34, 0.4), { data: true, repeat: [8, 4] });
  const peelN = tex(normalFromCanvas(noiseCanvas(256, 0.5, 0.5, 0.4), 0.8), { data: true, repeat: [18, 8] });
  const grime = tex(noiseCanvas(256, 0.06, 0.60, 0.5), { data: true, repeat: [10, 3] });

  const paint = (color, r = 0.30) => new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(color), roughness: r, metalness: 0.08,
    clearcoat: 0.9, clearcoatRoughness: 0.10,
    roughnessMap: rough, normalMap: peelN, normalScale: new THREE.Vector2(0.055, 0.055),
    envMapIntensity: 1.15
  });

  MATS.body = paint(L.body, 0.30);
  MATS.red = paint(L.red, 0.26);
  MATS.accent = paint(L.frame, 0.26);
  MATS.roof = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(L.roof), roughness: 0.44, metalness: 0.20,
    clearcoat: 0.55, clearcoatRoughness: 0.32, roughnessMap: rough, envMapIntensity: 0.95
  });
  MATS.skirt = new THREE.MeshStandardMaterial({
    color: new THREE.Color(L.skirt), roughness: 0.66, metalness: 0.34, roughnessMap: grime, envMapIntensity: 0.7
  });
  MATS.skin = new THREE.MeshPhysicalMaterial({
    roughness: 0.30, metalness: 0.08, clearcoat: 0.9, clearcoatRoughness: 0.10,
    normalMap: peelN, normalScale: new THREE.Vector2(0.05, 0.05), envMapIntensity: 1.15
  });
  MATS.reveal = new THREE.MeshStandardMaterial({ color: 0x2a2e33, roughness: 0.55, metalness: 0.4 });
  MATS.mask = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(L.mask), roughness: 0.09, metalness: 0.28,
    clearcoat: 1.0, clearcoatRoughness: 0.05, envMapIntensity: 1.6
  });
  MATS.band = new THREE.MeshPhysicalMaterial({
    color: 0x121519, roughness: 0.15, metalness: 0.22, clearcoat: 1, clearcoatRoughness: 0.07, envMapIntensity: 1.35
  });
  MATS.doorMat = new THREE.MeshPhysicalMaterial({
    roughness: 0.26, metalness: 0.12, clearcoat: 0.85, clearcoatRoughness: 0.12,
    normalMap: peelN, normalScale: new THREE.Vector2(0.05, 0.05), envMapIntensity: 1.1
  });
  MATS.glass = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(L.glass), roughness: 0.05, metalness: 0.0,
    transparent: true, opacity: 0.46, clearcoat: 1, clearcoatRoughness: 0.03,
    envMapIntensity: 1.8, side: THREE.DoubleSide, depthWrite: false
  });
  MATS.glassFront = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(L.glass), roughness: 0.04, metalness: 0.0,
    transparent: true, opacity: 0.34, clearcoat: 1, clearcoatRoughness: 0.02,
    envMapIntensity: 2.2, side: THREE.DoubleSide, depthWrite: false
  });
  MATS.rubber = new THREE.MeshStandardMaterial({ color: 0x121417, roughness: 0.94, metalness: 0.0 });
  MATS.steel = new THREE.MeshStandardMaterial({ color: 0xbcc2c8, roughness: 0.24, metalness: 0.96, envMapIntensity: 1.35 });
  MATS.steelDark = new THREE.MeshStandardMaterial({ color: 0x4a5057, roughness: 0.48, metalness: 0.88, roughnessMap: grime });
  MATS.under = new THREE.MeshStandardMaterial({ color: 0x2b2f34, roughness: 0.70, metalness: 0.5, roughnessMap: grime, envMapIntensity: 0.6 });
  MATS.underDark = new THREE.MeshStandardMaterial({ color: 0x171a1e, roughness: 0.82, metalness: 0.4 });
  MATS.wheel = new THREE.MeshStandardMaterial({ color: 0x45423d, roughness: 0.42, metalness: 0.86, roughnessMap: grime });
  MATS.tread = new THREE.MeshStandardMaterial({ color: 0x93979d, roughness: 0.16, metalness: 1.0, envMapIntensity: 1.5 });
  MATS.pole = new THREE.MeshStandardMaterial({ color: 0xcad0d6, roughness: 0.20, metalness: 0.96, envMapIntensity: 1.45 });
  MATS.interiorWall = new THREE.MeshStandardMaterial({ color: 0xd4dade, roughness: 0.62, metalness: 0.05, side: THREE.DoubleSide });
  MATS.interiorFloor = new THREE.MeshStandardMaterial({ color: 0x565b61, roughness: 0.86, metalness: 0.05, side: THREE.DoubleSide });
  MATS.seat = new THREE.MeshStandardMaterial({ color: 0x2b4d78, roughness: 0.86, metalness: 0.0 });
  MATS.seatBase = new THREE.MeshStandardMaterial({ color: 0x383e45, roughness: 0.6, metalness: 0.3 });
  MATS.cabDark = new THREE.MeshStandardMaterial({ color: 0x4a5158, roughness: 0.62, metalness: 0.15, side: THREE.DoubleSide });
  MATS.cabPanel = new THREE.MeshStandardMaterial({ color: 0x646c74, roughness: 0.5, metalness: 0.25 });
  MATS.screen = new THREE.MeshStandardMaterial({ color: 0x08121c, emissive: new THREE.Color(0x2a6ea8), emissiveIntensity: 1.2, roughness: 0.25 });
  MATS.ledWhite = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: new THREE.Color(0xfff4e6), emissiveIntensity: 2.6, roughness: 0.4 });
  MATS.ledWarm = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: new THREE.Color(0xffeacf), emissiveIntensity: 1.1, roughness: 0.5 });
  MATS.ledRed = new THREE.MeshStandardMaterial({ color: 0x2a0000, emissive: new THREE.Color(0xff2a2a), emissiveIntensity: 2.0, roughness: 0.4 });
  MATS.decal = new THREE.MeshBasicMaterial({
    transparent: true, depthWrite: false, toneMapped: false,
    polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4
  });
  return MATS;
}

/* ------------------------- окружение студийного зала ---------------------- */
function makeEnvTexture(renderer) {
  const W = 1024, H = 512;
  const c = cvs(W, H), g = c.getContext('2d');
  const grd = g.createLinearGradient(0, 0, 0, H);
  grd.addColorStop(0.00, '#0a0e14');
  grd.addColorStop(0.34, '#1b2530');
  grd.addColorStop(0.50, '#2c3947');
  grd.addColorStop(0.62, '#141a22');
  grd.addColorStop(1.00, '#05070a');
  g.fillStyle = grd; g.fillRect(0, 0, W, H);
  // верхние софтбоксы — читаются длинными бликами на кузове
  const bars = [[0.16, 0.055, 5.2], [0.30, 0.030, 2.4], [0.44, 0.020, 1.2]];
  for (const [v, h, inten] of bars) {
    const y = v * H, hh = h * H;
    const bg = g.createLinearGradient(0, y - hh, 0, y + hh);
    const a = clamp(inten / 6, 0, 1);
    bg.addColorStop(0, 'rgba(210,232,255,0)');
    bg.addColorStop(0.5, `rgba(226,242,255,${a})`);
    bg.addColorStop(1, 'rgba(210,232,255,0)');
    g.fillStyle = bg;
    g.fillRect(0, y - hh, W, hh * 2);
  }
  // тёплый боковой источник
  const warm = g.createRadialGradient(W * 0.78, H * 0.42, 10, W * 0.78, H * 0.42, W * 0.20);
  warm.addColorStop(0, 'rgba(255,196,140,0.55)');
  warm.addColorStop(1, 'rgba(255,196,140,0)');
  g.fillStyle = warm; g.fillRect(0, 0, W, H);
  const t = tex(c, { clamp: true });
  t.mapping = THREE.EquirectangularReflectionMapping;
  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileEquirectangularShader();
  const rt = pmrem.fromEquirectangular(t);
  t.dispose(); pmrem.dispose();
  return rt.texture;
}
