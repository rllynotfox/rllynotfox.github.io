/* Приёмка: тележка / салон / сброс / рейс + отдельный мобильный контекст.
   SwiftShader медленный, dt<=0.05 => симуляция идёт медленнее реального времени. */
const puppeteer = require('puppeteer'); const path = require('path');
const URL = 'file://' + path.join(__dirname, 'moskva-2020.html') + '?q=low';
const FLAGS = ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];
const wait = ms => new Promise(r => setTimeout(r, ms));
const sync = p => p.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))));
const R = { steps: [], errors: [] };
const step = (k, v) => { R.steps.push(k); R[k] = v; };

async function boot(b, w, h) {
  const p = await b.newPage();
  await p.setViewport({ width: w, height: h });
  p.on('pageerror', e => R.errors.push('PAGEERR ' + e.message));
  p.on('console', m => { const t = m.text(); if (/нет материала|not of type|INVALID_OPERATION|Too many|context lost/i.test(t)) R.errors.push('CONSOLE ' + t.slice(0, 150)); });
  await p.goto(URL, { waitUntil: 'load' });
  await p.waitForFunction(() => document.getElementById('loader').classList.contains('done'), { timeout: 180000 });
  await wait(2000);
  return p;
}
const low4 = async p => {
  await p.evaluate(() => document.querySelector('#segQuality button[data-q="low"]').click());
  await p.evaluate(() => document.querySelector('#segCars button[data-cars="4"]').click());
  await wait(2600);
};

(async () => {
  const b = await puppeteer.launch({ headless: 'new', args: FLAGS });
  try {
    const p = await boot(b, 1000, 620);
    await low4(p);
    const shot = async n => { await sync(p); await p.screenshot({ path: 'shots/a_' + n + '.png' }); };

    /* --- тележка --- */
    await p.evaluate(() => window.__setCam('bogie')); await wait(3000); await shot('bogie');
    step('bogie', await p.evaluate(() => {
      const T = window.__three, sc = window.__getScene(), cam = window.__cam();
      const vis = o => { let q = o; while (q) { if (!q.visible) return false; q = q.parent; } return true; };
      const rc = new T.Raycaster(); const names = {};
      for (let i = 0; i < 11; i++) for (let j = 0; j < 8; j++) {
        rc.setFromCamera(new T.Vector2(-0.85 + i * 0.17, -0.75 + j * 0.21), cam);
        const h = rc.intersectObjects(sc.children, true).filter(x => x.object.type === 'Mesh' && vis(x.object));
        if (h[0]) { const n = h[0].object.name || '?'; names[n] = (names[n] || 0) + 1; }
      }
      const s = window.__stats();
      return { hits: names, cp: s.cp, ct: s.ct, studio: s.studio };
    }));

    /* --- салон --- */
    await p.evaluate(() => window.__setCam('salon')); await wait(2600); await shot('salon');
    step('salonOk', true);

    /* --- сброс: поезд обязан стоять у платформы, режим = станция --- */
    await p.evaluate(() => document.getElementById('btnReset').click());
    await low4(p); await shot('reset');
    step('reset', await p.evaluate(() => { const s = window.__stats(); return { phase: s.phase, trainX: s.tp[0], camX: s.cp[0], studio: s.studio, cars: s.cars }; }));

    /* --- рейс: короткий подход, длинный таймаут (медленный растеризатор) --- */
    await p.evaluate(() => { const s = window.__sim; s.x = s.stopX - 42; s.v = 9; s.phase = 'approach'; s.tPhase = 0; window.__state.running = true; });
    await wait(1500); await shot('approach');
    step('approach', await p.evaluate(() => { const s = window.__stats(); return { phase: s.phase, trainX: s.tp[0], camX: s.cp[0], targetX: s.ct[0] }; }));
    let arrived = false;
    try { await p.waitForFunction(() => window.__sim.phase === 'dwell', { timeout: 170000, polling: 1000 }); arrived = true; } catch (e) { }
    step('arrived', arrived);
    if (arrived) {
      await wait(3000); await shot('arrived');
      step('doors', await p.evaluate(() => window.__state.doorsOpen));
    }

    /* --- орбита мышью --- */
    const before = await p.evaluate(() => window.__stats().cp);
    await p.mouse.move(400, 300); await p.mouse.down();
    for (let i = 0; i < 10; i++) { await p.mouse.move(400 + i * 14, 300 + i * 3); await wait(40); }
    await p.mouse.up(); await wait(1200); await shot('drag');
    step('dragMoved', JSON.stringify(before) !== JSON.stringify(await p.evaluate(() => window.__stats().cp)));

    step('desktop', await p.evaluate(() => ({ diag: window.__diag, err: window.__renderErr, calls: window.__stats().calls, tris: window.__stats().tris })));
    step('desktopOverflow', await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, sh: document.documentElement.scrollHeight, ch: document.documentElement.clientHeight })));
    await p.close();

    /* --- мобильный: свежий контекст --- */
    const m = await boot(b, 390, 780);
    await low4(m); await sync(m);
    await m.screenshot({ path: 'shots/a_mobile.png' });
    await m.evaluate(() => document.getElementById('btnPanel').click()); await wait(900);
    await m.screenshot({ path: 'shots/a_mobile_panel.png' });
    step('panel', await m.evaluate(() => {
      const d = document.getElementById('dock'); const r = d.getBoundingClientRect();
      return { top: Math.round(r.top), bottom: Math.round(r.bottom), vh: innerHeight, scrollable: d.scrollHeight > d.clientHeight };
    }));
    await m.evaluate(() => { const d = document.getElementById('dock'); d.scrollTop = d.scrollHeight; }); await wait(700);
    await m.screenshot({ path: 'shots/a_mobile_bottom.png' });
    await m.evaluate(() => document.getElementById('btnPanel').click()); await wait(700);
    await m.evaluate(() => window.__setCam('facade')); await wait(2800); await sync(m);
    await m.screenshot({ path: 'shots/a_mobile_facade.png' });
    step('mobile', await m.evaluate(() => ({ diag: window.__diag, err: window.__renderErr, calls: window.__stats().calls })));
    step('mobileOverflow', await m.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, sh: document.documentElement.scrollHeight, ch: document.documentElement.clientHeight })));
    await m.close();
  } catch (e) { R.fatal = String(e && e.message || e); }
  finally { try { await b.close(); } catch (e) { } console.log(JSON.stringify(R, null, 1)); }
})();
