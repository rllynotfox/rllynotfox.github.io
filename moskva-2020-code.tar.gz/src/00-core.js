/* ============================================================================
   МОСКВА-2020 · 81-775/776/777 — фотореалистичная модель
   Ядро: конфигурация, палитра, математика, процедурные текстуры, материалы
   Все размеры в метрах, приведены по заводским данным Метровагонмаш.
   ========================================================================== */

const SPECS = {
  headLen: 20.080,      // длина по торцам головок автосцепок, Мг
  midLen: 19.140,       // длина по торцам головок автосцепок, Мп/Пп
  width: 2.740,         // ширина кузова
  height: 3.680,        // высота порожнего вагона от УГР
  carBase: 12.600,      // база вагона
  bogieBase: 2.200,     // база тележки
  wheelD: 0.780,        // диаметр бандажа нового колеса
  gauge: 1.520,         // ширина колеи
  doorW: 1.600,         // дверной проём
  gangwayW: 1.600,      // межвагонный переход
  floorH: 1.200,        // уровень пола от УГР
  vmax: 90, vserv: 80,
  power: 4 * 170,
  massHead: 38.3, massMid: 36.5, massTrailer: 34.5,
  seatsHead: 29, seatsMid: 34, capacity8: 1490
};

const DIM = {
  hw: SPECS.width / 2,           // 1.37
  yb: 1.02,                      // низ юбки кузова
  yt: SPECS.height,              // 3.68 верх крыши
  rb: 0.16,                      // радиус нижнего скругления
  rt: 0.34,                      // радиус верхнего скругления
  sideBot: 1.18,                 // низ плоской боковины
  sideTop: 3.34,                 // верх плоской боковины
  bandLowBot: 1.18, bandLowTop: 1.42,   // нижняя красная полоса
  bandUpBot: 3.12, bandUpTop: 3.34,     // верхняя красная полоса
  winBot: 1.76, winTop: 2.78,
  doorBot: 1.20, doorTop: 2.90,
  noseLen: 1.15,
  rake: 0.13,                    // завал лобовой маски назад (м на 1 м высоты)
  floorH: SPECS.floorH           // уровень пола
};

/* ---------------------------------- палитры ------------------------------ */
const LIVERIES = {
  classic: {
    name: 'Кольцевая · классическая',
    body: 0xdfe3e6, red: 0xd42a24, roof: 0x24406e, skirt: 0x24272b,
    frame: 0xd42a24, mask: 0x0a0c0f, band: 0x121517, door: 0x1b1e22,
    accent: 0xd42a24, line: '5', lineColor: '#8d5b4c', lineName: 'Кольцевая',
    station: 'КРАСНОПРЕСНЕНСКАЯ', route: '024', side: 'МОСКВА', graphic: 'rings'
  },
  bkl: {
    name: 'БКЛ · бирюзовая',
    body: 0xe8ebed, red: 0xd42a24, roof: 0x1d3557, skirt: 0x24272b,
    frame: 0xd42a24, mask: 0x0a0c0f, band: 0x121517, door: 0x1b1e22,
    accent: 0x25bcd2, line: '11', lineColor: '#82c0c0', lineName: 'Большая кольцевая',
    station: 'ТЕРЕХОВО', route: '047', side: 'МОСКВА', graphic: 'bkl'
  },
  m2024: {
    name: 'Москва-2024 · рестайлинг',
    body: 0xf2f4f5, red: 0xe02020, roof: 0x2b2f36, skirt: 0x1e2125,
    frame: 0xe02020, mask: 0x08090b, band: 0x0e1113, door: 0x15181b,
    accent: 0xe02020, line: '2', lineColor: '#4fb04f', lineName: 'Замоскворецкая',
    station: 'ТЕХНОПАРК', route: '112', side: 'МОСКВА', graphic: 'none'
  }
};

const state = {
  livery: 'bkl',
  cars: 8,
  speedKmh: 62,
  running: true,
  doorsOpen: false,
  headlights: true,
  interiorLight: true,
  passengers: true,
  wiper: false,
  wireframe: false,
  dimensions: false,
  autoOrbit: false,
  follow: true,
  quality: 'high',
  bloom: 0.62,
  dof: 0.35,
  fog: 0.50,
  exposure: 1.06,
  lightWarm: 0.42,
  lightLevel: 1.0,
  grain: 0.35,
  sound: true,
  showSpecs: false,
  studio: false,
  camera: 'hero'
};

/* ---------------------------------- утилиты ------------------------------ */
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = t => t * t * (3 - 2 * t);
const smoother = t => t * t * t * (t * (t * 6 - 15) + 10);
const rnd = (seedObj) => { // детерминированный ГПСЧ
  seedObj.s = (seedObj.s * 1664525 + 1013904223) % 4294967296;
  return seedObj.s / 4294967296;
};
const SEED = { s: 20200607 };
const R = () => rnd(SEED);
const rr = (a, b) => a + (b - a) * R();

function cvs(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
let MAXANISO = 8;
function tex(canvas, opts = {}) {
  const t = new THREE.CanvasTexture(canvas);
  t.colorSpace = opts.data ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = opts.clamp ? THREE.ClampToEdgeWrapping : THREE.RepeatWrapping;
  if (opts.repeat) t.repeat.set(opts.repeat[0], opts.repeat[1]);
  t.anisotropy = MAXANISO;
  t.needsUpdate = true;
  return t;
}

/* округлённый прямоугольник: точка по лучу из центра (для лофтинга кузова) */
function rrPoint(hw, hh, rb, rt, th) {
  const c = Math.cos(th), s = Math.sin(th);
  const ac = Math.abs(c), as = Math.abs(s);
  const r = s >= 0 ? rt : rb;
  const cz = hw - r, cy = hh - r;
  let z, y;
  if (ac > 1e-9 && (as <= 1e-9 || (hw / ac) * as <= cy)) { z = hw; y = hw * as / ac; }
  else if (as > 1e-9 && (hh / as) * ac <= cz) { y = hh; z = hh * ac / as; }
  else {
    const b = ac * cz + as * cy, cc = cz * cz + cy * cy - r * r;
    const t = b + Math.sqrt(Math.max(0, b * b - cc));
    z = t * ac; y = t * as;
  }
  return [c < 0 ? -z : z, s < 0 ? -y : y];
}

function roundedRectShape(w, h, r, cx = 0, cy = 0) {
  const s = new THREE.Shape();
  const x = cx - w / 2, y = cy - h / 2;
  r = Math.min(r, w / 2 - 1e-4, h / 2 - 1e-4);
  s.moveTo(x + r, y);
  s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r); s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}
function roundedRectPath(w, h, r, cx = 0, cy = 0) {
  const p = new THREE.Path();
  const s = roundedRectShape(w, h, r, cx, cy);
  p.curves = s.curves; p.autoClose = true;
  return p;
}

/* ------------------------- сборщик геометрии по материалам ---------------- */
class Builder {
  constructor() { this.bins = new Map(); }
  add(key, geo, matrix) {
    if (matrix) geo.applyMatrix4(matrix);
    if (location.search.includes('nancheck')) {
      const arr = geo.attributes.position.array;
      for (let i = 0; i < arr.length; i++) if (!Number.isFinite(arr[i])) {
        console.log('NANGEOM ' + key + ' :: ' + new Error().stack.split('\n').slice(1, 5).join(' | '));
        break;
      }
    }
    if (!geo.attributes.uv) {
      const n = geo.attributes.position.count;
      geo.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(n * 2), 2));
    }
    if (!geo.attributes.normal) geo.computeVertexNormals();
    const g = geo.index ? geo.toNonIndexed() : geo;
    if (!this.bins.has(key)) this.bins.set(key, []);
    this.bins.get(key).push(g);
    return this;
  }
  box(key, w, h, d, x, y, z, rot) {
    const g = new THREE.BoxGeometry(w, h, d);
    const m = new THREE.Matrix4();
    if (rot) m.makeRotationFromEuler(new THREE.Euler(rot[0] || 0, rot[1] || 0, rot[2] || 0));
    m.setPosition(x, y, z);
    return this.add(key, g, m);
  }
  cyl(key, rt, rb, h, seg, x, y, z, rot) {
    const g = new THREE.CylinderGeometry(rt, rb, h, seg);
    const m = new THREE.Matrix4();
    if (rot) m.makeRotationFromEuler(new THREE.Euler(rot[0] || 0, rot[1] || 0, rot[2] || 0));
    m.setPosition(x, y, z);
    return this.add(key, g, m);
  }
  /* слить в один BufferGeometry на ключ */
  flush(materials, target, opts = {}) {
    const out = [];
    for (const [key, list] of this.bins) {
      const merged = mergeGeos(list);
      const mat = materials[key];
      if (!mat) { console.warn('нет материала', key); continue; }
      const mesh = new THREE.Mesh(merged, mat);
      mesh.castShadow = opts.cast !== false;
      mesh.receiveShadow = opts.receive !== false;
      mesh.name = key;
      target.add(mesh);
      out.push(mesh);
    }
    this.bins.clear();
    return out;
  }
}

function mergeGeos(list) {
  let total = 0;
  for (const g of list) total += g.attributes.position.count;
  const pos = new Float32Array(total * 3), nor = new Float32Array(total * 3), uv = new Float32Array(total * 2);
  let o = 0;
  for (const g of list) {
    const p = g.attributes.position.array, n = g.attributes.normal.array, u = g.attributes.uv.array;
    pos.set(p, o * 3); nor.set(n, o * 3); uv.set(u, o * 2);
    o += g.attributes.position.count;
    g.dispose();
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  out.computeBoundingSphere();
  return out;
}

const M4 = (x, y, z, rx = 0, ry = 0, rz = 0) => {
  const m = new THREE.Matrix4();
  m.makeRotationFromEuler(new THREE.Euler(rx, ry, rz));
  m.setPosition(x, y, z);
  return m;
};

/* --------------------------- процедурные текстуры ------------------------- */
function noiseCanvas(size, scale, contrast, base) {
  const c = cvs(size, size), g = c.getContext('2d');
  const img = g.createImageData(size, size);
  const S = { s: 7717 };
  for (let i = 0; i < size * size; i++) {
    const x = i % size, y = (i / size) | 0;
    let v = 0, amp = 1, f = scale;
    for (let o = 0; o < 4; o++) {
      v += amp * (Math.sin(x * f * 0.7 + Math.cos(y * f * 1.3)) * 0.5 + rnd(S));
      amp *= 0.55; f *= 2.1;
    }
    v = base + (v / 2.2 - 0.5) * contrast;
    const b = clamp(v, 0, 1) * 255;
    img.data[i * 4] = img.data[i * 4 + 1] = img.data[i * 4 + 2] = b;
    img.data[i * 4 + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return c;
}

function normalFromCanvas(src, strength) {
  const size = src.width;
  const sg = src.getContext('2d').getImageData(0, 0, size, size).data;
  const c = cvs(size, size), g = c.getContext('2d');
  const img = g.createImageData(size, size);
  const H = (x, y) => sg[(((y + size) % size) * size + ((x + size) % size)) * 4] / 255;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const dx = (H(x + 1, y) - H(x - 1, y)) * strength;
    const dy = (H(x, y + 1) - H(x, y - 1)) * strength;
    let nx = -dx, ny = -dy, nz = 1;
    const l = Math.hypot(nx, ny, nz); nx /= l; ny /= l; nz /= l;
    const i = (y * size + x) * 4;
    img.data[i] = (nx * 0.5 + 0.5) * 255;
    img.data[i + 1] = (ny * 0.5 + 0.5) * 255;
    img.data[i + 2] = (nz * 0.5 + 0.5) * 255;
    img.data[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return c;
}

/* логотип Московского метро (пин с «М») */
function drawMetroLogo(g, cx, cy, r, color, fill = false) {
  g.save();
  g.translate(cx, cy);
  g.strokeStyle = color; g.fillStyle = color;
  g.lineWidth = r * 0.17; g.lineJoin = 'round'; g.lineCap = 'round';
  g.beginPath();
  const a0 = Math.PI * 0.72, a1 = Math.PI * 0.40;
  g.arc(0, -r * 0.06, r * 0.86, a0, a1 + Math.PI * 2, false);
  g.lineTo(-r * 0.30, r * 1.02);
  g.closePath();
  if (fill) g.fill(); else g.stroke();
  // буква М
  g.lineWidth = r * 0.19;
  g.beginPath();
  const w = r * 0.50, h = r * 0.46, yb = r * 0.24;
  g.moveTo(-w, yb); g.lineTo(-w * 0.86, yb - h);
  g.lineTo(0, yb - h * 0.18); g.lineTo(w * 0.86, yb - h);
  g.lineTo(w, yb);
  g.stroke();
  g.restore();
}

function drawWheelchair(g, cx, cy, s, color) {
  g.save(); g.translate(cx, cy); g.scale(s, s);
  g.fillStyle = color; g.strokeStyle = color; g.lineWidth = 0.11; g.lineCap = 'round';
  g.beginPath(); g.arc(0.06, -0.62, 0.15, 0, 7); g.fill();
  g.beginPath(); g.moveTo(0.02, -0.40); g.lineTo(-0.02, 0.02); g.lineTo(0.36, 0.02);
  g.lineTo(0.50, 0.42); g.stroke();
  g.beginPath(); g.moveTo(0.02, -0.24); g.lineTo(0.34, -0.20); g.stroke();
  g.beginPath(); g.arc(0.02, 0.22, 0.40, -0.5, Math.PI * 1.55); g.stroke();
  g.restore();
}

/* светодиодное табло: текст + растр */
function ledDisplay(text, w, h, opts = {}) {
  const c = cvs(w, h), g = c.getContext('2d');
  g.fillStyle = opts.bg || '#05070a'; g.fillRect(0, 0, w, h);
  const pad = opts.pad ?? h * 0.22;
  g.textBaseline = 'middle';
  let fs = opts.font || Math.floor(h * 0.56);
  g.font = `${opts.weight || 600} ${fs}px "Segoe UI", "Helvetica Neue", Arial, sans-serif`;
  while (g.measureText(text).width > w - pad * 2 && fs > 8) {
    fs -= 2; g.font = `${opts.weight || 600} ${fs}px "Segoe UI", "Helvetica Neue", Arial, sans-serif`;
  }
  g.fillStyle = opts.fg || '#eaf4ff';
  g.shadowColor = opts.fg || '#eaf4ff'; g.shadowBlur = h * 0.22;
  if (opts.align === 'left') { g.textAlign = 'left'; g.fillText(text, pad, h * 0.53); }
  else { g.textAlign = 'center'; g.fillText(text, w / 2, h * 0.53); }
  g.shadowBlur = 0;
  if (opts.led !== false) { // растр светодиодов
    const step = Math.max(3, Math.round(h / 22));
    g.globalCompositeOperation = 'multiply';
    g.fillStyle = '#000';
    for (let y = 0; y < h; y += step) g.fillRect(0, y, w, 1);
    for (let x = 0; x < w; x += step) g.fillRect(x, 0, 1, h);
    g.globalCompositeOperation = 'source-over';
  }
  return c;
}

function textDecal(text, w, h, opts = {}) {
  const c = cvs(w, h), g = c.getContext('2d');
  g.clearRect(0, 0, w, h);
  if (opts.bg) { g.fillStyle = opts.bg; g.fillRect(0, 0, w, h); }
  g.textAlign = opts.align || 'center'; g.textBaseline = 'middle';
  g.font = `${opts.weight || 700} ${opts.font || Math.floor(h * 0.7)}px "Segoe UI", Arial, sans-serif`;
  g.fillStyle = opts.fg || '#ffffff';
  if (opts.letterSpacing) {
    const chars = [...text];
    const widths = chars.map(ch => g.measureText(ch).width + opts.letterSpacing);
    const total = widths.reduce((a, b) => a + b, 0) - opts.letterSpacing;
    let x = opts.align === 'left' ? 4 : (w - total) / 2;
    g.textAlign = 'left';
    for (let i = 0; i < chars.length; i++) { g.fillText(chars[i], x, h * 0.54); x += widths[i]; }
  } else {
    g.fillText(text, opts.align === 'left' ? 4 : w / 2, h * 0.54);
  }
  return c;
}

/* графика на борту: концентрические дуги (фирменный паттерн) */
function sideGraphic(w, h, mode, color) {
  const c = cvs(w, h), g = c.getContext('2d');
  g.clearRect(0, 0, w, h);
  if (mode === 'none') return c;
  g.strokeStyle = color; g.lineCap = 'butt';
  const cx = w * 0.5, cy = h * 0.55;
  if (mode === 'rings') {
    for (let i = 0; i < 5; i++) {
      g.lineWidth = h * 0.055;
      g.beginPath(); g.arc(cx, cy, h * (0.16 + i * 0.115), Math.PI * 0.15, Math.PI * 1.85); g.stroke();
    }
  } else {
    g.globalAlpha = 0.95;
    for (let i = 0; i < 4; i++) {
      g.lineWidth = h * 0.05;
      g.beginPath(); g.arc(cx - w * 0.18, cy, h * (0.2 + i * 0.14), -Math.PI * 0.5, Math.PI * 0.5); g.stroke();
      g.beginPath(); g.arc(cx + w * 0.18, cy, h * (0.2 + i * 0.14), Math.PI * 0.5, Math.PI * 1.5); g.stroke();
    }
  }
  return c;
}

/* --------------------------------- материалы ------------------------------ */
const MATS = {};
function buildMaterials(L) {
  for (const k in MATS) {
    const m = MATS[k];
    if (m && m.isMaterial && !k.startsWith('cloth') && k !== 'trouser') {
      for (const t of ['map', 'normalMap', 'roughnessMap']) if (m[t]) m[t].dispose();
      m.dispose();
    }
  }
  const rough = tex(noiseCanvas(256, 0.09, 0.30, 0.55), { data: true, repeat: [6, 3] });
  const peelN = tex(normalFromCanvas(noiseCanvas(256, 0.55, 0.5, 0.5), 1.1), { data: true, repeat: [14, 6] });
  const grime = tex(noiseCanvas(256, 0.05, 0.55, 0.62), { data: true, repeat: [10, 2] });

  const paint = (color, r = 0.30) => new THREE.MeshPhysicalMaterial({
    color, roughness: r, metalness: 0.05, clearcoat: 0.85, clearcoatRoughness: 0.14,
    roughnessMap: rough, normalMap: peelN, normalScale: new THREE.Vector2(0.10, 0.10),
    envMapIntensity: 1.15
  });

  MATS.body = paint(L.body, 0.32);
  MATS.red = paint(L.red, 0.28);
  MATS.accent = paint(L.frame, 0.28);
  MATS.roof = new THREE.MeshPhysicalMaterial({
    color: L.roof, roughness: 0.46, metalness: 0.15, clearcoat: 0.5, clearcoatRoughness: 0.35,
    roughnessMap: rough, envMapIntensity: 0.9
  });
  MATS.skirt = new THREE.MeshStandardMaterial({ color: L.skirt, roughness: 0.68, metalness: 0.35, roughnessMap: grime, envMapIntensity: 0.7 });
  MATS.mask = new THREE.MeshPhysicalMaterial({
    color: L.mask, roughness: 0.10, metalness: 0.25, clearcoat: 1.0, clearcoatRoughness: 0.05,
    normalMap: peelN, normalScale: new THREE.Vector2(0.05, 0.05), envMapIntensity: 1.5
  });
  MATS.band = new THREE.MeshPhysicalMaterial({ color: L.band, roughness: 0.16, metalness: 0.2, clearcoat: 1, clearcoatRoughness: 0.08, envMapIntensity: 1.3 });
  MATS.door = new THREE.MeshPhysicalMaterial({ color: L.door, roughness: 0.24, metalness: 0.3, clearcoat: 0.8, clearcoatRoughness: 0.15, envMapIntensity: 1.1 });
  MATS.glass = new THREE.MeshPhysicalMaterial({
    color: 0x0a1013, roughness: 0.04, metalness: 0.0, transparent: true, opacity: 0.66,
    clearcoat: 1, clearcoatRoughness: 0.02, envMapIntensity: 1.7, side: THREE.DoubleSide,
    depthWrite: false, premultipliedAlpha: true
  });
  MATS.glassFront = new THREE.MeshPhysicalMaterial({
    color: 0x0e1518, roughness: 0.03, metalness: 0.0, transparent: true, opacity: 0.30,
    clearcoat: 1, clearcoatRoughness: 0.02, envMapIntensity: 2.4, side: THREE.DoubleSide, depthWrite: false
  });
  MATS.rubber = new THREE.MeshStandardMaterial({ color: 0x14161a, roughness: 0.92, metalness: 0.0 });
  MATS.steel = new THREE.MeshStandardMaterial({ color: 0xb9bfc6, roughness: 0.26, metalness: 0.95, envMapIntensity: 1.3 });
  MATS.steelDark = new THREE.MeshStandardMaterial({ color: 0x4c525a, roughness: 0.50, metalness: 0.88, roughnessMap: grime });
  MATS.under = new THREE.MeshStandardMaterial({ color: 0x2c3035, roughness: 0.72, metalness: 0.5, roughnessMap: grime, envMapIntensity: 0.6 });
  MATS.underDark = new THREE.MeshStandardMaterial({ color: 0x191c20, roughness: 0.8, metalness: 0.4 });
  MATS.wheel = new THREE.MeshStandardMaterial({ color: 0x4a4640, roughness: 0.44, metalness: 0.85, roughnessMap: grime });
  MATS.tread = new THREE.MeshStandardMaterial({ color: 0x8e9298, roughness: 0.18, metalness: 1.0, envMapIntensity: 1.4 });
  MATS.interiorWall = new THREE.MeshStandardMaterial({ color: 0xd6dbdf, roughness: 0.62, metalness: 0.05, side: THREE.DoubleSide });
  MATS.interiorFloor = new THREE.MeshStandardMaterial({ color: 0x5c6167, roughness: 0.85, metalness: 0.05, roughnessMap: grime, side: THREE.DoubleSide });
  MATS.seat = new THREE.MeshStandardMaterial({ color: 0x2c4f7c, roughness: 0.85, metalness: 0.0 });
  MATS.seatBase = new THREE.MeshStandardMaterial({ color: 0x3b4148, roughness: 0.6, metalness: 0.3 });
  MATS.pole = new THREE.MeshStandardMaterial({ color: 0xc8ced4, roughness: 0.22, metalness: 0.95, envMapIntensity: 1.4 });
  MATS.ledWhite = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff3e2, emissiveIntensity: 3.2, roughness: 0.4, toneMapped: false });
  MATS.ledWarm = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffe9c9, emissiveIntensity: 1.2, roughness: 0.5, toneMapped: false });
  MATS.ledRed = new THREE.MeshStandardMaterial({ color: 0x330000, emissive: 0xff2020, emissiveIntensity: 2.4, roughness: 0.4, toneMapped: false });
  MATS.cabDark = new THREE.MeshStandardMaterial({ color: 0x50575f, roughness: 0.62, metalness: 0.15, side: THREE.DoubleSide });
  MATS.cabPanel = new THREE.MeshStandardMaterial({ color: 0x6a727b, roughness: 0.5, metalness: 0.25 });
  MATS.screen = new THREE.MeshStandardMaterial({ color: 0x0a1420, emissive: 0x2a6ea8, emissiveIntensity: 1.4, roughness: 0.25, toneMapped: false });
  MATS.skin = new THREE.MeshStandardMaterial({ color: 0xd8a184, roughness: 0.75 });
  MATS.hair = new THREE.MeshStandardMaterial({ color: 0x2a2320, roughness: 0.9 });

  MATS.decal = new THREE.MeshPhysicalMaterial({
    transparent: true, roughness: 0.28, metalness: 0.0, clearcoat: 0.9, clearcoatRoughness: 0.12,
    depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2
  });
  MATS.emissiveDecal = new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false, toneMapped: false });

  /* общие декали ливреи (одна текстура на весь состав) */
  const mkDecal = (canvas, extra = {}) => {
    const m = MATS.decal.clone();
    m.map = tex(canvas, { clamp: true });
    Object.assign(m, extra);
    return m;
  };
  const lc = cvs(256, 256);
  drawMetroLogo(lc.getContext('2d'), 128, 120, 92, '#' + new THREE.Color(L.red).getHexString());
  MATS.dLogo = mkDecal(lc);
  MATS.dGraphic = L.graphic === 'none' ? null : mkDecal(sideGraphic(512, 256, L.graphic, '#2f5fa8'), { opacity: 0.92 });
  MATS.dMoskva = mkDecal(textDecal('МОСКВА', 512, 96, { fg: '#ffffff', font: 66, weight: 700, letterSpacing: 6 }));
  const wc = cvs(128, 128), wg = wc.getContext('2d');
  wg.fillStyle = '#1b3f7a'; wg.fillRect(0, 0, 128, 128);
  drawWheelchair(wg, 60, 66, 46, '#ffffff');
  MATS.dWheel = mkDecal(wc, { depthWrite: true });
  MATS.dDisplay = new THREE.MeshBasicMaterial({ map: tex(ledDisplay(L.station, 512, 96, { fg: '#f2f7ff', bg: '#0a0d12' }), { clamp: true }), toneMapped: false });
  MATS.dRoute = new THREE.MeshBasicMaterial({ map: tex(ledDisplay(L.route + '   ' + L.station, 768, 108, { fg: '#ffffff', bg: '#05070a', font: 74, weight: 700 }), { clamp: true }), toneMapped: false, color: 0xffffff });
  const fc = cvs(256, 256);
  drawMetroLogo(fc.getContext('2d'), 128, 118, 86, '#ff2f4a');
  MATS.dFrontLogo = new THREE.MeshBasicMaterial({ map: tex(fc, { clamp: true }), transparent: true, toneMapped: false, depthWrite: false });
  return MATS;
}

/* ---------------------- окружение (HDR-панорама тоннеля) ------------------ */
function makeEnvTexture(renderer) {
  const W = 512, H = 256;
  const data = new Float32Array(W * H * 4);
  const put = (x, y, r, g, b) => { const i = (y * W + x) * 4; data[i] = r; data[i + 1] = g; data[i + 2] = b; data[i + 3] = 1; };
  for (let y = 0; y < H; y++) {
    const v = y / (H - 1);                 // 0 = зенит
    const elev = (0.5 - v) * Math.PI;      // +pi/2 вверху
    for (let x = 0; x < W; x++) {
      const u = x / (W - 1), az = u * Math.PI * 2;
      let r, g, b;
      if (elev > 0.30) {                    // потолок станции
        const t = (elev - 0.30) / (Math.PI / 2 - 0.30);
        r = lerp(0.40, 0.22, t); g = lerp(0.41, 0.23, t); b = lerp(0.44, 0.26, t);
        // продольные световые линии потолка
        const strip = Math.exp(-Math.pow((Math.abs(Math.sin(az)) - 0.30) / 0.09, 2));
        const along = Math.exp(-Math.pow((elev - 0.72) / 0.30, 2));
        const s = strip * along * 7.0;
        r += s * 1.0; g += s * 0.97; b += s * 0.90;
        // кольцевые светильники
        const ring = Math.exp(-Math.pow((elev - 1.06) / 0.075, 2)) * (0.5 + 0.5 * Math.cos(az * 6));
        r += ring * 4.5; g += ring * 4.3; b += ring * 3.9;
      } else if (elev > -0.12) {            // стены / колонны
        const t = (elev + 0.12) / 0.42;
        r = lerp(0.13, 0.44, t); g = lerp(0.14, 0.45, t); b = lerp(0.16, 0.48, t);
        const col = Math.pow(Math.max(0, Math.cos(az * 8)), 8) * 0.55;
        r += col; g += col; b += col * 1.02;
        const warm = Math.pow(Math.max(0, Math.sin(az * 2 + 1)), 3) * 0.12;
        r += warm; g += warm * 0.8; b += warm * 0.5;
        // яркая горизонтальная линия светильников — характерный блик на борту
        const line = Math.exp(-Math.pow((elev - 0.17) / 0.045, 2)) * 3.1;
        r += line; g += line * 0.98; b += line * 0.93;
        const line2 = Math.exp(-Math.pow((elev - 0.05) / 0.03, 2)) * 0.9;
        r += line2 * 0.9; g += line2 * 0.95; b += line2;
      } else {                              // пол / путь
        const t = clamp((-elev - 0.12) / 1.2, 0, 1);
        r = lerp(0.17, 0.045, t); g = lerp(0.17, 0.046, t); b = lerp(0.18, 0.05, t);
      }
      put(x, y, r, g, b);
    }
  }
  const t = new THREE.DataTexture(data, W, H, THREE.RGBAFormat, THREE.FloatType);
  t.mapping = THREE.EquirectangularReflectionMapping;
  t.colorSpace = THREE.NoColorSpace;
  t.needsUpdate = true;
  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileEquirectangularShader();
  const rt = pmrem.fromEquirectangular(t);
  t.dispose(); pmrem.dispose();
  return rt.texture;
}
