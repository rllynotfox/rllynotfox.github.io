const puppeteer=require('puppeteer');const path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:900,height:600});
const out=[];
p.on('console',async m=>{const t=m.text(); if(t.startsWith('LINKFAIL')||t.startsWith('FSDEFINES')||t.startsWith('FSHEAD')) out.push(t.slice(0,1400));});
p.on('pageerror',e=>out.push('PAGEERROR '+e.message));
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?shaderdebug',{waitUntil:'load'});
await new Promise(r=>setTimeout(r,22000));
console.log([...new Set(out)].slice(0,8).join('\n\n----\n\n'));
await b.close();})();
