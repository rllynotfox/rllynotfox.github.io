const puppeteer=require('puppeteer');const path=require('path');
(async()=>{
const cams=process.argv.slice(3);
const q=process.argv[2]||'q=low';
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:1000,height:620});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?'+q,{waitUntil:'load'});
await p.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:120000});
await p.evaluate(()=>{window.__park(true);});
if(process.env.CARS) await p.evaluate(n=>document.querySelector('#segCars button[data-cars="'+n+'"]').click(), process.env.CARS);
await new Promise(r=>setTimeout(r,2500));
for(const c of cams){
  await p.evaluate(k=>window.__setCam(k),c);
  await new Promise(r=>setTimeout(r,2600));
  await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  await p.screenshot({path:'shots/'+c+'.png'});
}
const d=await p.evaluate(()=>({diag:window.__diag,stats:window.__stats()}));
console.log(JSON.stringify(d).slice(0,400),'errs',errs.slice(0,3));
await b.close();})();
