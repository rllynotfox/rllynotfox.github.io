/* ============================================================================
   РЕНДЕР, СВЕТ, ПОСТОБРАБОТКА (bloom + DoF + ACES + зерно + виньетка)
   ========================================================================== */

let renderer, scene, camera, controls, envTex, clock;
let keyLight, fillLight, platformLights = [], headSpots = [], lightCones = [];
let studioKey, studioRim, studioFill, studioUnder;
let composer = null;

const QUALITY = {
  low: { pr: 1.0, samples: 0, shadow: 1024, bloomRes: 0.35, dof: false, shadows: true },
  medium: { pr: 1.35, samples: 2, shadow: 1536, bloomRes: 0.5, dof: true, shadows: true },
  high: { pr: 2.0, samples: 4, shadow: 2048, bloomRes: 0.5, dof: true, shadows: true }
};

let postFailed = false, SOFTWARE = false;
function initRenderer(canvas) {
  const qs = new URLSearchParams(location.search);
  if (qs.get('q') && QUALITY[qs.get('q')]) state.quality = qs.get('q');
  if (location.search.includes('nomsaa')) for (const k in QUALITY) QUALITY[k].samples = 0;
  if (location.search.includes('nodof')) for (const k in QUALITY) QUALITY[k].dof = false;
  if (qs.get('post') === '0') postFailed = true;
  renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance', stencil: false });
  // программный растеризатор (SwiftShader/llvmpipe) не тянет тени и MSAA —
  // заранее включаем облегчённый режим, чтобы сцена осталась плавной и стабильной
  try {
    const gl = renderer.getContext();
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const rname = dbg ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '') : '';
    SOFTWARE = /swiftshader|llvmpipe|software|basic render|microsoft/i.test(rname);
  } catch (e) { SOFTWARE = false; }
  if (SOFTWARE) {
    if (!qs.get('q')) state.quality = 'low';
    QUALITY.low.pr = 1; QUALITY.low.shadow = 512;
    for (const k in QUALITY) { QUALITY[k].samples = 0; QUALITY[k].dof = false; }
  }
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, QUALITY[state.quality].pr));
  renderer.setSize(innerWidth, innerHeight, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NoToneMapping;
  renderer.shadowMap.enabled = !SOFTWARE;   // контактные тени-подложки остаются
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  MAXANISO = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  window.__diag = { shaderErrors: 0, postFailed: false };
  renderer.debug.onShaderError = (gl, prog, vs, fs) => {
    try {
      window.__diag.shaderErrors++;
      if (location.search.includes('shaderdebug')) {
        window.__diag.last = String(gl.getProgramInfoLog(prog) || '') + ' | ' + String(gl.getShaderInfoLog(fs) || '');
      }
    } catch (e) { /* диагностика не должна ломать кадр */ }
    postFailed = true; window.__diag.postFailed = true;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;
  };
  canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); postFailed = true; });
  canvas.addEventListener('webglcontextrestored', () => { allocTargets(); });

  scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x0d1014, 0.010);
  camera = new THREE.PerspectiveCamera(38, innerWidth / innerHeight, 0.15, 420);
  camera.position.set(24, 3.4, 12);
  clock = new THREE.Clock();

  envTex = makeEnvTexture(renderer);
  scene.environment = envTex;

  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.055;
  controls.minDistance = 1.2;
  controls.maxDistance = 190;
  controls.maxPolarAngle = Math.PI * 0.495;
  controls.target.set(6, 2.0, TRACK_Z);
  controls.panSpeed = 0.7;
  controls.rotateSpeed = 0.55;
  controls.zoomSpeed = 0.9;

  /* свет */
  keyLight = new THREE.DirectionalLight(0xfff2e2, 1.5);
  keyLight.position.set(18, 26, 16);
  keyLight.castShadow = true;
  keyLight.shadow.mapSize.set(2048, 2048);
  keyLight.shadow.camera.near = 1;
  keyLight.shadow.camera.far = 120;
  const S = 26;
  keyLight.shadow.camera.left = -S; keyLight.shadow.camera.right = S;
  keyLight.shadow.camera.top = S; keyLight.shadow.camera.bottom = -S;
  keyLight.shadow.bias = -0.0006;
  keyLight.shadow.normalBias = 0.035;
  scene.add(keyLight);
  scene.add(keyLight.target);

  fillLight = new THREE.HemisphereLight(0xdfe8ff, 0x20242a, 0.55);
  scene.add(fillLight);

  studioKey = new THREE.DirectionalLight(0xdce9ff, 2.1); studioKey.position.set(-14, 9, 18); studioKey.visible = false; scene.add(studioKey);
  studioRim = new THREE.DirectionalLight(0xff9a6a, 2.4); studioRim.position.set(20, 6, -18); studioRim.visible = false; scene.add(studioRim);
  studioFill = new THREE.PointLight(0xbfd6ff, 60, 40, 2.0); studioFill.position.set(0, 1.6, 7); studioFill.visible = false; scene.add(studioFill);
  studioUnder = new THREE.PointLight(0xffe4c0, 30, 26, 2.0); studioUnder.position.set(0, 0.55, -5); studioUnder.visible = false; scene.add(studioUnder);
  for (let i = 0; i < 4; i++) {
    const p = new THREE.PointLight(0xffe6c4, 17, 32, 2.0);
    p.position.set(-30 + i * 22, CEIL_Y - 0.9, PLAT_EDGE + 3.2);
    scene.add(p); platformLights.push(p);
    const p2 = new THREE.PointLight(0xdce8ff, 10, 28, 2.0);
    p2.position.set(-30 + i * 22, CEIL_Y - 0.5, TRACK_Z);
    scene.add(p2); platformLights.push(p2);
  }
  // фары
  for (const s of [-1, 1]) {
    const sp = new THREE.SpotLight(0xf2f6ff, 0, 60, 0.30, 0.55, 1.4);
    sp.castShadow = false;
    scene.add(sp); scene.add(sp.target);
    headSpots.push({ light: sp, side: s });
    const cg = new THREE.ConeGeometry(1.5, 16, 22, 1, true);
    cg.translate(0, -8, 0); cg.rotateZ(Math.PI / 2);
    const cm = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
      uniforms: { uOpacity: { value: 0.0 }, uColor: { value: new THREE.Color(0xdfeaff) } },
      vertexShader: `varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);} `,
      fragmentShader: `varying vec3 vP; uniform float uOpacity; uniform vec3 uColor;
        void main(){
          float t = clamp(vP.x/16.0,0.0,1.0);
          float rad = length(vP.yz)/max(0.001,1.5*t);
          float a = pow(1.0-t,1.8) * (1.0-smoothstep(0.55,1.0,rad));
          gl_FragColor = vec4(uColor, a*uOpacity);
        }`
    });
    const cone = new THREE.Mesh(cg, cm);
    cone.frustumCulled = false;
    scene.add(cone);
    lightCones.push({ mesh: cone, side: s });
  }
  initPost();
}

function applyLighting() {
  const warm = state.lightWarm, lv = state.lightLevel;
  const warmCol = new THREE.Color(0xbcd2ff).lerp(new THREE.Color(0xffcf96), warm);
  keyLight.color.copy(warmCol);
  keyLight.intensity = 1.25 * lv;
  fillLight.intensity = 0.17 * lv;
  fillLight.color.copy(new THREE.Color(0x9fb8e8).lerp(new THREE.Color(0xffd9b0), warm));
  for (const p of platformLights) { p.color.copy(warmCol); p.intensity = (p.userData.base || (p.userData.base = p.intensity)) * lv; }
  if (stationGroup) {
    const SM = stationGroup.userData.SM;
    SM.strip.emissive.copy(warmCol); SM.strip.emissiveIntensity = 1.55 * lv;
    SM.ring.emissive.copy(warmCol); SM.ring.emissiveIntensity = 2.1 * lv;
  }
  scene.fog.density = 0.0016 + state.fog * 0.014;
  const fogCol = new THREE.Color(0x0a1018).lerp(new THREE.Color(0x1a1208), warm).multiplyScalar(0.75 + 0.5 * lv);
  scene.fog.color.copy(fogCol);
  scene.background = fogCol;
  const st = state.studio;
  if (studioKey) {
    studioKey.visible = st; studioRim.visible = st; studioFill.visible = st; studioUnder.visible = st;
    const inner = state.camera === 'cab' || state.camera === 'salon';
    studioKey.intensity = (inner ? 0.60 : 2.1) * lv; studioRim.intensity = (inner ? 0.15 : 2.4) * lv;
    studioFill.intensity = (inner ? 24 : 60) * lv; studioUnder.intensity = 46 * lv;
    const cx = controls ? controls.target.x : 0;
    studioKey.position.set(cx - 14, 9, 18); studioKey.target.position.set(cx, 1.6, 0); studioKey.target.updateMatrixWorld();
    studioRim.position.set(cx + 18, 6, -18); studioRim.target.position.set(cx, 1.8, 0); studioRim.target.updateMatrixWorld();
    const sz = camera && camera.position.z >= 0 ? 1 : -1;
    studioFill.position.set(cx + 2, 1.9, sz * 7.5); studioUnder.position.set(cx - 1, 0.6, sz * 4.6);
    keyLight.intensity = (st ? 0.55 : 1.25) * lv;
    fillLight.intensity = (st ? 0.30 : 0.17) * lv;
  }
  const hi = state.headlights ? 1 : 0;
  for (const h of headSpots) h.light.intensity = 140 * hi;
  for (const c of lightCones) c.mesh.material.uniforms.uOpacity.value = 0.055 * hi * (0.3 + state.fog);
  MATS.ledWhite.emissiveIntensity = state.headlights ? 3.4 : 0.25;
  MATS.ledWarm.emissiveIntensity = state.interiorLight ? 1.5 * lv : 0.05;
  for (const car of trainCars) {
    const a = car.userData.anim;
    if (a.headlamps) for (const l of a.headlamps) l.material.emissiveIntensity = state.headlights ? 4.2 : 0.15;
    if (a.frontLogo) a.frontLogo.material.opacity = state.headlights ? 1 : 0.35;
  }
}

/* ------------------------------ постобработка ----------------------------- */
const FS_VERT = `varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.0,1.0); }`;
let fsScene, fsCam, fsMesh;
function fsPass(material, target) {
  fsMesh.material = material;
  renderer.setRenderTarget(target || null);
  renderer.render(fsScene, fsCam);
}
function makeRT(w, h, opts = {}) {
  return new THREE.WebGLRenderTarget(Math.max(2, w | 0), Math.max(2, h | 0), {
    type: THREE.HalfFloatType, format: THREE.RGBAFormat,
    minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
    depthBuffer: !!opts.depth, samples: opts.samples || 0,
    colorSpace: THREE.LinearSRGBColorSpace
  });
}

const P = {};
function initPost() {
  fsScene = new THREE.Scene();
  fsCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  fsMesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.MeshBasicMaterial());
  fsMesh.frustumCulled = false;
  fsScene.add(fsMesh);

  P.bright = new THREE.ShaderMaterial({
    uniforms: { tSrc: { value: null }, uThresh: { value: 0.85 }, uKnee: { value: 0.55 } },
    vertexShader: FS_VERT,
    fragmentShader: `varying vec2 vUv; uniform sampler2D tSrc; uniform float uThresh,uKnee;
      void main(){ vec3 c=texture2D(tSrc,vUv).rgb; float l=dot(c,vec3(0.2126,0.7152,0.0722));
        float s=clamp((l-uThresh+uKnee)/(2.0*uKnee),0.0,1.0);
        float w=max(l-uThresh, s*s*uKnee)/max(l,1e-4);
        gl_FragColor=vec4(c*w,1.0); }`
  });
  P.blur = new THREE.ShaderMaterial({
    uniforms: { tSrc: { value: null }, uDir: { value: new THREE.Vector2(1, 0) }, uTexel: { value: new THREE.Vector2() } },
    vertexShader: FS_VERT,
    fragmentShader: `varying vec2 vUv; uniform sampler2D tSrc; uniform vec2 uDir,uTexel;
      void main(){
        vec2 o=uDir*uTexel;
        vec3 s=texture2D(tSrc,vUv).rgb*0.227027;
        s+=texture2D(tSrc,vUv+o*1.3846).rgb*0.316216;
        s+=texture2D(tSrc,vUv-o*1.3846).rgb*0.316216;
        s+=texture2D(tSrc,vUv+o*3.2308).rgb*0.070270;
        s+=texture2D(tSrc,vUv-o*3.2308).rgb*0.070270;
        gl_FragColor=vec4(s,1.0); }`
  });
  P.down = new THREE.ShaderMaterial({
    uniforms: { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() } },
    vertexShader: FS_VERT,
    fragmentShader: `varying vec2 vUv; uniform sampler2D tSrc; uniform vec2 uTexel;
      void main(){ vec3 s=vec3(0.0);
        s+=texture2D(tSrc,vUv+uTexel*vec2(-1.0,-1.0)).rgb;
        s+=texture2D(tSrc,vUv+uTexel*vec2(1.0,-1.0)).rgb;
        s+=texture2D(tSrc,vUv+uTexel*vec2(-1.0,1.0)).rgb;
        s+=texture2D(tSrc,vUv+uTexel*vec2(1.0,1.0)).rgb;
        gl_FragColor=vec4(s*0.25,1.0); }`
  });
  P.comp = new THREE.ShaderMaterial({
    uniforms: {
      tSrc: { value: null }, tBloomA: { value: null }, tBloomB: { value: null }, tDof: { value: null }, tDepth: { value: null },
      uBloom: { value: 0.6 }, uExposure: { value: 1.05 }, uTime: { value: 0 }, uGrain: { value: 0.35 },
      uDof: { value: 0.35 }, uFocus: { value: 20 }, uRange: { value: 14 }, uNear: { value: 0.15 }, uFar: { value: 420 },
      uRes: { value: new THREE.Vector2() }, uVignette: { value: 0.42 }, uCA: { value: 0.6 }
    },
    vertexShader: FS_VERT,
    fragmentShader: `
      varying vec2 vUv;
      uniform sampler2D tSrc,tBloomA,tBloomB,tDof,tDepth;
      uniform float uBloom,uExposure,uTime,uGrain,uDof,uFocus,uRange,uNear,uFar,uVignette,uCA;
      uniform vec2 uRes;
      vec3 aces(vec3 x){
        const float a=2.51,b=0.03,c=2.43,d=0.59,e=0.14;
        return clamp((x*(a*x+b))/(x*(c*x+d)+e),0.0,1.0);
      }
      float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
      float linDepth(float d){ return (uNear*uFar)/(uFar-(uFar-uNear)*d); }
      void main(){
        vec2 uv=vUv;
        vec2 d2=uv-0.5; float r2=dot(d2,d2);
        float ca=uCA*0.0016*r2;
        vec3 col;
        col.r=texture2D(tSrc,uv+d2*ca).r;
        col.g=texture2D(tSrc,uv).g;
        col.b=texture2D(tSrc,uv-d2*ca).b;
        if(uDof>0.001){
          float d=texture2D(tDepth,uv).x;
          float z=linDepth(d);
          float coc=clamp(abs(z-uFocus)/max(uRange,0.5),0.0,1.0);
          coc=pow(coc,1.35)*uDof;
          vec3 bl=texture2D(tDof,uv).rgb;
          col=mix(col,bl,coc);
        }
        vec3 bl=texture2D(tBloomA,uv).rgb*0.62+texture2D(tBloomB,uv).rgb*0.38;
        col+=bl*uBloom;
        col*=uExposure;
        col=aces(col);
        // кинематографический грейд: холодные тени, тёплые света
        float lum=dot(col,vec3(0.2126,0.7152,0.0722));
        vec3 shadowTint=vec3(0.86,0.95,1.10);
        vec3 highTint=vec3(1.07,1.01,0.92);
        col*=mix(shadowTint,highTint,smoothstep(0.12,0.75,lum));
        col=(col-0.5)*1.13+0.5;
        col=max(col,0.0);
        float vig=smoothstep(0.95,0.25,r2*1.9);
        col*=mix(1.0,vig,uVignette);
        float g=hash(uv*uRes+vec2(uTime*37.0,uTime*19.0))-0.5;
        col+=g*uGrain*0.045;
        col=pow(max(col,0.0),vec3(1.0/2.2));
        gl_FragColor=vec4(col,1.0);
      }`
  });
  allocTargets();
}

function allocTargets() {
  const q = QUALITY[state.quality];
  const MAXPIX = { low: SOFTWARE ? 0.95e6 : 1.35e6, medium: 2.1e6, high: 2.9e6 }[state.quality];
  const fit = Math.sqrt(MAXPIX / Math.max(1, innerWidth * innerHeight));
  const pr = Math.max(0.6, Math.min(devicePixelRatio || 1, q.pr, fit));
  const w = Math.floor(innerWidth * pr), h = Math.floor(innerHeight * pr);
  for (const k of ['main', 'bA', 'bB', 'bC', 'bD', 'dA', 'dB']) if (P[k]) P[k].dispose();
  P.main = makeRT(w, h, { depth: true, samples: q.samples });
  P.main.depthTexture = new THREE.DepthTexture(w, h);
  P.main.depthTexture.type = THREE.UnsignedIntType;
  P.main.depthTexture.format = THREE.DepthFormat;
  const bw = Math.floor(w * q.bloomRes), bh = Math.floor(h * q.bloomRes);
  P.bA = makeRT(bw, bh); P.bB = makeRT(bw, bh);
  P.bC = makeRT(bw / 2, bh / 2); P.bD = makeRT(bw / 2, bh / 2);
  P.dA = makeRT(w / 2, h / 2); P.dB = makeRT(w / 2, h / 2);
  P.comp.uniforms.uRes.value.set(w, h);
  renderer.setPixelRatio(pr);
  renderer.setSize(innerWidth, innerHeight, false);
  if (keyLight) {
    const s = q.shadow;
    if (keyLight.shadow.mapSize.x !== s) {
      keyLight.shadow.mapSize.set(s, s);
      if (keyLight.shadow.map) { keyLight.shadow.map.dispose(); keyLight.shadow.map = null; }
    }
  }
}

function renderFrame(dt, time) {
  const q = QUALITY[state.quality];
  if (postFailed || location.search.includes('nopost')) {
    renderer.setRenderTarget(null);
    renderer.render(scene, camera);
    return;
  }
  renderer.setRenderTarget(P.main);
  renderer.clear();
  renderer.render(scene, camera);

  // bloom
  P.bright.uniforms.tSrc.value = P.main.texture;
  fsPass(P.bright, P.bA);
  P.blur.uniforms.tSrc.value = P.bA;
  P.blur.uniforms.uTexel.value.set(1 / P.bA.width, 1 / P.bA.height);
  P.blur.uniforms.uDir.value.set(1, 0); fsPass(P.blur, P.bB);
  P.blur.uniforms.tSrc.value = P.bB; P.blur.uniforms.uDir.value.set(0, 1); fsPass(P.blur, P.bA);
  P.down.uniforms.tSrc.value = P.bA;
  P.down.uniforms.uTexel.value.set(1 / P.bA.width, 1 / P.bA.height);
  fsPass(P.down, P.bC);
  P.blur.uniforms.tSrc.value = P.bC;
  P.blur.uniforms.uTexel.value.set(1 / P.bC.width, 1 / P.bC.height);
  P.blur.uniforms.uDir.value.set(1, 0); fsPass(P.blur, P.bD);
  P.blur.uniforms.tSrc.value = P.bD; P.blur.uniforms.uDir.value.set(0, 1); fsPass(P.blur, P.bC);

  // dof
  const u = P.comp.uniforms;
  if (q.dof && state.dof > 0.001) {
    P.down.uniforms.tSrc.value = P.main.texture;
    P.down.uniforms.uTexel.value.set(1 / P.main.width, 1 / P.main.height);
    fsPass(P.down, P.dA);
    P.blur.uniforms.tSrc.value = P.dA;
    P.blur.uniforms.uTexel.value.set(1 / P.dA.width, 1 / P.dA.height);
    P.blur.uniforms.uDir.value.set(1, 0); fsPass(P.blur, P.dB);
    P.blur.uniforms.tSrc.value = P.dB; P.blur.uniforms.uDir.value.set(0, 1); fsPass(P.blur, P.dA);
    u.tDof.value = P.dA.texture;
    u.tDepth.value = P.main.depthTexture;
    u.uDof.value = state.dof;
    const fd = camera.position.distanceTo(controls.target);
    u.uFocus.value = fd;
    u.uRange.value = Math.max(3.0, fd * 0.55);
  } else {
    u.uDof.value = 0;
    u.tDof.value = P.main.texture;
    u.tDepth.value = P.main.depthTexture;
  }
  u.tSrc.value = P.main.texture;
  u.tBloomA.value = P.bA.texture;
  u.tBloomB.value = P.bC.texture;
  u.uBloom.value = state.bloom;
  u.uExposure.value = state.exposure;
  u.uGrain.value = state.grain;
  u.uTime.value = time;
  u.uNear.value = camera.near; u.uFar.value = camera.far;
  fsPass(P.comp, null);
}
