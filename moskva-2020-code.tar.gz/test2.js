const puppeteer=require('puppeteer');const path=require('path');
(async()=>{
const q=process.argv[2]||'';
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:800,height:520});
let errs=0,first='';
p.on('console',m=>{if(m.type()==='error'){errs++;if(!first)first=m.text().slice(0,120)}});
p.on('pageerror',e=>{errs++;if(!first)first='PAGEERROR '+e.message});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+(q?'?'+q:''),{waitUntil:'load'});
await new Promise(r=>setTimeout(r,18000));
await p.screenshot({path:'shots/probe'+(q||'default')+'.png'});
const px=await p.evaluate(()=>{const c=document.getElementById('view');const g=c.getContext('webgl2')||c.getContext('webgl');return {lost:g?g.isContextLost():'nogl',w:c.width,h:c.height}});
console.log(q||'default','errors=',errs,'first=',first,JSON.stringify(px));
await b.close();})();
