const puppeteer=require('puppeteer');const path=require('path');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:900,height:560});
p.on('pageerror',e=>console.log('PAGEERR:',e.message.slice(0,200)));
p.on('console',m=>{const t=m.text();if(/error|Error|нет материала|CONTEXT_LOST/i.test(t))console.log('CON:',t.slice(0,160));});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?q=low',{waitUntil:'load'});
for(let i=0;i<24;i++){
  await wait(5000);
  const s=await p.evaluate(()=>({done:document.getElementById('loader').classList.contains('done'),txt:document.getElementById('ldText').textContent,bar:document.getElementById('ldBar')?document.getElementById('ldBar').style.width:'?',err:window.__renderErr,diag:window.__diag})).catch(e=>({dead:String(e).slice(0,80)}));
  console.log((i+1)*5+'s', JSON.stringify(s));
  if(s.done)break;
}
await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))).catch(()=>{});
await p.screenshot({path:'shots/probe.png'}).catch(()=>{});
await b.close();})();
