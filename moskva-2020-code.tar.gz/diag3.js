const puppeteer=require('puppeteer');const path=require('path');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:1000,height:620});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?q=low',{waitUntil:'load'});
await p.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:180000});
await p.evaluate(()=>document.querySelector('#segCars button[data-cars="4"]').click());
await wait(2500);
await p.evaluate(()=>window.__setCam('bogie'));await wait(3000);
await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
await p.screenshot({path:'shots/g_bogie30.png'});
const probe=await p.evaluate(()=>{
  const T=window.__three,sc=window.__getScene(),cam=window.__cam();
  const rc=new T.Raycaster();const out=[];
  for(const v of [-0.6,0,0.6]) for(const u of [-0.7,-0.35,0,0.35,0.7]){
    rc.setFromCamera(new T.Vector2(u,v),cam);
    const h=rc.intersectObjects(sc.children,true).filter(x=>x.object.visible&&x.object.type==='Mesh');
    out.push({u,v,hit:h[0]?{n:h[0].object.name||h[0].object.parent.name||'?',d:+h[0].distance.toFixed(2),y:+h[0].point.y.toFixed(2),x:+h[0].point.x.toFixed(2),z:+h[0].point.z.toFixed(2)}:null});
  }
  const st=window.__stats();
  // габариты тележки головного вагона
  const car=sc.getObjectByProperty('type','Group');
  return {st,hits:out.filter(o=>o.hit).map(o=>o.u+','+o.v+' -> '+o.hit.n+' d='+o.hit.d+' p='+o.hit.x+'/'+o.hit.y+'/'+o.hit.z)};
});
console.log(JSON.stringify(probe,null,1));
await p.evaluate(()=>{const c=window.__cam();c.fov=62;c.updateProjectionMatrix();});await wait(1500);
await p.screenshot({path:'shots/g_bogie62.png'});
await p.evaluate(()=>{const c=window.__cam(),k=window.__controls();window.__state.follow=false;
  const s=window.__sim; c.position.set(s.x+35.5+3.0,1.9,7.5); k.target.set(s.x+35.5,0.75,0); c.fov=40;c.updateProjectionMatrix();k.update();});
await wait(1800);await p.screenshot({path:'shots/g_bogie_manual.png'});
console.log('errs',errs.slice(0,3));
await b.close();})();
