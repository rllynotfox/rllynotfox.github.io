const puppeteer=require('puppeteer');const path=require('path');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:1280,height:800});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
p.on('console',m=>{const t=m.text();if(/нет материала|CONTEXT_LOST|not of type/i.test(t))errs.push(t.slice(0,120));});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html'),{waitUntil:'load'});
await p.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:180000});
await wait(3000);
await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
await p.screenshot({path:'shots/now_hero.png'});
const o=await p.evaluate(()=>({q:window.__state.quality,cars:window.__stats().cars,len:window.__stats().len,diag:window.__diag,err:window.__renderErr,calls:window.__stats().calls,tris:window.__stats().tris}));
await p.evaluate(()=>window.__setCam('facade'));await wait(2500);
await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
await p.screenshot({path:'shots/now_facade.png'});
console.log(JSON.stringify(o),'errs',errs.slice(0,4));
await b.close();})();
