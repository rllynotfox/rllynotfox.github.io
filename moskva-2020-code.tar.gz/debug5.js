const puppeteer=require('puppeteer');const path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:800,height:520});
const out=[];
p.on('console',m=>{out.push(m.type()+': '+m.text().slice(0,900))});
p.on('pageerror',e=>out.push('PAGEERROR '+e.message));
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?shaderdebug',{waitUntil:'load'});
await new Promise(r=>setTimeout(r,18000));
console.log([...new Set(out)].slice(0,10).join('\n\n---\n\n'));
await b.close();})();
