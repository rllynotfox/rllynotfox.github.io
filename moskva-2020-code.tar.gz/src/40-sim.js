/* ============================================================================
   ДВИЖЕНИЕ, КАМЕРА, ЗВУК
   ========================================================================== */

const sim = {
  x: 0, v: 0, phase: 'approach', tPhase: 0, doorT: 0, doorTarget: 0,
  wheel: 0, wiperT: 0, stopX: 0, dist: 0, clackT: 0, accel: 0
};

function stopPosition() { return PLAT - 5 - trainLen / 2; }

function resetRun() {
  sim.stopX = stopPosition();
  sim.x = -(HALL + trainLen / 2 + 6);   // нос состава у портала тоннеля
  sim.v = state.speedKmh / 3.6;
  sim.phase = 'approach';
  sim.tPhase = 0;
  state.doorsOpen = false;
  sim.doorTarget = 0;
}

function updateSim(dt) {
  const cruise = state.speedKmh / 3.6;
  sim.stopX = stopPosition();
  const prevV = sim.v;
  if (state.studio) {
    sim.phase = 'parked';
    sim.x += (0 - sim.x) * Math.min(1, dt * 2.2);
    sim.v = state.doorsOpen ? 0 : cruise * 0.55;      // стенд: колёса вращаются
  } else if (!state.running) {
    sim.phase = 'parked';
    sim.x += (sim.stopX - sim.x) * Math.min(1, dt * 2.2);
    sim.v = 0;
  } else if (sim.phase === 'parked') {
    sim.phase = 'dwell'; sim.tPhase = 0;
  }
  if (state.running && !state.studio) {
    sim.tPhase += dt;
    if (sim.phase === 'approach') {
      const remain = sim.stopX - sim.x;
      const brakeD = (sim.v * sim.v) / (2 * 1.05) + 1.2;
      if (remain <= brakeD) sim.v = Math.max(0, sim.v - 1.05 * dt);
      else sim.v += (cruise - sim.v) * Math.min(1, dt * 0.6);
      sim.x += sim.v * dt;
      if (sim.x >= sim.stopX - 0.02 || sim.v < 0.02) {
        sim.x = sim.stopX; sim.v = 0; sim.phase = 'dwell'; sim.tPhase = 0;
        audio.event('arrive');
      }
    } else if (sim.phase === 'dwell') {
      sim.v = 0;
      if (sim.tPhase > 1.0 && !state.doorsOpen) setDoors(true);
      if (sim.tPhase > 11.5 && state.doorsOpen) setDoors(false);
      if (sim.tPhase > 14.5) { sim.phase = 'depart'; sim.tPhase = 0; audio.event('depart'); }
    } else if (sim.phase === 'depart') {
      sim.v = Math.min(cruise, sim.v + 1.25 * dt);
      sim.x += sim.v * dt;
      if (sim.x - trainLen / 2 > HALL + 75) resetRun();
    }
  }
  sim.accel = (sim.v - prevV) / Math.max(dt, 1e-4);
  sim.dist += sim.v * dt;
  sim.wheel += sim.v / (SPECS.wheelD / 2) * dt;

  // двери
  const spd = 1 / 1.6;
  sim.doorT += clamp(sim.doorTarget - sim.doorT, -spd * dt, spd * dt);
  const e = smoother(clamp(sim.doorT, 0, 1));
  const out = Math.min(1, sim.doorT * 5) * 0.055;
  for (const car of trainCars) {
    const a = car.userData.anim;
    for (const k of ['doorsL', 'doorsL2', 'doorsR', 'doorsR2']) {
      const g = a[k]; if (!g) continue;
      const dir = g.userData.dir;
      g.position.x = dir * e * (SPECS.doorW / 2 - 0.03);
      g.position.z = dir * 0 + g.userData.side * out;
    }
    for (const w of a.wheels) w.rotation.z = -sim.wheel;
    if (a.wiper) {
      const ang = state.wiper ? Math.sin(sim.wiperT * 2.4) * 0.62 - 0.25 : -0.85;
      a.wiper.matrixAutoUpdate = false;
      a.wiper.matrix.copy(a.wiper.userData.baseM).multiply(new THREE.Matrix4().makeRotationZ(ang));
      a.wiper.matrixWorldNeedsUpdate = true;
    }
  }
  if (state.wiper) sim.wiperT += dt;
  if (trainGroup) trainGroup.position.x = sim.x;

  // фары следуют за головным вагоном
  const fx = sim.x + trainLen / 2;
  headSpots.forEach(h => {
    h.light.position.set(fx - 0.35, 1.95, TZ() + h.side * 1.05);
    h.light.target.position.set(fx + 30, 0.6, TZ() + h.side * 1.6);
  });
  lightCones.forEach(c => {
    c.mesh.position.set(fx - 0.1, 1.95, TZ() + c.side * 1.05);
    c.mesh.rotation.set(0, 0, -0.045);
  });

  if (state.studio && studioFill) {
    const cx = sim.x + trainLen / 2 - 6;
    const sz = camera.position.z >= 0 ? 1 : -1;
    studioFill.position.x = cx + 2; studioFill.position.z = sz * 7.5;
    studioUnder.position.x = cx - 1; studioUnder.position.z = sz * 4.6;
    studioKey.position.x = cx - 14; studioKey.target.position.x = cx; studioKey.target.updateMatrixWorld();
    studioRim.position.x = cx + 18; studioRim.target.position.x = cx; studioRim.target.updateMatrixWorld();
  }
  // тень следует за камерой
  const t = controls.target;
  keyLight.position.set(t.x + 16, 26, t.z + 14);
  keyLight.target.position.set(t.x, 1.5, t.z);

  // пыль
  if (dust) {
    dust.rotation.y += dt * 0.006;
    dust.position.x = Math.sin(clock.elapsedTime * 0.05) * 2;
    dust.material.opacity = 0.18 + state.fog * 0.4;
  }
  audio.update(dt);
}

function setDoors(open) {
  if (open && sim.v > 0.4 && !state.studio) { toast('Двери заблокированы: поезд движется'); return; }
  if (state.doorsOpen === open) return;
  state.doorsOpen = open;
  sim.doorTarget = open ? 1 : 0;
  audio.event(open ? 'doorOpen' : 'doorClose');
  const btn = document.getElementById('btnDoors');
  if (btn) { btn.classList.toggle('on', open); btn.querySelector('.lbl').textContent = open ? 'Закрыть двери' : 'Открыть двери'; }
}
function updateDoorTargets(instant) {
  sim.doorTarget = state.doorsOpen ? 1 : 0;
  if (instant) sim.doorT = sim.doorTarget;
}

/* --------------------------------- камера --------------------------------- */
const CAM = {
  hero:   { name: 'Ракурс',   fov: 40, get: F => state.studio ? { p: [F + 11, 3.4, 10], t: [F - 5, 2.0, 0] } : { p: [F + 6.0, 2.95, TZ() + 6.6], t: [F - 1.6, 2.05, TZ()] } },
  facade: { name: 'Фасад',    fov: 42, get: F => state.studio ? { p: [F + 11, 2.2, 1.2], t: [F - 1, 2.1, 0] } : { p: [F + 6.8, 2.15, TZ() + 0.9], t: [F - 1.5, 2.05, TZ()] } },
  side:   { name: 'Борт',     fov: 45, get: F => state.studio ? { p: [F - 24, 2.6, 11], t: [F - 36, 2.1, 0] } : { p: [F - 22, 2.4, TZ() + 7.6], t: [F - 34, 2.1, TZ()] } },
  cab:    { name: 'Кабина',   fov: 60, get: F => ({ p: [F - 3.35, 2.74, TZ() - 0.52], t: [F + 3.5, 2.18, TZ() + 0.18] }) },
  salon:  { name: 'Салон',    fov: 62, get: F => ({ p: [F - 12.4, 2.40, TZ() - 0.30], t: [F - 23, 2.02, TZ() + 0.25] }) },
  bogie:  { name: 'Тележка',  fov: 40, studio: true, get: F => state.studio ? { p: [F - 0.74, 1.90, 7.5], t: [F - 3.74, 0.75, 0] } : { p: [F - 0.74, 1.95, TZ() + 7.5], t: [F - 3.74, 0.75, TZ()] } },
  roof:   { name: 'Крыша',    fov: 50, get: F => state.studio ? { p: [F - 8, 7.5, 9], t: [F - 18, 3.2, 0] } : { p: [F - 3.5, 4.85, TZ() + 7.4], t: [F - 16, 3.3, TZ()] } },
  pano:   { name: 'Панорама', fov: 62, get: F => state.studio ? { p: [F + 22, 9, 26], t: [F - 60, 2.2, 0] } : { p: [F + 5.5, 4.6, TZ() + 8.8], t: [F - 60, 2.0, TZ()] } }
};
function TZ() { return state.studio ? 0 : TRACK_Z; }
let camTween = null;
function setCamera(key, instant) {
  state.camera = key;
  if (CAM[key].studio && !state.studio) {
    state.studio = true;
    applyMode(); applyLighting();
    document.querySelectorAll('#segMode button').forEach(x => x.classList.toggle('on', x.dataset.mode === 'studio'));
    toast('Детальный осмотр — студийная площадка');
  }
  const F = trainLen / 2;
  const c = CAM[key].get(F);
  const toP = new THREE.Vector3(c.p[0] + sim.x, c.p[1], c.p[2]);
  const toT = new THREE.Vector3(c.t[0] + sim.x, c.t[1], c.t[2]);
  if (CAM[key].fov) {
    state.fov = CAM[key].fov; camera.fov = CAM[key].fov; camera.updateProjectionMatrix();
    const r = document.getElementById('rngFov'); if (r) { r.value = CAM[key].fov; document.getElementById('valFov').textContent = CAM[key].fov + '°'; }
  }
  if (instant) { camera.position.copy(toP); controls.target.copy(toT); camTween = null; }
  else camTween = { fromP: camera.position.clone(), fromT: controls.target.clone(), toP, toT, t: 0, dur: 1.15 };
  document.querySelectorAll('.cam-chip').forEach(el => el.classList.toggle('on', el.dataset.cam === key));
  applyLighting();
}
function updateCamera(dt) {
  if (camTween) {
    camTween.t += dt / camTween.dur;
    const e = smoother(clamp(camTween.t, 0, 1));
    camera.position.lerpVectors(camTween.fromP, camTween.toP, e);
    controls.target.lerpVectors(camTween.fromT, camTween.toT, e);
    if (camTween.t >= 1) camTween = null;
  } else if (state.follow && trainGroup) {
    let dx = sim.x - (trainGroup.userData.lastX ?? sim.x);
    if (!state.studio) {                            // камера остаётся в зале станции
      const nx = controls.target.x + dx;
      const lim = HALL - 7;
      if (nx > lim) dx -= (nx - lim);
      if (nx < -lim) dx += (-lim - nx);
    }
    camera.position.x += dx; controls.target.x += dx;
  }
  if (trainGroup) trainGroup.userData.lastX = sim.x;
  controls.autoRotate = state.autoOrbit && !camTween;
  controls.autoRotateSpeed = 0.45;
  controls.update();
}

/* ---------------------------------- звук ---------------------------------- */
const audio = {
  ctx: null, ready: false, master: null, nodes: {},
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ctx = this.ctx = new AC();
    const master = this.master = ctx.createGain();
    master.gain.value = state.sound ? 0.85 : 0.0;
    master.connect(ctx.destination);

    // шумовой буфер
    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; last = (last + 0.02 * w) / 1.02; d[i] = last * 3.2; }
    this.noiseBuf = buf;

    const mkNoise = (filterType, freq, q, gain) => {
      const src = ctx.createBufferSource(); src.buffer = buf; src.loop = true;
      const f = ctx.createBiquadFilter(); f.type = filterType; f.frequency.value = freq; f.Q.value = q;
      const g = ctx.createGain(); g.gain.value = gain;
      src.connect(f); f.connect(g); g.connect(master); src.start();
      return { src, f, g };
    };
    this.nodes.rumble = mkNoise('lowpass', 160, 0.7, 0.0);
    this.nodes.hiss = mkNoise('bandpass', 1400, 0.8, 0.0);
    this.nodes.squeal = mkNoise('bandpass', 2600, 14, 0.0);
    this.nodes.room = mkNoise('lowpass', 320, 0.5, 0.05);

    // тяговый инвертор
    const osc = ctx.createOscillator(); osc.type = 'sawtooth'; osc.frequency.value = 60;
    const of = ctx.createBiquadFilter(); of.type = 'lowpass'; of.frequency.value = 900; of.Q.value = 3;
    const og = ctx.createGain(); og.gain.value = 0;
    osc.connect(of); of.connect(og); og.connect(master); osc.start();
    this.nodes.motor = { osc, f: of, g: og };

    const osc2 = ctx.createOscillator(); osc2.type = 'sine'; osc2.frequency.value = 400;
    const og2 = ctx.createGain(); og2.gain.value = 0;
    osc2.connect(og2); og2.connect(master); osc2.start();
    this.nodes.inv = { osc: osc2, g: og2 };
    this.ready = true;
  },
  setMuted(m) {
    if (!this.master) return;
    this.master.gain.setTargetAtTime(m ? 0 : 0.85, this.ctx.currentTime, 0.08);
  },
  update(dt) {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    const v = sim.v, vn = clamp(v / 22, 0, 1);
    const inside = ['cab', 'salon'].includes(state.camera);
    const cabFactor = inside ? 0.55 : 1.0;
    this.nodes.rumble.g.gain.setTargetAtTime((0.05 + vn * 0.42) * cabFactor, t, 0.15);
    this.nodes.rumble.f.frequency.setTargetAtTime(90 + vn * 220, t, 0.2);
    this.nodes.hiss.g.gain.setTargetAtTime(vn * vn * 0.10 * cabFactor, t, 0.2);
    const braking = sim.accel < -0.25 && v > 0.6 && v < 9;
    this.nodes.squeal.g.gain.setTargetAtTime(braking ? 0.035 * (1 - v / 9) : 0, t, 0.25);
    this.nodes.squeal.f.frequency.setTargetAtTime(1900 + v * 130, t, 0.3);
    const acc = clamp(sim.accel / 1.3, -1, 1);
    this.nodes.motor.g.gain.setTargetAtTime((Math.abs(acc) > 0.05 ? 0.045 : 0.012) * (0.3 + vn) * cabFactor, t, 0.2);
    this.nodes.motor.osc.frequency.setTargetAtTime(38 + v * 5.2, t, 0.15);
    this.nodes.motor.f.frequency.setTargetAtTime(300 + v * 45, t, 0.2);
    // ступени инвертора при разгоне
    const steps = [180, 260, 340, 430, 540, 680, 850, 1050];
    const si = clamp(Math.floor(v / 2.6), 0, steps.length - 1);
    this.nodes.inv.g.gain.setTargetAtTime(acc > 0.15 ? 0.018 : 0.0, t, 0.15);
    this.nodes.inv.osc.frequency.setTargetAtTime(steps[si], t, 0.08);
    // стук стыков
    if (v > 1) {
      sim.clackT -= dt;
      if (sim.clackT <= 0) { sim.clackT = 12.5 / v * (0.9 + Math.random() * 0.2); this.clack(clamp(v / 20, 0.15, 1) * cabFactor); }
    }
  },
  clack(amp) {
    if (!this.ready) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.noiseBuf;
    src.playbackRate.value = 1.6;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 220 + Math.random() * 120; f.Q.value = 1.6;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.22 * amp, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start(t); src.stop(t + 0.16);
  },
  beep(freq, dur, when, vol, type) {
    if (!this.ready) return;
    const ctx = this.ctx, t = ctx.currentTime + when;
    const o = ctx.createOscillator(); o.type = type || 'sine'; o.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.master);
    o.start(t); o.stop(t + dur + 0.05);
  },
  event(name) {
    if (!this.ready) return;
    if (name === 'doorOpen') { this.beep(880, 0.16, 0, 0.10); this.beep(660, 0.22, 0.17, 0.10); this.pneumatic(0.35); }
    if (name === 'doorClose') {
      for (let i = 0; i < 3; i++) this.beep(1000, 0.10, i * 0.19, 0.09, 'triangle');
      this.pneumatic(0.5, 0.75);
    }
    if (name === 'arrive') this.pneumatic(0.7, 0.0, 1.4);
    if (name === 'depart') { this.beep(520, 0.3, 0.1, 0.06); this.beep(392, 0.5, 0.35, 0.06); }
  },
  pneumatic(vol, when = 0, dur = 0.9) {
    const ctx = this.ctx, t = ctx.currentTime + when;
    const src = ctx.createBufferSource(); src.buffer = this.noiseBuf; src.playbackRate.value = 0.8;
    const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 900;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.09 * vol, t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start(t); src.stop(t + dur + 0.1);
  }
};
