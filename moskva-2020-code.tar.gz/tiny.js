const puppeteer=require('puppeteer');const path=require('path');const fs=require('fs');
const L=s=>fs.appendFileSync('tiny.log',s+'\n');
(async()=>{
fs.writeFileSync('tiny.log','');
const b=await puppeteer.launch({headless:'new',protocolTimeout:45000,
 args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--js-flags=--max-old-space-size=384']});
const p=await b.newPage();
await p.setViewport({width:800,height:500});
p.on('pageerror',e=>L('PAGEERR '+e.message.slice(0,200)));
p.on('error',e=>L('CRASH '+String(e).slice(0,200)));
p.on('console',m=>{const t=m.text();if(/error|нет материала|LOST/i.test(t))L('CON '+t.slice(0,160));});
L('goto');
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?q=low',{waitUntil:'domcontentloaded'});
L('loaded');
for(let i=0;i<8;i++){
  await new Promise(r=>setTimeout(r,4000));
  try{const s=await p.evaluate(()=>({d:document.getElementById('loader').classList.contains('done'),t:document.getElementById('ldText').textContent}));L(i+' '+JSON.stringify(s));if(s.d)break;}
  catch(e){L(i+' EVAL_FAIL '+String(e.message).slice(0,90));break;}
}
try{await p.screenshot({path:'shots/tiny.png'});L('shot ok');}catch(e){L('shot fail');}
await b.close();process.exit(0);
})();
