const puppeteer=require('puppeteer');const path=require('path');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:1000,height:620});
const errs=[];p.on('pageerror',e=>errs.push('PE '+e.message));p.on('console',m=>{if(m.type()==='error')errs.push('CE '+m.text().slice(0,90))});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html')+'?q=low',{waitUntil:'load'});
await p.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:120000});
await p.evaluate(()=>document.querySelector('#segCars button[data-cars="4"]').click());await sleep(3000);
const sync=()=>p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
const shot=async n=>{await sync();await p.screenshot({path:'shots/v_'+n+'.png'});};
await p.evaluate(()=>window.__setCam('bogie'));await sleep(3200);await shot('bogie');
await p.evaluate(()=>window.__setCam('salon'));await sleep(2600);await shot('salon');
await p.evaluate(()=>{document.querySelector('#segMode button[data-mode="station"]').click();});await sleep(3500);
await p.evaluate(()=>{window.__setCam('facade');});await sleep(2600);await shot('facade');
// полный интерактивный цикл
const r=[];
for(const [id,label] of [['btnDoors','doors'],['tgHead','head'],['tgInterior','int'],['tgWiper','wiper'],['tgPeople','people'],['tgOrbit','orbit'],['tgDims','dims'],['tgWire','wire'],['btnSpecs','specs'],['specsX','specsX'],['btnSound','sound'],['btnRun','run']]){
  await p.evaluate(i=>document.getElementById(i).click(),id);await sleep(400);
  r.push(label+':ok');
}
await p.evaluate(()=>{document.getElementById('tgWire').click();document.getElementById('tgDims').click();document.getElementById('tgOrbit').click();document.getElementById('btnRun').click();});
await sleep(600);
for(const [id,v] of [['rngSpeed','80'],['rngFov','50'],['rngDof','60'],['rngLight','140'],['rngWarm','80'],['rngFog','20'],['rngExp','130'],['rngBloom','100'],['rngGrain','10']]){
  await p.evaluate((i,val)=>{const e=document.getElementById(i);e.value=val;e.dispatchEvent(new Event('input'));},id,v);
}
await sleep(1200);
const s1=await p.evaluate(()=>({state:Object.assign({},window.__state),stats:window.__stats()}));
await p.evaluate(()=>document.getElementById('btnReset').click());await sleep(4000);
await p.evaluate(()=>window.__setCam('hero'));await sleep(2500);await shot('after_reset');
// мышь: орбита
await p.mouse.move(400,320);await p.mouse.down();await p.mouse.move(520,300,{steps:8});await p.mouse.up();await sleep(1500);
await shot('orbited');
// мобильный
await p.setViewport({width:390,height:780});await sleep(2500);await shot('mobile');
const ov=await p.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,sh:document.documentElement.scrollHeight,ch:document.documentElement.clientHeight}));
await p.evaluate(()=>document.getElementById('btnPanel').click());await sleep(1000);await shot('mobile_dock');
const s2=await p.evaluate(()=>({diag:window.__diag,renderErr:window.__renderErr||null,stats:window.__stats()}));
console.log('CLICKS',r.join(' '));
console.log('S1',JSON.stringify(s1.state).slice(0,420));
console.log('OVERFLOW',JSON.stringify(ov));
console.log('S2',JSON.stringify(s2));
console.log('ERRORS',errs.slice(0,6));
await b.close();})();
