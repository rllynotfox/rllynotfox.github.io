/* ============================================================================
   ИНТЕРФЕЙС, ГАБАРИТНАЯ СХЕМА, ЗАПУСК
   ========================================================================== */

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let toastT = 0, wantShot = false, dimGroup = null;

function toast(msg) {
  const el = $('#toast');
  el.textContent = msg; el.classList.add('show');
  clearTimeout(toastT);
  toastT = setTimeout(() => el.classList.remove('show'), 2400);
}

/* ------------------------- габаритная схема в 3D --------------------------- */
function labelSprite(text, color = '#7fe9ff') {
  const c = cvs(512, 128), g = c.getContext('2d');
  g.clearRect(0, 0, 512, 128);
  g.fillStyle = 'rgba(6,14,18,0.82)';
  const w = 512, h = 128, r = 26;
  g.beginPath(); g.roundRect(4, 22, w - 8, h - 44, r); g.fill();
  g.strokeStyle = color; g.lineWidth = 3; g.stroke();
  g.fillStyle = color; g.font = '700 52px "Segoe UI", Arial, sans-serif';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, w / 2, h / 2 + 2);
  const m = new THREE.SpriteMaterial({ map: tex(c, { clamp: true }), transparent: true, depthTest: false, depthWrite: false, toneMapped: false });
  const s = new THREE.Sprite(m);
  s.scale.set(1.9, 0.475, 1);
  s.renderOrder = 999;
  return s;
}
function dimLine(a, b, text, off) {
  const g = new THREE.Group();
  const col = 0x7fe9ff;
  const mat = new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: 0.85, depthTest: false });
  const A = new THREE.Vector3(...a), Bp = new THREE.Vector3(...b);
  const dir = new THREE.Vector3().subVectors(Bp, A).normalize();
  const up = Math.abs(dir.y) > 0.9 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0);
  const tick = new THREE.Vector3().crossVectors(dir, up).normalize().multiplyScalar(0.16);
  const pts = [A, Bp,
    A.clone().add(tick), A.clone().sub(tick),
    Bp.clone().add(tick), Bp.clone().sub(tick)];
  const geo = new THREE.BufferGeometry().setFromPoints(pts);
  const line = new THREE.LineSegments(geo, mat);
  line.renderOrder = 998;
  g.add(line);
  const sp = labelSprite(text);
  sp.position.copy(A).add(Bp).multiplyScalar(0.5).add(new THREE.Vector3(...(off || [0, 0.32, 0])));
  g.add(sp);
  return g;
}
function buildDimensions() {
  if (dimGroup) { disposeGroup(dimGroup); dimGroup = null; }
  const car = trainCars[0];
  if (!car) return;
  dimGroup = new THREE.Group();
  const f = 9.60, r = -9.60, hw = DIM.hw;
  dimGroup.add(dimLine([r, 0.30, hw + 0.9], [f, 0.30, hw + 0.9], '20 080 мм', [0, 0.34, 0]));
  dimGroup.add(dimLine([f + 0.9, DIM.yb, -hw], [f + 0.9, DIM.yb, hw], '2 740 мм', [0.2, 0.34, 0]));
  dimGroup.add(dimLine([f + 0.9, 0, hw + 0.55], [f + 0.9, DIM.yt, hw + 0.55], '3 680 мм', [0.5, 0, 0]));
  dimGroup.add(dimLine([-6.30, 0.12, -hw - 0.55], [6.30, 0.12, -hw - 0.55], 'база 12 600', [0, 0.3, 0]));
  dimGroup.add(dimLine([-7.90, 1.55, hw + 0.35], [-6.30, 1.55, hw + 0.35], 'дверь 1 600', [0, 0.3, 0]));
  dimGroup.add(dimLine([f + 2.2, 0.02, -0.76], [f + 2.2, 0.02, 0.76], 'колея 1 520', [0, 0.3, 0]));
  dimGroup.add(dimLine([-7.40, 0.05, hw + 0.2], [-5.20, 0.05, hw + 0.2], 'тележка 2 200', [0, 0.28, 0]));
  car.add(dimGroup);
  dimGroup.visible = state.dimensions;
}

/* ------------------------------ привязка UI ------------------------------- */
function bindUI() {
  // ракурсы
  const cams = $('#cams');
  Object.keys(CAM).forEach((k, i) => {
    const b = document.createElement('button');
    b.className = 'cam-chip' + (k === state.camera ? ' on' : '');
    b.dataset.cam = k;
    b.innerHTML = `<small>${i + 1}</small>${CAM[k].name}`;
    b.onclick = () => { setCamera(k); audio.init(); };
    cams.appendChild(b);
  });

  $('#segCars').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    state.cars = +b.dataset.cars;
    $$('#segCars button').forEach(x => x.classList.toggle('on', x === b));
    rebuild();
  };
  $('#liveryBox').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    state.livery = b.dataset.liv;
    $$('#liveryBox .lv').forEach(x => x.classList.toggle('on', x === b));
    rebuild();
  };
  $('#segMode').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    state.studio = b.dataset.mode === 'studio';
    $$('#segMode button').forEach(x => x.classList.toggle('on', x === b));
    applyMode(); applyLighting(); setCamera(state.camera);
    if (state.studio) { state.doorsOpen = false; updateDoorTargets(true); $('#btnDoors').classList.remove('on'); $('#btnDoors').querySelector('.lbl').textContent = 'Открыть двери'; }
    toast(state.studio ? 'Студийная площадка' : 'Станция «' + LIVERIES[state.livery].station + '»');
  };
  $('#segQuality').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    state.quality = b.dataset.q;
    $$('#segQuality button').forEach(x => x.classList.toggle('on', x === b));
    allocTargets();
    toast('Качество: ' + b.textContent);
  };

  const runBtn = $('#btnRun');
  runBtn.onclick = () => {
    state.running = !state.running;
    runBtn.classList.toggle('on', state.running);
    runBtn.querySelector('.ico').textContent = state.running ? '❚❚' : '▶';
    runBtn.querySelector('.lbl').textContent = state.running ? 'Рейс выполняется' : 'Стоянка у платформы';
    if (!state.running) setDoors(false);
    audio.init();
  };
  $('#btnDoors').onclick = () => { setDoors(!state.doorsOpen); audio.init(); };

  const tg = (id, key, after) => {
    const el = $(id);
    el.onclick = () => {
      state[key] = !state[key];
      el.classList.toggle('on', state[key]);
      if (after) after();
      audio.init();
    };
  };
  tg('#tgHead', 'headlights', applyLighting);
  tg('#tgInterior', 'interiorLight', applyLighting);
  tg('#tgWiper', 'wiper');
  tg('#tgPeople', 'passengers', rebuild);
  tg('#tgFollow', 'follow');
  tg('#tgOrbit', 'autoOrbit');
  tg('#tgDims', 'dimensions', () => { if (dimGroup) dimGroup.visible = state.dimensions; });
  tg('#tgWire', 'wireframe', () => {
    for (const k in MATS) if (MATS[k].isMaterial) MATS[k].wireframe = state.wireframe;
  });

  const rng = (id, valId, key, scale, fmt, after) => {
    const el = $(id), out = $(valId);
    const upd = () => {
      const v = +el.value * scale;
      state[key] = v;
      out.textContent = fmt(v);
      if (after) after();
    };
    el.oninput = upd; upd();
  };
  rng('#rngSpeed', '#valSpeed', 'speedKmh', 1, v => v + ' км/ч');
  rng('#rngFov', '#valFov', 'fov', 1, v => v + '°', () => { camera.fov = state.fov; camera.updateProjectionMatrix(); });
  rng('#rngDof', '#valDof', 'dof', 0.01, v => Math.round(v * 100) + '%');
  rng('#rngLight', '#valLight', 'lightLevel', 0.01, v => Math.round(v * 100) + '%', applyLighting);
  rng('#rngWarm', '#valWarm', 'lightWarm', 0.01, v => Math.round(v * 100) + '%', applyLighting);
  rng('#rngFog', '#valFog', 'fog', 0.01, v => Math.round(v * 100) + '%', applyLighting);
  rng('#rngExp', '#valExp', 'exposure', 0.01, v => v.toFixed(2));
  rng('#rngBloom', '#valBloom', 'bloom', 0.01, v => Math.round(v * 100) + '%');
  rng('#rngGrain', '#valGrain', 'grain', 0.01, v => Math.round(v * 100) + '%');

  $('#btnSound').onclick = () => {
    state.sound = !state.sound;
    const b = $('#btnSound');
    b.classList.toggle('on', state.sound); b.classList.toggle('off', !state.sound);
    audio.init(); audio.setMuted(!state.sound);
  };
  $('#btnSpecs').onclick = () => $('#specs').classList.add('open');
  $('#specsX').onclick = () => $('#specs').classList.remove('open');
  $('#specs').onclick = e => { if (e.target.id === 'specs') $('#specs').classList.remove('open'); };
  $('#btnShot').onclick = () => { wantShot = true; toast('Сохраняю кадр…'); };
  $('#btnPanel').onclick = () => $('#dock').classList.toggle('hidden');
  $('#btnReset').onclick = () => {
    Object.assign(state, {
      speedKmh: 62, running: true, doorsOpen: false, headlights: true, interiorLight: true,
      passengers: true, wiper: false, wireframe: false, dimensions: false, autoOrbit: false,
      follow: true, bloom: 0.62, dof: 0.35, fog: 0.55, exposure: 1.05, lightWarm: 0.42,
      lightLevel: 1.0, grain: 0.35, quality: BOOT_QUALITY,
      studio: false, livery: 'bkl', cars: 8, camera: 'hero'
    });
    $$('#segMode button').forEach(x => x.classList.toggle('on', x.dataset.mode === 'station'));
    $$('#segCars button').forEach(x => x.classList.toggle('on', +x.dataset.cars === state.cars));
    $$('#liveryBox .lv').forEach(x => x.classList.toggle('on', x.dataset.liv === state.livery));
    const set = (id, v) => { const e = $(id); e.value = v; e.dispatchEvent(new Event('input')); };
    set('#rngSpeed', 62); set('#rngFov', 38); set('#rngDof', 35); set('#rngLight', 100);
    set('#rngWarm', 42); set('#rngFog', 55); set('#rngExp', 105); set('#rngBloom', 62); set('#rngGrain', 35);
    $$('.tg').forEach(el => {
      const on = ['tgHead', 'tgInterior', 'tgPeople', 'tgFollow'].includes(el.id);
      el.classList.toggle('on', on);
    });
    $$('#segQuality button').forEach(x => x.classList.toggle('on', x.dataset.q === state.quality));
    $('#btnRun').classList.add('on');
    $('#btnRun').querySelector('.ico').textContent = '❚❚';
    $('#btnRun').querySelector('.lbl').textContent = 'Рейс выполняется';
    $('#btnDoors').classList.remove('on');
    $('#btnDoors').querySelector('.lbl').textContent = 'Открыть двери';
    buildStation(true); rebuild(); allocTargets(); resetRun();
    sim.x = sim.stopX; sim.v = 0; sim.phase = 'dwell'; sim.tPhase = 0;
    trainGroup.position.x = sim.x; trainGroup.userData.lastX = sim.x;
    setCamera('hero', true);
    toast('Настройки сброшены');
  };

  addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT') return;
    const k = e.key.toLowerCase();
    const keys = Object.keys(CAM);
    if (k >= '1' && k <= '8') { setCamera(keys[+k - 1]); return; }
    if (k === ' ' || k === 'spacebar') { e.preventDefault(); $('#btnRun').click(); }
    if (k === 'd' || k === 'в') $('#btnDoors').click();
    if (k === 's' || k === 'ы') $('#btnSound').click();
    if (k === 'i' || k === 'ш') $('#specs').classList.toggle('open');
    if (k === 'p' || k === 'з') $('#btnShot').click();
    if (k === 'h' || k === 'р') $('#btnPanel').click();
    if (k === 'escape') $('#specs').classList.remove('open');
    if (k === 'f' || k === 'а') $('#tgFollow').click();
    if (k === 'o' || k === 'щ') $('#tgOrbit').click();
  });
  addEventListener('pointerdown', () => audio.init(), { once: true });
  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    allocTargets();
  });
  renderer.domElement.addEventListener('pointerdown', () => { camTween = null; });
}

function updateHud() {
  const v = Math.round(sim.v * 3.6);
  $('#hudV').textContent = v;
  $('#hudBar').style.width = clamp(v / 90 * 100, 0, 100) + '%';
  const names = { approach: 'Подход к платформе', dwell: state.doorsOpen ? 'Посадка пассажиров' : 'Стоянка', depart: 'Отправление', parked: state.studio ? 'Стенд · студия' : 'Стоянка у платформы' };
  $('#hudPhase').textContent = names[sim.phase] || '—';
}

function updateMeta() {
  const L = LIVERIES[state.livery];
  $('#lineNum').textContent = L.line;
  $('#lineNum').style.background = L.lineColor;
  $('#lineName').textContent = L.lineName;
  $('#hudStation').textContent = L.station;
  $('#hudCars').textContent = `${state.cars} вагонов · ${trainLen.toFixed(1).replace('.', ',')} м`;
  const comp = { 4: 'Мг + Пп + Мп + Мг', 6: 'Мг + Пп + 2×Мп + Пп + Мг', 8: 'Мг + Пп + 4×Мп + Пп + Мг' }[state.cars];
  $('#consistNote').textContent = `${comp} · ${trainLen.toFixed(1).replace('.', ',')} м`;
  document.documentElement.style.setProperty('--acc2', L.lineColor === '#8d5b4c' ? '#d98a5a' : L.accent === 0x25bcd2 ? '#25bcd2' : '#e0342f');
}

function rebuild() {
  const wasRunning = state.running;
  const oldLen = trainLen, oldPhase = sim.phase;
  const nose = sim.x + oldLen / 2;                 // сохраняем положение головной части
  buildStation();
  buildTrain();
  buildDimensions();
  applyMode();
  for (const k in MATS) if (MATS[k].isMaterial) MATS[k].wireframe = state.wireframe;
  updateMeta();
  // состав новой длины обязан остаться у платформы, иначе камера смотрит в пустоту
  sim.stopX = stopPosition();
  if (state.studio) { sim.x = 0; sim.phase = 'parked'; }
  else if (oldPhase === 'dwell' || oldPhase === 'parked') { sim.x = sim.stopX; sim.phase = 'dwell'; sim.tPhase = 0; }
  else sim.x = nose - trainLen / 2;
  if (trainGroup) { trainGroup.position.x = sim.x; trainGroup.userData.lastX = sim.x; }
  applyLighting();
  setCamera(state.camera, true);
  state.running = wasRunning;
}

/* --------------------------------- запуск --------------------------------- */
const LD = [
  [8, 'Инициализация WebGL…'],
  [22, 'Процедурные текстуры и HDR-окружение…'],
  [40, 'Сборка станции и пути…'],
  [62, 'Кузова, маски, дверные системы…'],
  [82, 'Тележки, салон, кабина…'],
  [95, 'Компиляция шейдеров…'],
  [100, 'Готово']
];
function setLoad(i) {
  $('#ldBar').style.width = LD[i][0] + '%';
  $('#ldText').textContent = LD[i][1];
}
const nextFrame = () => new Promise(r => requestAnimationFrame(() => setTimeout(r, 0)));

async function main() {
  setLoad(0); await nextFrame();
  initRenderer($('#view'));
  BOOT_QUALITY = state.quality;
  setLoad(1); await nextFrame();
  buildMaterials(LIVERIES[state.livery]);
  setLoad(2); await nextFrame();
  buildStation();
  setLoad(3); await nextFrame();
  buildTrain();
  setLoad(4); await nextFrame();
  buildDimensions();
  applyMode();
  bindUI();
  if (innerWidth < 900) $('#dock').classList.add('hidden');
  $$('#segQuality button').forEach(x => x.classList.toggle('on', x.dataset.q === state.quality));
  updateMeta();
  applyLighting();
  resetRun();
  sim.x = sim.stopX; sim.v = 0; sim.phase = 'dwell'; sim.tPhase = 0;
  trainGroup.position.x = sim.x;
  setCamera('hero', true);
  setLoad(5); await nextFrame();
  renderer.compile(scene, camera);
  renderFrame(0.016, 0);
  setLoad(6); await nextFrame();
  $('#loader').classList.add('done');
  setTimeout(() => { $('#loader').style.display = 'none'; }, 700);
  if (SOFTWARE) setTimeout(() => toast('Программный рендеринг: включён облегчённый режим'), 1200);
  loop();
}

let BOOT_QUALITY = 'high';
let last = 0, fpsAcc = 0, fpsN = 0, autoDowngraded = false;
function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, clock.getDelta());
  const t = clock.elapsedTime;
  updateSim(dt);
  updateCamera(dt);
  updateHud();
  try { renderFrame(dt, t); } catch (err) { if (!window.__renderErr) { window.__renderErr = String(err && err.message || err); } }
  if (wantShot) {
    wantShot = false;
    try {
      const a = document.createElement('a');
      a.download = 'moskva-2020_' + Date.now() + '.png';
      a.href = renderer.domElement.toDataURL('image/png');
      a.click();
      toast('Кадр сохранён');
    } catch (err) { toast('Не удалось сохранить кадр'); }
  }
  // адаптивное качество
  fpsAcc += dt; fpsN++;
  if (fpsAcc > 3) {
    const fps = fpsN / fpsAcc;
    if (fps < 26 && !autoDowngraded && state.quality === 'high') {
      autoDowngraded = true;
      state.quality = 'medium';
      $$('#segQuality button').forEach(x => x.classList.toggle('on', x.dataset.q === 'medium'));
      allocTargets();
      toast('Качество снижено для плавности (можно вернуть в панели)');
    }
    fpsAcc = 0; fpsN = 0;
  }
}

/* отладочные хуки (используются автотестами и не влияют на работу) */
window.__setCam = k => setCamera(k, true);
window.__state = state;
window.__getScene = () => scene;
window.__three = THREE;
window.__cam = () => camera;
window.__controls = () => controls;
window.__sim = sim;
window.__park = v => { state.running = !v; };
window.__stats = () => ({
  calls: renderer.info.render.calls, tris: renderer.info.render.triangles,
  programs: renderer.info.programs.length, textures: renderer.info.memory.textures,
  geometries: renderer.info.memory.geometries, phase: sim.phase, cars: trainCars.length,
  len: +trainLen.toFixed(2), cam: state.camera,
  cp: camera.position.toArray().map(v => +v.toFixed(2)), ct: controls.target.toArray().map(v => +v.toFixed(2)),
  tp: trainGroup ? trainGroup.position.toArray().map(v => +v.toFixed(2)) : null, sx: +sim.x.toFixed(2),
  lastX: trainGroup && trainGroup.userData.lastX !== undefined ? +trainGroup.userData.lastX.toFixed(2) : null,
  studio: state.studio, follow: state.follow
});

main();
