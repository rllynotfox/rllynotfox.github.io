/* ============================================================================
   УЗЛЫ ВАГОНА: крыша, подкузовное оборудование, тележки, салон, кабина
   ========================================================================== */

function buildRoof(cfg, B, G) {
  const len = cfg.noseStart - cfg.rear;
  const cx = (cfg.rear + cfg.noseStart) / 2;
  // продольный кабельный канал
  B.box('roof', len - 0.4, 0.07, 0.34, cx, DIM.yt + 0.02, 0);
  // кондиционеры салона
  const acs = cfg.head ? [-5.4, -0.4, 4.2] : [-4.6, 0, 4.6];
  for (const ax of acs) {
    const w = 2.55, d = 1.92, h = 0.26;
    B.add('under', plate(d, w, 0.18, h), M4(ax, DIM.yt + 0.01, 0, 0, 0, 0).multiply(
      new THREE.Matrix4().makeRotationX(-Math.PI / 2)).multiply(new THREE.Matrix4().makeRotationZ(Math.PI / 2)));
    for (let i = 0; i < 7; i++) B.box('under', 0.16, 0.03, d - 0.35, ax - 1.0 + i * 0.33, DIM.yt + h + 0.01, 0);
    B.box('underDark', w - 0.2, 0.05, 0.10, ax, DIM.yt + 0.10, d / 2 - 0.06);
    B.box('underDark', w - 0.2, 0.05, 0.10, ax, DIM.yt + 0.10, -d / 2 + 0.06);
  }
  if (cfg.head) { // кондиционер кабины
    B.box('under', 1.10, 0.20, 1.55, 7.35, DIM.yt + 0.06, 0);
    for (let i = 0; i < 4; i++) B.box('under', 0.12, 0.03, 1.2, 6.95 + i * 0.26, DIM.yt + 0.17, 0);
    // антенны
    for (const s of [-1, 1]) B.box('underDark', 0.30, 0.09, 0.14, 8.30, DIM.yt - 0.02, s * 0.55);
  }
  for (const s of [-1, 1]) B.box('underDark', 0.42, 0.08, 0.16, cfg.rear + 1.2, DIM.yt + 0.02, s * 0.62);
  // водосточные желоба
  for (const s of [-1, 1]) B.box('roof', len, 0.05, 0.07, cx, DIM.yt - 0.06, s * (DIM.hw - 0.10));
}

function buildUnderframe(cfg, B, G, number) {
  // всё подкузовное оборудование — строго МЕЖДУ тележками (тележки на ±6.3, длина рамы 3.05)
  const boxes = cfg.head
    ? [[-3.85, 1.55], [-1.85, 2.15], [0.55, 2.35], [3.05, 2.15]]
    : [[-3.90, 1.60], [-1.80, 2.30], [0.70, 2.40], [3.20, 2.10]];
  for (const [bx, bl] of boxes) {
    const h = 0.52 + (Math.abs(bx) % 1) * 0.16;
    B.box('under', bl, h, 1.90, bx, 1.00 - h / 2, 0);
    B.box('underDark', bl - 0.12, 0.04, 1.76, bx, 1.00 - h - 0.01, 0);
    for (const s of [-1, 1]) {
      B.box('underDark', bl - 0.25, 0.05, 0.03, bx, 1.00 - h * 0.35, s * 0.96);
      B.box('steelDark', 0.08, 0.10, 0.04, bx - bl / 2 + 0.2, 1.00 - h * 0.6, s * 0.96);
      B.box('steelDark', 0.08, 0.10, 0.04, bx + bl / 2 - 0.2, 1.00 - h * 0.6, s * 0.96);
    }
  }
  // тормозные резисторы с рёбрами
  for (const bx of [cfg.head ? -2.9 : -2.8, 2.0]) {
    for (let i = 0; i < 9; i++) B.box('steelDark', 0.035, 0.30, 1.66, bx - 0.4 + i * 0.10, 0.62, 0);
  }
  // главные резервуары
  for (const s of [-1, 1]) for (const bx of [-3.4, 3.4]) {
    B.cyl('under', 0.155, 0.155, 1.30, 14, bx, 0.80, s * 1.13, [0, 0, Math.PI / 2]);
    B.cyl('steelDark', 0.165, 0.165, 0.05, 14, bx - 0.64, 0.80, s * 1.13, [0, 0, Math.PI / 2]);
    B.cyl('steelDark', 0.165, 0.165, 0.05, 14, bx + 0.64, 0.80, s * 1.13, [0, 0, Math.PI / 2]);
  }
  // рама кузова и кабельные трассы
  B.box('underDark', cfg.noseStart - cfg.rear - 0.2, 0.10, 2.30, (cfg.rear + cfg.noseStart) / 2, 1.02, 0);
  for (const s of [-1, 1]) {
    B.box('underDark', cfg.noseStart - cfg.rear - 1.0, 0.07, 0.10, (cfg.rear + cfg.noseStart) / 2, 0.96, s * 1.22);
    B.box('skirt', cfg.noseStart - cfg.rear - 0.3, 0.20, 0.04, (cfg.rear + cfg.noseStart) / 2, 1.06, s * (DIM.hw - 0.03));
  }
  // подножки
  for (const s of [-1, 1]) B.box('steelDark', 0.55, 0.04, 0.22, cfg.rear + 0.55, 0.62, s * (DIM.hw - 0.05));
}

/* --------------------------------- тележки -------------------------------- */
function buildBogies(cfg, B, G) {
  const wheels = [];
  const wr = SPECS.wheelD / 2, wz = 0.80;
  for (let bi = 0; bi < 2; bi++) {
    const bx = cfg.bogies[bi];
    const front = cfg.head && bi === 1;
    // рама
    for (const s of [-1, 1]) {
      B.box('under', 3.05, 0.24, 0.20, bx, 0.62, s * 1.03);
      B.box('under', 0.34, 0.30, 0.24, bx, 0.62, s * 1.03);
    }
    for (const e of [-1, 1]) B.box('under', 0.22, 0.22, 2.06, bx + e * 1.44, 0.62, 0);
    B.box('under', 0.62, 0.32, 2.10, bx, 0.80, 0);
    B.box('steelDark', 0.30, 0.14, 0.30, bx, 0.99, 0);
    // пневморессоры
    for (const s of [-1, 1]) {
      B.cyl('rubber', 0.20, 0.22, 0.20, 16, bx, 0.99, s * 0.86);
      B.cyl('rubber', 0.225, 0.225, 0.045, 16, bx, 0.99, s * 0.86);
      B.cyl('steelDark', 0.19, 0.19, 0.04, 16, bx, 1.10, s * 0.86);
      // гасители колебаний
      B.cyl('steelDark', 0.045, 0.045, 0.44, 10, bx + 0.30, 0.86, s * 1.00, [0, 0, 0.5]);
      B.cyl('steelDark', 0.04, 0.04, 0.55, 10, bx - 0.25, 0.70, s * 0.95, [Math.PI / 2, 0, 0]);
    }
    for (const a of [-1, 1]) {
      const ax = bx + a * SPECS.bogieBase / 2;
      // буксы и первичное подвешивание
      for (const s of [-1, 1]) {
        B.box('under', 0.32, 0.30, 0.24, ax, 0.42, s * 1.03);
        B.box('steelDark', 0.26, 0.06, 0.20, ax, 0.28, s * 1.03);
        for (const dx of [-0.14, 0.14]) {
          for (let k = 0; k < 4; k++) {
            const t = new THREE.TorusGeometry(0.062, 0.016, 5, 10);
            B.add('steelDark', t, M4(ax + dx, 0.55 + k * 0.045, s * 1.03, Math.PI / 2, 0, 0));
          }
          B.cyl('under', 0.05, 0.05, 0.22, 8, ax + dx, 0.62, s * 1.03);
        }
        // блок-тормоз
        B.box('under', 0.16, 0.20, 0.26, ax + a * 0.30, 0.44, s * 0.94);
        B.cyl('steelDark', 0.03, 0.03, 0.22, 8, ax + a * 0.20, 0.44, s * 0.86, [0, 0, Math.PI / 2]);
        // токоприёмник
        B.box('underDark', 0.30, 0.07, 0.12, ax, 0.30, s * 1.30);
        B.box('steelDark', 0.26, 0.05, 0.09, ax, 0.255, s * 1.30);
        B.box('under', 0.06, 0.22, 0.06, ax, 0.40, s * 1.26);
      }
      // тяговый привод
      if (cfg.motor) {
        for (const s of [-1, 1]) {
          B.cyl('under', 0.175, 0.175, 0.72, 16, ax - a * 0.42, 0.52, s * 0.44, [0, 0, Math.PI / 2]);
          B.cyl('steelDark', 0.185, 0.185, 0.05, 16, ax - a * 0.78, 0.52, s * 0.44, [0, 0, Math.PI / 2]);
          B.box('under', 0.34, 0.36, 0.30, ax, 0.44, s * 0.44);
          B.cyl('steelDark', 0.03, 0.03, 0.40, 8, ax - a * 0.30, 0.72, s * 0.60, [0, 0.4, Math.PI / 2]);
        }
      }
      // колёсная пара (вращается)
      const wg = new THREE.Group();
      const WB = new Builder();
      WB.cyl('steelDark', 0.075, 0.075, 1.62, 12, 0, 0, 0, [Math.PI / 2, 0, 0]);
      for (const s of [-1, 1]) {
        WB.cyl('tread', wr, wr, 0.135, 30, 0, 0, s * wz, [Math.PI / 2, 0, 0]);
        WB.cyl('wheel', wr + 0.026, wr + 0.026, 0.028, 30, 0, 0, s * (wz - 0.075), [Math.PI / 2, 0, 0]);
        WB.cyl('wheel', 0.30, 0.30, 0.07, 24, 0, 0, s * (wz - 0.01), [Math.PI / 2, 0, 0]);
        WB.cyl('steelDark', 0.125, 0.125, 0.17, 16, 0, 0, s * (wz - 0.02), [Math.PI / 2, 0, 0]);
        for (let k = 0; k < 6; k++) {
          const an = k / 6 * Math.PI * 2;
          WB.cyl('underDark', 0.045, 0.045, 0.09, 8, Math.cos(an) * 0.20, Math.sin(an) * 0.20, s * (wz - 0.01), [Math.PI / 2, 0, 0]);
        }
      }
      WB.flush(MATS, wg, { cast: true, receive: true });
      wg.position.set(ax, wr, 0);
      G.add(wg);
      wheels.push(wg);
    }
    // брус токоприёмника
    for (const s of [-1, 1]) B.box('underDark', 2.4, 0.09, 0.09, bx, 0.34, s * 1.30);
    // катушки АРС на передней тележке головного вагона
    if (front) {
      for (const s of [-1, 1]) {
        B.box('under', 0.42, 0.16, 0.26, bx + 1.60, 0.30, s * 0.42);
        B.box('underDark', 0.36, 0.04, 0.20, bx + 1.60, 0.21, s * 0.42);
      }
      B.box('under', 0.18, 0.26, 0.16, bx + 1.30, 0.42, 1.30); // срывной клапан
    }
    // шкворневая тяга
    B.cyl('steelDark', 0.05, 0.05, 0.70, 10, bx - 0.55, 0.86, 0, [0, 0, Math.PI / 2]);
  }
  return wheels;
}

/* ---------------------------------- салон --------------------------------- */
function ensurePeopleMats() {
  if (MATS.cloth0) return;
  const cols = [0x2b3a55, 0x4a4f57, 0x6b5b4a, 0x3d4f43, 0x7a3b3b, 0x2f4f6f];
  cols.forEach((c, i) => MATS['cloth' + i] = new THREE.MeshStandardMaterial({ color: c, roughness: 0.88 }));
  MATS.trouser = new THREE.MeshStandardMaterial({ color: 0x2a2d33, roughness: 0.9 });
}

function person(B, x, y, z, seated, face, ci) {
  const cl = 'cloth' + ci;
  const s = 1;
  const torsoY = seated ? y + 0.42 : y + 1.05;
  const hipY = seated ? y + 0.20 : y + 0.82;
  // голова
  const hg = new THREE.SphereGeometry(0.105, 12, 10);
  hg.scale(1, 1.15, 1);
  B.add('skin', hg, M4(x, torsoY + 0.36, z));
  const hair = new THREE.SphereGeometry(0.112, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.62);
  B.add('hair', hair, M4(x, torsoY + 0.38, z));
  // торс
  const tg = new THREE.CapsuleGeometry(0.15, 0.34, 4, 10);
  tg.scale(1.0, 1, 0.72);
  B.add(cl, tg, M4(x, torsoY, z));
  // руки
  for (const sd of [-1, 1]) {
    const ag = new THREE.CapsuleGeometry(0.048, 0.34, 3, 7);
    B.add(cl, ag, M4(x + sd * 0.17, torsoY - 0.02, z + (seated ? 0.06 : 0), seated ? 0.35 : 0.05, 0, sd * 0.10));
  }
  if (seated) {
    const th = new THREE.CapsuleGeometry(0.075, 0.30, 3, 8);
    for (const sd of [-1, 1]) B.add('trouser', th, M4(x + sd * 0.09, hipY + 0.03, z + face * 0.22, Math.PI / 2, 0, 0));
    const sh = new THREE.CapsuleGeometry(0.062, 0.34, 3, 8);
    for (const sd of [-1, 1]) B.add('trouser', sh, M4(x + sd * 0.09, hipY - 0.22, z + face * 0.40));
  } else {
    for (const sd of [-1, 1]) {
      const lg = new THREE.CapsuleGeometry(0.072, 0.62, 3, 8);
      B.add('trouser', lg, M4(x + sd * 0.09, y + 0.42, z));
    }
  }
}

function buildInterior(cfg, G, L, anim) {
  ensurePeopleMats();
  const B = new Builder();
  const x0 = cfg.rear + 0.12, x1 = cfg.head ? cfg.cabWall : cfg.front - 0.12;
  const len = x1 - x0, cx = (x0 + x1) / 2;
  const F = DIM.floorH;
  // пол и потолок
  B.box('interiorFloor', len, 0.05, 2.58, cx, F - 0.02, 0);
  B.box('interiorWall', len, 0.05, 2.50, cx, 3.28, 0);
  B.box('interiorWall', len, 0.16, 2.30, cx, 3.20, 0);
  // световые модули потолка
  for (const s of [-1, 1]) {
    B.box('ledWarm', len - 0.5, 0.03, 0.20, cx, 3.185, s * 0.72);
    B.box('interiorWall', len - 0.4, 0.06, 0.30, cx, 3.22, s * 0.72);
  }
  // боковые стены под окнами и над окнами
  for (const s of [-1, 1]) {
    B.box('interiorWall', len, 0.56, 0.05, cx, F + 0.28, s * 1.30);
    B.box('interiorWall', len, 0.34, 0.05, cx, 2.96, s * 1.30);
    B.box('steelDark', len, 0.04, 0.06, cx, DIM.winBot - 0.02, s * 1.29);
  }
  // диваны
  const ds = cfg.doors.slice().sort((a, b) => a - b);
  const gaps = [];
  let cur = x0;
  for (const d of ds) { gaps.push([cur, d - SPECS.doorW / 2 - 0.12]); cur = d + SPECS.doorW / 2 + 0.12; }
  gaps.push([cur, x1]);
  for (const gp of gaps) {
    const w = gp[1] - gp[0];
    if (w < 0.7) continue;
    for (const s of [-1, 1]) {
      const z = s * 1.06;
      const seatW = Math.min(w, 2.30);
      const sx = (gp[0] + gp[1]) / 2;
      B.box('seatBase', seatW, 0.34, 0.46, sx, F + 0.17, z);
      const cush = plate(seatW, 0.46, 0.06, 0.10);
      B.add('seat', cush, M4(sx, F + 0.40, z, -Math.PI / 2, 0, 0));
      const back = plate(seatW, 0.62, 0.07, 0.09);
      B.add('seat', back, M4(sx, F + 0.78, s * 1.24, 0, s > 0 ? Math.PI : 0, 0).multiply(new THREE.Matrix4().makeRotationX(-0.12 * s)));
      B.box('steelDark', seatW, 0.04, 0.05, sx, F + 1.10, s * 1.26);
      // разделители мест
      const n = Math.max(2, Math.round(seatW / 0.46));
      for (let i = 1; i < n; i++) B.box('seatBase', 0.02, 0.05, 0.42, sx - seatW / 2 + i * seatW / n, F + 0.47, z);
    }
  }
  // поручни
  for (const d of cfg.doors) {
    for (const s of [-1, 1]) for (const e of [-1, 1]) {
      B.cyl('pole', 0.021, 0.021, 2.05, 10, d + e * (SPECS.doorW / 2 + 0.16), F + 1.02, s * 0.72);
    }
    B.cyl('pole', 0.02, 0.02, 1.5, 10, d, 2.62, 0, [Math.PI / 2, 0, 0]);
  }
  for (const s of [-1, 1]) {
    B.cyl('pole', 0.022, 0.022, len - 0.6, 10, cx, 2.66, s * 0.80, [0, 0, Math.PI / 2]);
    for (let i = 0; i < Math.floor(len / 1.1); i++) {
      const hx = x0 + 0.6 + i * 1.1;
      B.cyl('pole', 0.012, 0.012, 0.20, 6, hx, 2.55, s * 0.80);
      const loop = new THREE.TorusGeometry(0.055, 0.012, 5, 10);
      B.add('rubber', loop, M4(hx, 2.42, s * 0.80, 0, Math.PI / 2, 0));
    }
  }
  // торцевые перегородки и переход
  for (const e of [cfg.rear + 0.10, ...(cfg.head ? [] : [cfg.front - 0.10])]) {
    for (const s of [-1, 1]) B.box('interiorWall', 0.06, 2.10, 0.48, e, F + 1.05, s * 1.06);
    B.box('interiorWall', 0.06, 0.30, 2.5, e, 3.10, 0);
  }
  // информационные экраны над дверями
  for (const d of cfg.doors) for (const s of [-1, 1]) {
    B.box('underDark', 0.62, 0.20, 0.03, d, 2.92, s * 1.26);
    B.box('screen', 0.56, 0.15, 0.01, d, 2.92, s * 1.245);
  }
  // пассажиры
  if (state.passengers) {
    for (const gp of gaps) {
      const w = gp[1] - gp[0];
      if (w < 0.8) continue;
      const n = Math.max(1, Math.floor(w / 0.52));
      for (const s of [-1, 1]) for (let i = 0; i < n; i++) {
        if (R() < 0.34) continue;
        const px = gp[0] + 0.26 + i * (w - 0.5) / Math.max(1, n - 1 || 1);
        person(B, clamp(px, gp[0] + 0.24, gp[1] - 0.24), F + 0.45, s * 1.02, true, -s, (R() * 6) | 0);
      }
    }
    for (let i = 0; i < 6; i++) {
      const px = lerp(x0 + 1.2, x1 - 1.2, R());
      if (cfg.doors.some(d => Math.abs(d - px) < 1.0)) continue;
      person(B, px, F, rr(-0.5, 0.5), false, 1, (R() * 6) | 0);
    }
  }
  B.flush(MATS, G, { cast: false, receive: true });

  /* --- кабина машиниста --- */
  if (cfg.head) buildCab(cfg, G, anim);
}

function buildCab(cfg, G, anim) {
  const B = new Builder();
  const F = DIM.floorH, xw = cfg.cabWall;
  B.box('interiorFloor', 3.0, 0.05, 2.55, xw + 1.5, F - 0.02, 0);
  B.box('cabDark', 0.08, 2.15, 2.5, xw, F + 1.07, 0);
  B.box('cabPanel', 0.06, 1.85, 0.72, xw + 0.05, F + 0.93, -0.55);
  B.box('interiorWall', 3.0, 0.06, 2.4, xw + 1.5, 3.22, 0);
  B.box('ledWarm', 1.2, 0.03, 0.22, xw + 1.4, 3.18, 0);
  for (const s of [-1, 1]) B.box('cabDark', 3.0, 0.60, 0.06, xw + 1.5, F + 0.30, s * 1.28);
  // пульт
  const desk = plate(2.10, 0.62, 0.10, 0.10);
  B.add('cabPanel', desk, M4(cfg.front - 1.05, F + 0.78, 0, -Math.PI / 2 + 0.18, 0, Math.PI / 2));
  B.box('cabDark', 0.55, 0.72, 2.05, cfg.front - 0.85, F + 0.36, 0);
  B.box('cabPanel', 0.42, 0.10, 1.95, cfg.front - 1.12, F + 0.86, 0, [0, 0, 0.20]);
  // экраны пульта
  for (const s of [-1, 1]) {
    B.box('underDark', 0.05, 0.30, 0.44, cfg.front - 1.16, F + 1.02, s * 0.44, [0, 0, 0.22]);
    B.box('screen', 0.02, 0.25, 0.38, cfg.front - 1.13, F + 1.03, s * 0.44, [0, 0, 0.22]);
  }
  // контроллер машиниста
  B.cyl('steelDark', 0.025, 0.025, 0.20, 8, cfg.front - 1.20, F + 0.95, 0.78, [0.4, 0, 0]);
  B.cyl('rubber', 0.035, 0.035, 0.09, 10, cfg.front - 1.24, F + 1.04, 0.82, [0.4, 0, 0]);
  B.cyl('steelDark', 0.025, 0.025, 0.18, 8, cfg.front - 1.20, F + 0.94, -0.78, [-0.3, 0, 0]);
  // кресло машиниста
  B.box('cabDark', 0.16, 0.42, 0.16, xw + 1.15, F + 0.21, 0.30);
  B.add('seat', plate(0.50, 0.48, 0.08, 0.10), M4(xw + 1.15, F + 0.45, 0.30, -Math.PI / 2, 0, 0));
  B.add('seat', plate(0.48, 0.66, 0.08, 0.09), M4(xw + 0.92, F + 0.82, 0.30, 0, Math.PI / 2, 0));
  B.box('cabDark', 0.06, 0.20, 0.44, xw + 0.90, F + 1.22, 0.30);
  // машинист
  person(B, xw + 1.22, F + 0.48, 0.30, true, 1, 5);
  // шкаф машиниста и аппараты
  B.box('cabPanel', 0.45, 1.9, 0.55, xw + 0.35, F + 0.95, -1.0);
  B.box('underDark', 0.30, 0.5, 0.4, xw + 0.35, F + 1.5, 1.05);
  B.flush(MATS, G, { cast: false, receive: true });
}

/* ------------------------- межвагонный переход (гармошка) ------------------ */
function buildGangway(xa, xb, L) {
  const g = new THREE.Group();
  const B = new Builder();
  const w = SPECS.gangwayW + 0.22, h = 2.24;
  const len = xb - xa;
  const n = 9;
  for (let i = 0; i < n; i++) {
    const t = (i + 0.5) / n;
    const x = lerp(xa, xb, t);
    const s = i % 2 === 0 ? 1.0 : 0.94;
    const shape = roundedRectShape(w * s, h * s, 0.20, 0, DIM.floorH + h / 2 - 0.05);
    shape.holes.push(roundedRectPath(w * s - 0.10, h * s - 0.10, 0.17, 0, DIM.floorH + h / 2 - 0.05));
    const geo = new THREE.ExtrudeGeometry(shape, { depth: len / n * 0.92, bevelEnabled: false, curveSegments: 5 });
    B.add('rubber', geo, M4(x - len / n * 0.46, 0, 0, 0, Math.PI / 2, 0));
  }
  // мостик и поручни
  B.box('steelDark', len, 0.04, SPECS.gangwayW, (xa + xb) / 2, DIM.floorH - 0.02, 0);
  for (const s of [-1, 1]) {
    B.cyl('pole', 0.018, 0.018, 1.9, 8, (xa + xb) / 2, DIM.floorH + 0.95, s * (SPECS.gangwayW / 2 - 0.06));
    B.box('rubber', len, 1.9, 0.05, (xa + xb) / 2, DIM.floorH + 0.95, s * (SPECS.gangwayW / 2 + 0.04));
  }
  // межвагонные жгуты
  for (const s of [-1, 1]) for (let i = 0; i < 3; i++) {
    B.cyl('rubber', 0.035, 0.035, len, 8, (xa + xb) / 2, 0.85 + i * 0.09, s * 1.15, [0, 0, Math.PI / 2]);
  }
  // сцепка
  B.cyl('steelDark', 0.07, 0.07, len * 0.9, 10, (xa + xb) / 2, 0.72, 0, [0, 0, Math.PI / 2]);
  B.flush(MATS, g, { cast: true, receive: true });
  return g;
}

/* мягкая контактная тень под вагоном */
let shadowTexShared = null;
function contactShadow(len) {
  if (!shadowTexShared) {
    const c = cvs(128, 128), g = c.getContext('2d');
    const grd = g.createRadialGradient(64, 64, 4, 64, 64, 62);
    grd.addColorStop(0, 'rgba(0,0,0,0.85)'); grd.addColorStop(0.55, 'rgba(0,0,0,0.45)'); grd.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = grd; g.fillRect(0, 0, 128, 128);
    shadowTexShared = tex(c, { clamp: true });
  }
  const m = new THREE.Mesh(new THREE.PlaneGeometry(len, 4.6), new THREE.MeshBasicMaterial({
    map: shadowTexShared, transparent: true, opacity: 0.75, depthWrite: false, color: 0x000000, toneMapped: false
  }));
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.015;
  m.renderOrder = -1;
  return m;
}
