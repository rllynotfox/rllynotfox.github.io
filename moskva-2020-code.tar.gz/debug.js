const puppeteer=require('puppeteer');const path=require('path');
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const p=await b.newPage();await p.setViewport({width:1200,height:760});
const errs=[];p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error'&&!m.text().includes('NaN'))errs.push('ERR '+m.text())});
await p.goto('file://'+path.join(__dirname,'moskva-2020.html'),{waitUntil:'load'});
await p.waitForFunction(()=>document.getElementById('loader').classList.contains('done'),{timeout:120000}).catch(()=>errs.push('loader timeout'));
const bad=await p.evaluate(()=>{
  const out=[];
  window.__getScene && window.__getScene().traverse(o=>{
    if(!o.geometry) return;
    const a=o.geometry.attributes.position; if(!a) return;
    let n=0; for(let i=0;i<a.array.length;i++) if(!isFinite(a.array[i])) n++;
    if(n) out.push({name:o.name||'(noname)',parent:o.parent&&o.parent.name,nan:n,count:a.count,chain:(function(x){let s=[];while(x){s.push(x.name||x.type);x=x.parent}return s.join(' < ')})(o)});
  });
  return out;
});
console.log(JSON.stringify(bad.slice(0,12),null,1));
console.log('OTHER ERRORS:',errs.slice(0,10).join('\n'));
await b.close();})();
